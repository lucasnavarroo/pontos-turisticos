create view VW_ATEND_DATA_HORA as
    Select a.cd_unidade_atendimento,
         a.cd_medico_atendente,
         a.DT_ATENDIMENTO,
         a.hr_atendimento,
         a.cd_setor,
         a.cd_tipo_atendimento,
         to_date(to_char(a.dt_atendimento,'dd/mm/yyyy')||' '||fn_hora(a.HR_ATENDIMENTO),'dd/mm/yyyy hh24:mi:ss') dat_hor,
         a.cd_atendimento,
         a.cd_clinica
    from tm_atendimento a
   where a.CD_ATENDIMENTO > 0
     and a.dt_canc_atend is null
     and nvl(a.cd_medico_atendente,0) != 0  -- atend com alta
  UNION ALL
  -- atendimentos sem alta informadas
  Select a.cd_unidade_atendimento,
         o.cd_pessoa  cd_medico_atendente,
         a.DT_ATENDIMENTO,
         a.hr_atendimento,
         a.cd_setor,
         a.cd_tipo_atendimento,
         to_date(to_char(a.dt_atendimento,'dd/mm/yyyy')||' '||fn_hora(a.HR_ATENDIMENTO),'dd/mm/yyyy hh24:mi:ss') dat_hor,
         a.cd_atendimento,
         a.cd_clinica
    from tb_operador o,
         tb_senha_atendimento_sa sa,
         tm_atendimento a
   where a.CD_ATENDIMENTO > 0
     and a.dt_canc_atend is null
     and sa.cd_atendimento = a.cd_atendimento
     and sa.fl_status not in (6,7)
     and nvl(a.cd_medico_atendente,0) = 0   -- atendimento sem alta
     and o.nm_operador  = sa.cd_operador_inicio
     and o.cd_pessoa is not null -- exceto usuarios tipo 'UC.... CHAMADA CELULAR LAB
/

