create view VW_SAM_PRESC_MED_SUP as
select cd_atendimento,
       cd_ocorrencia_plano,
       cd_ordem_prescricao,
       cd_procedimento,
       QT_FREQUENCIA_USO,
       FL_NECESSARIO,
       FL_ACM,
       DS_OBSERVACAO,
       CD_ORDEM_PROC_PLANO_USO,
       CD_PROC_PLANO_PAI,
       fl_status_uso,
       fl_validado,
       p.fl_carro_parada_c,
       p.fl_tipo_aprazamento,
       presc.nm_fantasia       prof_prescritor,
       val.nm_fantasia         prof_validador,
       canc.nm_fantasia        prof_cancelador
  from TB_PROCEDIMENTO_PLANO_USO p,
       tb_pessoa                 presc,
       tb_pessoa                 val,
       tb_pessoa                 canc
 where p.cd_profissional_prescreve = presc.cd_pessoa(+)
   and p.cd_profissional_valida = val.cd_pessoa(+)
   and p.cd_profissional_cancela = canc.cd_pessoa(+)
   and cd_tipo_procedimento in (4, 5, 6)
   and cd_proc_plano_pai is null
   and fn_aerosol(cd_procedimento) = 0
 order by decode(cd_proc_plano_pai,
                 null,
                 cd_ordem_proc_plano_uso,
                 cd_proc_plano_pai),
          cd_ordem_proc_plano_uso
/

