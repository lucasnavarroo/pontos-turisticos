create view VW_SAM_MS_SUBGRUPO_PROCED as
select distinct b.cd_subgrupo_procedimento,
                b.nm_subgrupo_procedimento,
                b.cd_grupo_procedimento
  from tb_subgrupo_procedimento b, tb_procedimento c
 where c.cd_grupo_procedimento = b.cd_grupo_procedimento
   and c.cd_subgrupo_procedimento = b.cd_subgrupo_procedimento
   and c.fl_tipo_exame in (4,6)
/

