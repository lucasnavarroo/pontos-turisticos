create view FN_LIQDC_INTERNA as
select "ID_LIQDC_INTERNA","ID_CC"
     from fn_liqdc_interna@matera
/

