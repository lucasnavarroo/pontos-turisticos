create view VW_ITENS_KIT_PADRAO_FULL_V2 as
select /*
          Fred Monteiro - IVIA - 18/06/2018
          View que contem mais informacoes sobre o kit, como o responsavel, faixa pediatrica e ato cirurgico
       */
       a.id_kit,
       a.cd_atendimento,
       a.cd_unidade_atendimento,
       a.nm_unidade_atendimento,
       a.cd_param_grupo_proc,
       a.nm_param_grupo_proc,
       a.cd_tipo_grupo_proc,
       a.cd_procedimento,
       a.nm_procedimento,
       a.dt_transacao,
       a.fl_tipo_classificacao,
       a.ds_fl_tipo_classificacao,
       a.cd_tipo_produto_servico,
       a.cd_tipo_classificacao,
       a.ds_tipo_classificacao,
       a.cd_classificacao,
       a.nm_classificacao,
       a.cd_material_padrao,
       a.nm_material_padrao,
       nvl(aa.qt_material, a.qtd) qtd,
       a.cd_pessoa,
       a.cd_faixa,
       ab.cd_responsavel,
       ac.cd_ato_cirurgico,
       a.tipo_medicamento
  from    tb_material_cirurgia    ac,
          tb_material_responsavel ab,
          tb_material_pediatria   aa,
       vw_itens_kit_padrao_full   a
 where 1 = 1
   -- filtros
   and a.dt_transacao between nvl(aa.dt_ini_vigencia, a.dt_transacao) and nvl(aa.dt_fin_vigencia, a.dt_transacao)
   and a.dt_transacao between nvl(ab.dt_ini_vigencia, a.dt_transacao) and nvl(ab.dt_fin_vigencia, a.dt_transacao)
   and a.dt_transacao between nvl(ac.dt_ini_vigencia, a.dt_transacao) and nvl(ac.dt_fin_vigencia, a.dt_transacao)
   -- join a -- aa
   and a.cd_procedimento    = aa.cd_procedimento(+)
   and a.cd_material_padrao = aa.cd_material(+)
   and a.cd_faixa           = aa.cd_faixa(+)
   -- join a -- ab
   and a.cd_procedimento = ab.cd_procedimento(+)
   and a.cd_material_padrao = ab.cd_material(+)
   -- join a -- ac
   and a.cd_procedimento = ac.cd_procedimento(+)
   and a.cd_material_padrao = ac.cd_material(+)
/

