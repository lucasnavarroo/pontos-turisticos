create view VW_ADMINISTRACAO_MED as
select ad.ds_administracao_diluicao,
       a.cd_mnemonico||'   '||
          decode(ad.fl_tipo_administracao,'C','Contínuo','B','Bolus','L','Lento',' ') ds_administracao_via,
    ad.fl_tipo_administracao,
      ad.cd_tipo_acesso,
      ad.qt_retirar_medic,ad.cd_reconstituir,ad.qt_reconstituir,
      ad.qt_retirar_reconst1,ad.cd_reconstituir2,ad.qt_reconstituir2,ad.qt_concentracao_diluicao,
      ad.cd_unidade_conc_diluicao,ad.cd_principio_ativo,ad.cd_ocorrencia_diluicao,
      ad.cd_ordem_administracao,ad.qt_dosagem_padrao,ad.cd_unidade_dosagem_padrao,
      ad.cd_diluente,ad.qt_diluente,ad.cd_apresentacao_diluente,ap.cd_estado_fisico,ap.cd_apresentacao,
      m.qt_conteudo,ad.qt_frequencia_padrao,ad.fl_unid_freq_padrao,
      pdd.qt_dosagem_padrao qt_dose_padrao_adm,
      pdd.cd_unidade_usual,
      u.nr_unidade_usual,
      pdd.qt_idade_faixa_inf,
      pdd.qt_idade_faixa_sup,
      pf.nu_produto,
      pcd.cd_classe_acomodacao
           from tb_unidade_usual u,
                tb_material m,
                tb_produto_mat_med pmm,
                tb_produto pf,
                tb_tipo_acesso a,
                tb_param_dosagem_diluicao pdd,
                tb_param_classe_diluicao pcd,
                tb_principio_ativo pa,
                tb_produto_principio_ativo ppa,
                tb_apresentacao_diluicao ap,
                tb_administracao_diluicao ad
           where ad.cd_principio_ativo=ppa.cd_principio_ativo and
                 ap.cd_principio_ativo=ad.cd_principio_ativo and
                 ap.cd_ocorrencia_diluicao=ad.cd_ocorrencia_diluicao and
                 --ap.cd_apresentacao like 'AMPL' and
                 ppa.nu_produto=pf.nu_produto and
                 --pf.nu_produto=202 and
                 pa.cd_principio_ativo=ppa.cd_principio_ativo and
                 pcd.cd_principio_ativo(+)=ad.cd_principio_ativo and
                 pcd.cd_ocorrencia_diluicao(+)=ad.cd_ocorrencia_diluicao and
                 pcd.cd_ordem_administracao(+)=ad.cd_ordem_administracao and
                 --pcd.cd_classe_acomodacao=31 and
                 pdd.cd_principio_ativo(+)=ad.cd_principio_ativo and
                 pdd.cd_ocorrencia_diluicao(+)=ad.cd_ocorrencia_diluicao and
                 pdd.cd_ordem_administracao(+)=ad.cd_ordem_administracao and
                 --to_number(substr(fn_calcula_idade('10-10-2000'),1,2)) >= pdd.qt_idade_faixa_inf and
                 --to_number(substr(fn_calcula_idade('10-10-2000'),1,2)) <= pdd.qt_idade_faixa_sup and
                 pmm.nu_produto=pf.nu_produto and
                 m.cd_material=pmm.cd_mat_med and
                 ap.qt_dosagem=decode(m.cd_unidade_conteudo_dose,NULL,NVL(m.qt_dosagem,1),
                    (NVL(m.qt_dosagem,1)*decode(m.fl_fragmenta,'N',m.qt_conteudo,ap.qt_volume)
                                /m.qt_conteudo_dosagem)) and
                 ap.cd_apresentacao=m.cd_apresentacao and
                 a.cd_tipo_acesso=ad.cd_tipo_acesso   and
                 u.cd_unidade_usual(+)=pdd.cd_unidade_usual
/

