create view VFN_FILIAL as
select "COD_EMPRESA","COD_FILIAL","NOME","APELIDO"
      from vfn_filial@matera
/

