create view VW_DADOS_PACIENTE as
select -- dados do paciente --
       pac.cd_paciente cd_prontuario,
       pac.nm_paciente,
       to_char(pac.dt_nascimento, 'ddmmyyyy') dt_nascimento,
       pac.cd_sexo,
       pac.cd_cor,
       pac.fl_tipo_sanguineo,
       pac.fl_fator_rh,
       pac.cd_estado_civil,
       pac.nm_mae,
       pac.nu_cgc_cpf,
       pac.nm_municipio,
       pac.cd_uf
 from tb_paciente pac
/

