create view VW_SAM_HIST_RESULTADOS_EXAMES as
select distinct rp.cd_atendimento,
                rp.cd_ocorrencia,
                rp.cd_ordem,
                pr.ds_parametro_referencia,
                rp.ds_resultado_procedimento,
                uu.nm_unidade_usual,
                pk_pepsam_historico.fn_referencia_procedimento(p.cd_atendimento,
                                                               p.cd_ocorrencia,
                                                               p.cd_ordem,
                                                               p.cd_procedimento,
                                                               p.dt_resultado) cd_ref,
                rp.cd_parametro_referencia,
                rp.sq_resultado
  from TB_RESULTADO_PROCEDIMENTO rp,
       TB_PROCEDIMENTO_REALIZADO p,
       TB_PARAMETRO_REFERENCIA   pr,
       TB_UNIDADE_USUAL          uu
 where rp.cd_atendimento = p.cd_atendimento
   and rp.cd_ocorrencia = p.cd_ocorrencia
   and rp.cd_ordem = p.cd_ordem
   and rp.cd_parametro_referencia = pr.cd_parametro_referencia(+)
   and rp.cd_unidade_usual = uu.cd_unidade_usual(+)
/

