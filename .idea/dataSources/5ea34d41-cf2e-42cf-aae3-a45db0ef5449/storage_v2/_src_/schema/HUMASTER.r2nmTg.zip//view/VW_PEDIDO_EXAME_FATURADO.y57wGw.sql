create view VW_PEDIDO_EXAME_FATURADO as
select  at.cd_atendimento,
	at.dt_atendimento,
	at.cd_paciente,
	at.fl_internacao,
	pa.nm_paciente,
	pe.cd_ocorrencia ord_ped,
	at.cd_motivo_atendimento,
	decode(at.cd_motivo_atendimento,1,'EMER',2, 'ELET') ds_motivo,
	pe.nu_pedido,
	pe.dt_pedido,
	cob.cd_cobranca,
	cob.nu_remessa,
	gu.cd_ocorrencia ord_guia,
	gu.nu_guia,
	gu.cd_setor_origem,
	gu.cd_pessoa_realiza,
	se.nm_setor,
	gu.cd_convenio_pagador,
	co.cd_convenio,
	ps.nm_fantasia nm_convenio,
	pc.cd_plano_convenio,
	pc.ds_plano_convenio,
	pr.cd_procedimento, po.nr_procedimento,
	pr.qt_procedimento, pr.vl_total,
	pr.cd_ordem ord_proc
from    tm_setor se,
	tb_paciente pa,
	tb_plano_convenio pc,
	tb_pessoa ps,
	tm_convenio co,
	tb_convenio_pagador cp ,
	tb_procedimento po,
	tb_procedimento_realizado pr,
	tb_guia gu,
	tm_atendimento at,
	tb_pedido_exame pe,
	tb_cobranca_paciente cob
where   pe.cd_atendimento  = cob.cd_atendimento          and
   --   pe.cd_ocorrencia   = to_number(cob.nu_guia)      and
	at.cd_atendimento       = pe.cd_atendimento      and
        at.cd_unidade_atendimento like
        decode(fn_operador_multempresa,'S','%',fn_unidade_operador) and
	gu.cd_atendimento       = at.cd_atendimento      and
	gu.cd_ocorrencia_pedido = pe.cd_ocorrencia       and
	gu.cd_cobranca          = cob.cd_cobranca        and
	pr.cd_atendimento       = gu.cd_atendimento      and
	pr.cd_ocorrencia        = gu.cd_ocorrencia       and
	cp.cd_atendimento       = gu.cd_atendimento      and
	cp.cd_convenio_pagador  = gu.cd_convenio_pagador and
	co.cd_convenio          = cp.cd_convenio         and
	ps.cd_pessoa            = co.cd_pessoa           and
	pc.cd_convenio          = cp.cd_convenio         and
	pc.cd_plano_convenio    = cp.cd_plano            and
	po.cd_procedimento      = pr.cd_procedimento     and
	pa.cd_paciente          = at.cd_paciente         and
	se.cd_setor             = gu.cd_setor_origem
/

