create view VW_TITULOS_ABERTOS as
select  o.cd_cedente_sacado cd_pessoa,
   p.nm_pessoa_razao_social,
   o.cd_documento_gerador,
   o.cd_documento_controle,
   decode(o.cd_status,2, o.vl_saldo_obrigacao, o.vl_obrigacao) vl_obrigacao,
   o.cd_obrigacao,
   o.dt_vencimento
from    tb_pessoa p,
   tm_obrigacao o
where   o.cd_status in (1,2,10,13)
  and   o.cd_tipo_obrigacao = 2
  and   o.cd_unidade_atendimento like fn_unidade
  and   p.cd_pessoa = o.cd_cedente_sacado
/

