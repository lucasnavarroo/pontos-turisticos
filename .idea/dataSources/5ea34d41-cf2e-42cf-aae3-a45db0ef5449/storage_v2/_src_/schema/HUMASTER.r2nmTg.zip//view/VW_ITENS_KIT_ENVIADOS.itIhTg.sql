create view VW_ITENS_KIT_ENVIADOS as
select /*
           Fred Monteiro - IVIA - 04/04/2018
           View que contem os itens do kit que foram enviados na requisicao principal
       */
       a.id_kit,
       a.cd_atendimento,
       ab.cd_unidade_atendimento,
       aba.nm_unidade_atendimento,
       aea.cd_param_grupo_proc,
       aea.nm_param_grupo_proc,
       aea.cd_tipo_grupo_proc,
       a.cd_procedimento,
       ac.nm_procedimento,
       a.dt_transacao,
       aaaaaaa.fl_tipo_classificacao,
       aaaaaaa.ds_fl_tipo_classificacao,
       aaaaaaa.cd_tipo_produto_servico,
       aaaaaa.cd_tipo_classificacao,
       aaaaaa.ds_tipo_classificacao,
       aaaaa.cd_classificacao,
       aaaaa.nm_classificacao,
       aaa.cd_material,
       aaaa.nm_material,
       aaa.qt_material_c qtd,
       dbms_lob.substr(aaa.cd_codigo_barra) cd_codigo_barra,
       a.cd_pessoa_func_montou cd_pessoa
  from       tb_param_grupo_proc                      aea,     -- grupo de procedimento
          tb_proc_grupo_proc                          ae,      -- procedimento x grupo de procedimento
          tm_setor                                    ad,      -- setor que montou o kit
          tb_procedimento                             ac,      -- procedimento do kit
             tb_unidade_atendimento                   aba,     -- unidade de atendimento
          tm_atendimento                              ab,      -- atendimento do kit
                         tb_classe_tipo_classificacao aaaaaaa, -- tipo classe da classificacao
                      tb_tipo_classificacao           aaaaaa,  -- tipo de classificacao do material
                   tb_classificacao                   aaaaa,   -- classificacao do material
                tb_material                           aaaa,    -- material do kit
             tb_item_requisicao                       aaa,     -- itens da requisicao
          tm_requisicao                               aa,      -- requisicoes do kit
       tm_kit_cirurgia_lote                           a        -- kit
 where 1 = 1
   -- filtros
   and not exists (select 1
                     from tb_registro_saidas_extras b
                    where 1 = 1
                      and b.cd_requisicao = aa.cd_requisicao
                      and b.id_kit = a.id_kit)
   and aa.nm_mensagem not like '%SORO%'
   and fn_almox_consignado(aa.cd_setor_controle) = 0
   -- join a -- aa
   and a.id_kit = aa.id_kit
   -- join aa -- aaa
   and aa.cd_requisicao = aaa.cd_requisicao
   -- join aaa -- aaaa
   and aaa.cd_material = aaaa.cd_material
   -- join aaaa -- aaaaa
   and aaaa.cd_classificacao = aaaaa.cd_classificacao
   -- join aaaaa -- aaaaaa
   and aaaaa.cd_tipo_classificacao = aaaaaa.cd_tipo_classificacao
   -- join aaaaaa -- aaaaaaa
   and aaaaaa.fl_tipo_classificacao = aaaaaaa.fl_tipo_classificacao
   -- join a -- ab
   and a.cd_atendimento = ab.cd_atendimento(+)
   -- join ab -- aba
   and ab.cd_unidade_atendimento = aba.cd_unidade_atendimento(+)
   -- join a -- ac
   and a.cd_procedimento = ac.cd_procedimento
   -- join a -- ad
   and a.cd_setor_controle = ad.cd_setor
   -- join a -- ae
   and a.cd_procedimento = ae.cd_procedimento
   -- join ae -- aea
   and ae.cd_param_grupo_proc = aea.cd_param_grupo_proc
/

