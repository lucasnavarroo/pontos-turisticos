create view VW_EXAME_PROTOCOLO_SA as
select ta.cd_unidade_atendimento,
         ta.dt_atendimento,
         sa.cd_atendimento,
         sa.cd_senha_master,
         sa.cd_paciente,
         pa.nm_paciente,
         pa.dt_nascimento,
         sa.cd_procedimento,
         p.nm_procedimento,
         sa.cd_exame,
         pro.cd_protocolo_exame,
         sa.nu_guia,
         sa.nu_pedido,
         op.nm_operador nm_solicitante,
         (select /*+ FIRST_ROWS(1) */
           a.cd_amostra
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) cd_amostra,
         sa.dt_atendimento data_solicitacao,
         sa.dt_importacao,
         pd.nm_operador quem_importou,
         (select
          /*+ FIRST_ROWS(1) */
           p.dt_pedido
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) dt_pedido,
         (select
          /*+ FIRST_ROWS(1) */
           ae.dt_confirmacao
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) dt_confirmacao,
         (select
          /*+ FIRST_ROWS(1) */
           ae.cd_operador_confirma
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) cd_operador_confirma,
         (select /*+ FIRST_ROWS(1) */
           am.dt_amostra_coleta
            from tb_lote_rast    lo,
                 tb_amostra_rast am
           where lo.cd_lote = am.cd_lote
             and lo.fl_status != 'C'
             and am.cd_amostra_coleta =
                 (select
                  /*+ FIRST_ROWS(1) */
                   a.cd_amostra
                    from tb_procedimento_realizado pr,
                         tb_guia                   g,
                         tb_pedido_exame           p,
                         tb_amostra_procedimento   a,
                         tb_amostra_exame          ae
                   where pr.cd_ocorrencia = g.cd_ocorrencia
                     and pr.cd_atendimento = g.cd_atendimento
                     and g.cd_ocorrencia_pedido = p.cd_ocorrencia
                     and g.cd_atendimento = p.cd_atendimento
                     and a.cd_atendimento = pr.cd_atendimento
                     and a.cd_ocorrencia = pr.cd_ocorrencia
                     and a.cd_ordem = pr.cd_ordem
                     and pr.cd_atendimento = sa.cd_atendimento
                     and pr.cd_procedimento = sa.cd_procedimento
                     and a.cd_atendimento = ae.cd_atendimento
                     and a.cd_amostra = ae.cd_amostra
                     and g.nu_guia = sa.nu_guia
                     and rownum = 1)
             and rownum = 1) dt_envio,
         (select /*+ FIRST_ROWS(1) */
           lo.cd_oper_entrega
            from tb_lote_rast    lo,
                 tb_amostra_rast am
           where lo.cd_lote = am.cd_lote
             and lo.fl_status != 'C'
             and am.cd_amostra_coleta =
                 (select
                  /*+ FIRST_ROWS(1) */
                   a.cd_amostra
                    from tb_procedimento_realizado pr,
                         tb_guia                   g,
                         tb_pedido_exame           p,
                         tb_amostra_procedimento   a,
                         tb_amostra_exame          ae
                   where pr.cd_ocorrencia = g.cd_ocorrencia
                     and pr.cd_atendimento = g.cd_atendimento
                     and g.cd_ocorrencia_pedido = p.cd_ocorrencia
                     and g.cd_atendimento = p.cd_atendimento
                     and a.cd_atendimento = pr.cd_atendimento
                     and a.cd_ocorrencia = pr.cd_ocorrencia
                     and a.cd_ordem = pr.cd_ordem
                     and pr.cd_atendimento = sa.cd_atendimento
                     and pr.cd_procedimento = sa.cd_procedimento
                     and a.cd_atendimento = ae.cd_atendimento
                     and a.cd_amostra = ae.cd_amostra
                     and g.nu_guia = sa.nu_guia
                     and rownum = 1)
             and rownum = 1) cd_operador_envia,
         (select /*+ FIRST_ROWS(1) */
           am.dt_amostra_lab
            from tb_lote_rast    lo,
                 tb_amostra_rast am
           where lo.cd_lote = am.cd_lote
             and lo.fl_status != 'C'
             and am.cd_amostra_coleta =
                 (select
                  /*+ FIRST_ROWS(1) */
                   a.cd_amostra
                    from tb_procedimento_realizado pr,
                         tb_guia                   g,
                         tb_pedido_exame           p,
                         tb_amostra_procedimento   a,
                         tb_amostra_exame          ae
                   where pr.cd_ocorrencia = g.cd_ocorrencia
                     and pr.cd_atendimento = g.cd_atendimento
                     and g.cd_ocorrencia_pedido = p.cd_ocorrencia
                     and g.cd_atendimento = p.cd_atendimento
                     and a.cd_atendimento = pr.cd_atendimento
                     and a.cd_ocorrencia = pr.cd_ocorrencia
                     and a.cd_ordem = pr.cd_ordem
                     and pr.cd_atendimento = sa.cd_atendimento
                     and pr.cd_procedimento = sa.cd_procedimento
                     and a.cd_atendimento = ae.cd_atendimento
                     and a.cd_amostra = ae.cd_amostra
                     and g.nu_guia = sa.nu_guia
                     and rownum = 1)
             and rownum = 1) dt_recebimento,
         (select /*+ FIRST_ROWS(1) */
           lo.cd_oper_recebe
            from tb_lote_rast    lo,
                 tb_amostra_rast am
           where lo.cd_lote = am.cd_lote
             and lo.fl_status != 'C'
             and am.cd_amostra_coleta =
                 (select
                  /*+ FIRST_ROWS(1) */
                   a.cd_amostra
                    from tb_procedimento_realizado pr,
                         tb_guia                   g,
                         tb_pedido_exame           p,
                         tb_amostra_procedimento   a,
                         tb_amostra_exame          ae
                   where pr.cd_ocorrencia = g.cd_ocorrencia
                     and pr.cd_atendimento = g.cd_atendimento
                     and g.cd_ocorrencia_pedido = p.cd_ocorrencia
                     and g.cd_atendimento = p.cd_atendimento
                     and a.cd_atendimento = pr.cd_atendimento
                     and a.cd_ocorrencia = pr.cd_ocorrencia
                     and a.cd_ordem = pr.cd_ordem
                     and pr.cd_atendimento = sa.cd_atendimento
                     and pr.cd_procedimento = sa.cd_procedimento
                     and a.cd_atendimento = ae.cd_atendimento
                     and a.cd_amostra = ae.cd_amostra
                     and g.nu_guia = sa.nu_guia
                     and rownum = 1)
             and rownum = 1) cd_operador_recebe,
         (select /*+ FIRST_ROWS(1) */
           lo.cd_setor_recebe
            from tb_lote_rast    lo,
                 tb_amostra_rast am
           where lo.cd_lote = am.cd_lote
             and lo.fl_status != 'C'
             and am.cd_amostra_coleta =
                 (select
                  /*+ FIRST_ROWS(1) */
                   a.cd_amostra
                    from tb_procedimento_realizado pr,
                         tb_guia                   g,
                         tb_pedido_exame           p,
                         tb_amostra_procedimento   a,
                         tb_amostra_exame          ae
                   where pr.cd_ocorrencia = g.cd_ocorrencia
                     and pr.cd_atendimento = g.cd_atendimento
                     and g.cd_ocorrencia_pedido = p.cd_ocorrencia
                     and g.cd_atendimento = p.cd_atendimento
                     and a.cd_atendimento = pr.cd_atendimento
                     and a.cd_ocorrencia = pr.cd_ocorrencia
                     and a.cd_ordem = pr.cd_ordem
                     and pr.cd_atendimento = sa.cd_atendimento
                     and pr.cd_procedimento = sa.cd_procedimento
                     and a.cd_atendimento = ae.cd_atendimento
                     and a.cd_amostra = ae.cd_amostra
                     and g.nu_guia = sa.nu_guia
                     and rownum = 1)
             and rownum = 1) cd_setor_destino,
         (select /*+ FIRST_ROWS(1) */
           pr.dt_resultado
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and pr.dt_resultado is not null
             and rownum = 1) dt_resultado,
         (select
          /*+ FIRST_ROWS(1) */
           substr(pr.ds_observacao, 1, instr(pr.ds_observacao, '-', 1) - 1)
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) cd_operador_resultado,
         (select
          /*+ FIRST_ROWS(1) */
           pr.dt_libera_laudo
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) dt_libera_laudo,
         (select /*+ FIRST_ROWS(1) */
           op.nm_operador
            from tb_procedimento_realizado pr,
                 tb_prof_proced_realizado  prof,
                 tb_operador               op,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and prof.cd_profissional = op.cd_pessoa
             and prof.cd_tipo_ato_profissional = 20
             and prof.cd_atendimento = pr.cd_atendimento
             and prof.cd_ocorrencia = pr.cd_ocorrencia
             and prof.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) cd_operador_libera,
         (select
          /*+ FIRST_ROWS(1) */
           pr.cd_setor
            from tb_procedimento_realizado pr,
                 tb_guia                   g,
                 tb_pedido_exame           p,
                 tb_amostra_procedimento   a,
                 tb_amostra_exame          ae
           where pr.cd_ocorrencia = g.cd_ocorrencia
             and pr.cd_atendimento = g.cd_atendimento
             and g.cd_ocorrencia_pedido = p.cd_ocorrencia
             and g.cd_atendimento = p.cd_atendimento
             and a.cd_atendimento = pr.cd_atendimento
             and a.cd_ocorrencia = pr.cd_ocorrencia
             and a.cd_ordem = pr.cd_ordem
             and pr.cd_atendimento = sa.cd_atendimento
             and pr.cd_procedimento = sa.cd_procedimento
             and a.cd_atendimento = ae.cd_atendimento
             and a.cd_amostra = ae.cd_amostra
             and g.nu_guia = sa.nu_guia
             and rownum = 1) cd_setor,
         st.cd_local_atendimento
    from tb_exame_solicitado_sa  sa,
         tb_protocolo_exame_sa   pro,
         tm_atendimento          ta,
         tb_paciente             pa,
         tb_procedimento         p,
         tb_pessoa               pe,
         tb_operador             op,
         tb_pedido_exame         pd,
         tb_senha_atendimento_sa st
   where sa.cd_atendimento = pro.cd_atendimento
     and sa.cd_senha_master = pro.cd_senha_master
     and sa.cd_exame = pro.cd_exame
     and ta.cd_atendimento = sa.cd_atendimento
     and st.cd_senha_master = sa.cd_senha_master
     and ta.cd_paciente = pa.cd_paciente
     and sa.cd_procedimento = p.cd_procedimento
     and sa.cd_pessoa_solic = pe.cd_pessoa
     and sa.cd_atendimento = pd.cd_atendimento(+)
     and sa.nu_pedido = pd.nu_pedido(+)
     and op.cd_pessoa = pe.cd_pessoa
     and nvl(sa.fl_exame_cancelado, 'N') = 'N'
     and st.dt_fim_atendimento is null
     and exists (select /*+ FIRST_ROWS(1) */
           'x'
            from tb_protocolo_exame_sa
           where cd_atendimento = sa.cd_atendimento
             and cd_senha_master = sa.cd_senha_master
             and cd_exame = sa.cd_exame)
/

