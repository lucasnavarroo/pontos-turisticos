create view VW_USUARIOS_AERONAUTICA as
select nm_pessoa_razao_social,
         u.cd_usuario_empresa_parceira saram,
         u.cd_usuario,
         p.dt_nascimento_fundacao dt_nascimento,
         p.nu_cgc_cpf,
         p.nm_mae,
         t.cd_filial
    from tb_pessoa@hapvida p,
         tb_usuario_titular@hapvida t,
         tb_usuario@hapvida u
    where t.nu_titular = u.nu_titular
      and p.cd_pessoa  = u.cd_pessoa
      and u.fl_status_usuario+0 in (2)
      and pk_controle_aeronautica.fn_usuario_aeronautica@hapvida(u.cd_usuario,t.cd_filial) = 1

--create public synonym vw_usuarios_aeronautica for humaster.vw_usuarios_aeronautica;
--grant select on humaster.vw_usuarios_aeronautica to rl_administracao4;

-- fim sacti atendimento aeronautica ------------------------------
/

