create view VW_EXAME_PIXEON as
    select pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem na_accessionnumber,
       pr.cd_procedimento,
       at.cd_paciente,
       pa.nm_paciente,
       pa.cd_sexo,
       pa.dt_nascimento,
       null peso,
       null altura,
       null cd_med_laudo,
       null nm_med_laudo,
       null crm_laudo,
       null cd_uf_laudo,
       null nm_email_laudo,
       pem.cd_pessoa cd_med_solicitante,
       pem.nm_pessoa_razao_social nm_med_solicitante,
       prf.cd_crm_profissional crm_solicitante,
       prf.cd_uf_conselho cd_uf_solicitante,
       null nm_email_solicitante,
       po.nm_procedimento,
       po.nr_procedimento,
       pr.dt_procedimento_realizado,
       pr.hr_procedimento_realizado,
       null tipo_exame,
       null equipamento,
       pe.ds_senha_result senha,
       null ds_prestador,
       fn_dia_util(pr.dt_procedimento_realizado+1,1) dt_prev_entrega,
       null ident_exam
  from
       tb_pessoa                 pem,
       tb_prof_proced_realizado  pfp,
       tb_profissional           prf,
       tb_paciente               pa,
       tb_plano_convenio         pc,
       tb_pessoa                 ps,
       tm_convenio               co,
       tb_convenio_pagador       cp,
       tb_procedimento           po,
       tb_procedimento_realizado pr,
       tb_guia                   gu,
       tb_atendimento            at,
       tb_pedido_exame           pe
 where pe.cd_atendimento = at.cd_atendimento
   and gu.cd_atendimento = at.cd_atendimento
   and gu.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = gu.cd_atendimento
   and pr.cd_ocorrencia = gu.cd_ocorrencia
   and cp.cd_atendimento = gu.cd_atendimento
   and cp.cd_convenio_pagador = gu.cd_convenio_pagador
   and co.cd_convenio = cp.cd_convenio
   and ps.cd_pessoa = co.cd_pessoa
   and pc.cd_convenio = cp.cd_convenio
   and pc.cd_plano_convenio = cp.cd_plano
   and po.cd_procedimento = pr.cd_procedimento
   and po.fl_cirurgia = 2
   and po.fl_tipo_exame = 2
   and pa.cd_paciente = at.cd_paciente
   and at.cd_medico_atendente = pem.cd_pessoa
   and pem.cd_pessoa = pfp.cd_profissional
   and pfp.cd_atendimento = pr.cd_atendimento
   and pfp.cd_ocorrencia = pr.cd_ocorrencia
   and pfp.cd_ordem = pr.cd_ordem
   and pfp.cd_tipo_ato_profissional = 21
   and pfp.cd_profissional = prf.cd_profissional
   and pr.dt_procedimento_realizado between trunc(sysdate - 1) and trunc(sysdate)
union all
select pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem na_accessionnumber,
       pr.cd_procedimento,
       at.cd_paciente,
       pa.nm_paciente,
       pa.cd_sexo,
       pa.dt_nascimento,
       null peso,
       null altura,
       pem.cd_pessoa cd_med_laudo,
       pem.nm_pessoa_razao_social nm_med_laudo,
       prf.cd_crm_profissional crm_laudo,
       prf.cd_uf_conselho cd_uf_laudo,
       null nm_email_laudo,
       null cd_med_solicitante,
       null nm_med_solicitante,
       null crm_solicitante,
       null cd_uf_solicitante,
       null nm_email_solicitante,
       po.nm_procedimento,
       po.nr_procedimento,
       pr.dt_procedimento_realizado,
       pr.hr_procedimento_realizado,
       null tipo_exame,
       null equipamento,
       pe.ds_senha_result senha,
       null ds_prestador,
       fn_dia_util(pr.dt_procedimento_realizado+1,1) dt_prev_entrega,
       null ident_exam
  from
       tb_pessoa                 pem,
       tb_prof_proced_realizado  pfp,
       tb_profissional           prf,
       tb_paciente               pa,
       tb_plano_convenio         pc,
       tb_pessoa                 ps,
       tm_convenio               co,
       tb_convenio_pagador       cp,
       tb_procedimento           po,
       tb_procedimento_realizado pr,
       tb_guia                   gu,
       tb_atendimento            at,
       tb_pedido_exame           pe
 where pe.cd_atendimento = at.cd_atendimento
   and gu.cd_atendimento = at.cd_atendimento
   and gu.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = gu.cd_atendimento
   and pr.cd_ocorrencia = gu.cd_ocorrencia
   and cp.cd_atendimento = gu.cd_atendimento
   and cp.cd_convenio_pagador = gu.cd_convenio_pagador
   and co.cd_convenio = cp.cd_convenio
   and ps.cd_pessoa = co.cd_pessoa
   and pc.cd_convenio = cp.cd_convenio
   and pc.cd_plano_convenio = cp.cd_plano
   and po.cd_procedimento = pr.cd_procedimento
   and po.fl_cirurgia = 2
   and po.fl_tipo_exame = 2
   and pa.cd_paciente = at.cd_paciente
   and at.cd_medico_atendente = pem.cd_pessoa
   and pem.cd_pessoa = pfp.cd_profissional
   and pfp.cd_atendimento = pr.cd_atendimento
   and pfp.cd_ocorrencia = pr.cd_ocorrencia
   and pfp.cd_ordem = pr.cd_ordem
   and pfp.cd_tipo_ato_profissional = 20
   and pfp.cd_profissional = prf.cd_profissional
   and pr.dt_procedimento_realizado between trunc(sysdate - 1) and trunc(sysdate)
order by 21,1,2
/

