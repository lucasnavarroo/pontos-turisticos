create view VW_UF_HV as
select "CD_UF","NM_UF" from tb_uf@hapvida
/

