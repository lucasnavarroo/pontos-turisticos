create view VW_MOVIMENTO_TRANSACAO_CUSTO as
select
 v.cd_movimento_conta      ,
 v.dt_transacao            ,
 f.cd_filial               ,
 f.cd_empresa_organizacao  ,
 x.cd_centro_custo         ,
 c.cd_classe_tipo_operacao ,
 c.nm_classe_tipo_operacao ,
 c.fl_natureza,
 t.cd_tipo_operacao        ,
 t.nm_tipo_operacao        ,
 ot.CD_OPERACAO             ,
 o.nm_operacao             ,
 m.DT_EMISSAO_DOCUMENTO    ,
 m.CD_HISTORICO_PADRAO     ,
 LTRIM(h.DS_HISTORICO_PADRAO||' '||m.NM_HISTORICO,' ') NM_HISTORICO,
 abs(m.VL_TRANSACAO*x.vl_rateio/100*ot.vl_rateio/100) vl_transacao,
 m.CD_UM_TRANSACAO         ,
 decode(sign(m.vl_transacao),-1,decode(m.fl_lancamento,'C','D','D','C'),m.FL_LANCAMENTO) fl_lancamento,
 m.DT_ESTORNO
from tb_filial f,
     tb_historico_padrao h,
     tb_classe_tipo_operacao c,
     tb_tipo_operacao t,
     tb_operacao o,
     tm_setor s,
     tb_centro_custo_transacao x,
     tb_operacao_transacao ot,
     tm_movimento_transacao m,
     tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta and
   ot.cd_movimento_conta = m.cd_movimento_conta and
   ot.cd_ordem_transacao = m.cd_ordem_transacao and
   x.cd_movimento_conta = m.cd_movimento_conta and
   x.cd_ordem_transacao = m.cd_ordem_transacao and
   s.cd_setor = x.cd_centro_custo and
   o.cd_operacao = ot.cd_operacao and
   t.cd_tipo_operacao = o.cd_tipo_operacao and
   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao and
   c.cd_classe_tipo_operacao not in ('13','70') and
   h.cd_historico_padrao(+)=m.cd_historico_padrao and
   f.cd_filial(+) = s.cd_setor_emp
/

