create view VW_ITENS_KIT_AGEND_ATO_FECH as
SELECT /*
          Fred Monteiro - IVIA - 18/06/2018
          View que recupera os itens do ato de fechamento dos procedimentos de maior porte anestesico do agendamento
       */
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        MAX(a.qt_produto) qt_produto,
        MAX(a.qt_pediatria) qt_pediatria,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
        a.qt_kit_reduzido,
        a.cd_faixa
    FROM
        vw_itens_kit_agenda_n2 a -- materiais de dispensacao dos procedimentos que foram agendados,responsaveis,ato cirurgico e pediatria
    WHERE
            1 = 1
        AND
            a.cd_ato_cirurgico = 4
   -- maior porte anestesico
        AND
            a.cd_porte_anestesia = (
                SELECT
                    MAX(b.cd_porte_anestesia)
                FROM
                    vw_itens_kit_agenda_n2 b
                WHERE
                        1 = 1
                    AND
                        b.cd_agenda = a.cd_agenda
            )
    GROUP BY
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
        a.qt_kit_reduzido,
        a.cd_faixa
/

