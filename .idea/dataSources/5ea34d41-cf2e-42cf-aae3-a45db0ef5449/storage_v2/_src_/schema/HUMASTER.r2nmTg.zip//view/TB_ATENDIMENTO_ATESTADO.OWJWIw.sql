create view TB_ATENDIMENTO_ATESTADO as
select "NU_ATENDIMENTO","QT_DIAS","DT_INICIAL","FL_TRANSCRICAO" from tb_atendimento_atestado@hapvida
/

