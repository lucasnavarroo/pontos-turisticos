create view VW_TAXA_MAT_MED as
    select  cd_taxas CODIGO ,nm_taxas PRODUTO,'TAXA' TIPO
from   tb_taxas
union all
select substr(to_char(cd_mat_med),1,8) CODIGO,nm_mat_med PRODUTO,'MATMED' TIPO
from tb_mat_med
/

