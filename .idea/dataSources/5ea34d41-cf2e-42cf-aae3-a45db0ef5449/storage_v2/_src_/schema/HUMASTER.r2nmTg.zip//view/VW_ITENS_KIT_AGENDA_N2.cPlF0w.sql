create view VW_ITENS_KIT_AGENDA_N2 as
select a.cd_agenda,
       a.dt_agenda,
       a.dt_nascimento,
       a.cd_paciente,
       a.idade_meses,
       a.cd_param_grupo_proc,
       a.cd_procedimento,
       a.cd_porte_anestesia,
       a.cd_material,
       a.qt_produto qt_produto,
       null qt_pediatria,
       null cd_faixa,
       p.cd_ato_cirurgico,
       p.cd_profissional cd_responsavel,
       a.id_kit,
       a.cd_setor_controle,
       a.qt_kit_reduzido
  from  TB_PARAM_MATERIAL          p,
       vw_itens_kit_agenda_n1     a   -- materiais de dispensacao dos procedimentos que foram agendados
 where 1 = 1
   -- vigencia do ato
  /* and a.dt_agenda between nvl(aa.dt_ini_vigencia, a.dt_agenda) and nvl(aa.dt_fin_vigencia, a.dt_agenda)
   -- vigencia do responsavel
   and a.dt_agenda between nvl(ab.dt_ini_vigencia, a.dt_agenda) and nvl(ab.dt_fin_vigencia, a.dt_agenda
   -- join a -- aa
   and a.cd_procedimento_pai = aa.cd_procedimento(+)
   and a.cd_material         = aa.cd_material(+)
   -- join a -- ab
   and a.cd_procedimento_pai = ab.cd_procedimento(+)*/
   and a.cd_material         = p.cd_material(+)
/

