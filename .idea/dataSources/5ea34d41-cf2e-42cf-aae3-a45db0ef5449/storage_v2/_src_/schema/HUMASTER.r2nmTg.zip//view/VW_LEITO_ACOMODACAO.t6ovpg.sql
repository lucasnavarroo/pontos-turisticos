create view VW_LEITO_ACOMODACAO as
    select aa.cd_posto,
       aa.cd_acomodacao,
       aa.nu_leito,
       s.cd_setor_emp filial,
       (select c.ds_status
        from tb_status_leito_acomodacao c
        where c.cd_status = aa.cd_status) cd_status,
       a.cd_atendimento,
       (select t.nm_paciente
        from tm_atendimento b,
             tb_paciente t
        where b.cd_paciente = t.cd_paciente
          and b.cd_atendimento = a.cd_atendimento) nm_paciente,
       (select v.nm_convenio||' - '||v.ds_plano_convenio nm_convenio
        from vw_convenio_pagador v
        where v.cd_atendimento = a.cd_atendimento
          and v.cd_convenio_pagador = 1) nm_convenio,
       a.dt_ocupacao,
       aa.dt_status
from  tm_setor s,
      tb_ocupacao_acomodacao a,
      tb_leito_acomodacao aa
where aa.cd_acomodacao = a.cd_acomodacao
  and aa.cd_posto = s.cd_setor
  and aa.cd_posto = a.cd_posto
  and aa.nu_leito = a.nu_leito
  and aa.cd_status = 'O'
  and a.fl_ocupacao = 'S'
  and a.dt_liberacao is null
union
select aa.cd_posto,
       aa.cd_acomodacao,
       aa.nu_leito,
       s.cd_setor_emp filial,
       (select c.ds_status
        from tb_status_leito_acomodacao c
        where c.cd_status = aa.cd_status) cd_status,
       null cd_atendimento,
       null nm_paciente,
       null nm_convenio,
       null dt_ocupacao,
       aa.dt_status
from tm_setor s,
     tb_leito_acomodacao aa
where aa.cd_posto = s.cd_setor
  and aa.cd_status != 'O'
order by 2,3
/

