create view VW_EXAMES_LAB_RESULTADOS as
    select PR.CD_ATENDIMENTO, PR.CD_OCORRENCIA, PR.CD_ORDEM, RP.SQ_RESULTADO, PREF.DS_PARAMETRO_REFERENCIA, RP.DS_RESULTADO_PROCEDIMENTO, UU.NR_UNIDADE_USUAL,
       PREF.DS_PARAMETRO_REFERENCIA DS_REFERENCIA,
       --DECODE(PREF.DS_PARAMETRO_REFERENCIA,'RESULTADO',P.NM_PROCEDIMENTO,PREF.DS_PARAMETRO_REFERENCIA) DS_REFERENCIA,
      (RP.DS_RESULTADO_PROCEDIMENTO || ' ' || UU.NR_UNIDADE_USUAL|| ' (' ||FN_VALOR_PARAMETRO(pr.cd_procedimento, pr.cd_metodo_realizado, rp.cd_parametro_referencia,pr.cd_atendimento,pr.cd_ocorrencia,pr.cd_ordem,pr.dt_resultado) || ')' ) DS_RESULTADO,
       pr.cd_procedimento,2 CD_ORDEM_APRESENTACAO
from humaster.tb_procedimento_realizado pr,
     humaster.tb_resultado_procedimento rp,
     humaster.tb_procedimento p,
     humaster.tb_unidade_usual uu,
     humaster.tb_parametro_referencia pref
where pr.dt_libera_laudo is not null
  and rp.cd_atendimento      = pr.cd_atendimento
  and rp.cd_ocorrencia       = pr.cd_ocorrencia
  and rp.cd_ordem            = pr.cd_ordem
  and p.fl_tipo_exame       in (0,1)
  and p.fl_cirurgia          = 2
  and p.cd_procedimento      = pr.cd_procedimento
  and uu.cd_unidade_usual    = rp.cd_unidade_usual
  and pref.cd_parametro_referencia = rp.cd_parametro_referencia
union all
select PR.CD_ATENDIMENTO, PR.CD_OCORRENCIA, PR.CD_ORDEM, DE.NU_SEQ_DIAGNOSTICO, ' ' DS_PARAMETRO_REFERENCIA,
       ' ' DS_RESULTADO_PROCEDIMENTO, ' ' NR_UNIDADE_USUAL,
       ' ' DS_REFERENCIA,
       --DECODE(PREF.DS_PARAMETRO_REFERENCIA,'RESULTADO',P.NM_PROCEDIMENTO,PREF.DS_PARAMETRO_REFERENCIA) DS_REFERENCIA,
       DE.DS_DIAGNOSTICO_EXAME DS_RESULTADO,
       pr.cd_procedimento,3 CD_ORDEM_APRESENTACAO
from humaster.tb_procedimento_realizado pr,
     humaster.tb_diagnostico_exame de,
     humaster.tb_procedimento p
where pr.dt_libera_laudo is not null
  and de.cd_atendimento      = pr.cd_atendimento
  and de.cd_ocorrencia       = pr.cd_ocorrencia
  and de.cd_ordem            = pr.cd_ordem
  and p.fl_tipo_exame       in (0,1)
  and p.fl_cirurgia          = 2
  and p.cd_procedimento      = pr.cd_procedimento
/

