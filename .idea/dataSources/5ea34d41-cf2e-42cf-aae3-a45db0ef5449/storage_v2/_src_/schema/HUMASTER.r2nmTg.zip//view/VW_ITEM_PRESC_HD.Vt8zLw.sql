create view VW_ITEM_PRESC_HD as
select pp.cd_atendimento,
        pp.cd_ocorrencia_plano,
        pp.cd_ordem_prescricao,
        pp.cd_ordem_prescricao_plano,
        pp.cd_prescricao_plano_pai,
        pp.nu_produto,
        pp.cd_mat_med,
        pp.qt_dosagem,
        pp.cd_unidade_usual,
        pp.qt_frequencia_uso,
        pp.fl_frequencia_uso,
        pp.cd_tipo_acesso,
        pp.fl_bomba_infusao,
        pp.fl_necessario,
        pp.fl_acm,
        pp.fl_bureta,
        pp.ds_observacao,
        pp.qt_reconstituicao,
        pp.cd_diluente,
        pp.qt_diluicao,
        pp.qt_gotejamento,
        pp.cd_gotejamento,
        pp.qt_tempo_gotej,
        pp.cd_unidade_gotej,
        pp.fl_validado,
        pp.fl_status_uso,
        pp.fl_carro_parada_c,
        prd.cd_unidade_padrao cd_unid_dosagem_calc,
        nvl(mat.fl_alta_vigilancia, 'N') fl_alta_vigilancia,
        nvl(mat.fl_controlado, 'N') fl_controlado,
        pp.ds_apres_ud_fazer_retirar,
        val.nm_pessoa_razao_social nm_validador,
        presc.nm_pessoa_razao_social nm_prescritor,
        canc.nm_pessoa_razao_social nm_cancelador
   from tb_prescricao_plano pp,
        tb_produto          prd,
        tb_material         mat,
        tb_pessoa           val,
        tb_pessoa           presc,
        tb_pessoa           canc
  where pp.cd_mat_med = mat.cd_material
    and pp.nu_produto = prd.nu_produto(+)
    and pp.cd_tipo_prescricao_plano = 4
    and pp.cd_profissional_valida = val.cd_pessoa(+)
    and pp.cd_profissional_prescreve = presc.cd_pessoa(+)
    and pp.cd_profissional_cancela = canc.cd_pessoa(+)
  order by decode(pp.cd_tipo_prescricao_plano,
                  2,
                  nvl(pp.nu_ordem_apresentacao, 999),
                  999),
           decode(pp.cd_prescricao_plano_pai,
                  null,
                  pp.cd_ordem_prescricao_plano,
                  pp.cd_prescricao_plano_pai),
           pp.cd_ordem_prescricao_plano
/

