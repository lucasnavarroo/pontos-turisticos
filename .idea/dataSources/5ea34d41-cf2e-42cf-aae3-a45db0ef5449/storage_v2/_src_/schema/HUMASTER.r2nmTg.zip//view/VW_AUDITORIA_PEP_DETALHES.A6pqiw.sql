create view VW_AUDITORIA_PEP_DETALHES as
SELECT DISTINCT TO_DATE(to_char(DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO, CD_ACAO, CD_OPERADOR2 CD_OPERADOR, ID_SESSION, CD_ATENDIMENTO, NU_PRESCRICAO_MEDICA, DETALHE, ATIVIDADE, CD_TERMINAL
FROM (

-- ********************************************************************************* ACESSOS
      SELECT AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, NULL CD_ATENDIMENTO, NULL NU_PRESCRICAO_MEDICA,
             UPPER(DECODE(CD_FILIAL,NULL, DECODE(CD_PAPEL,NULL, '','PAPEL: ' || (SELECT NM_PAPEL FROM TB_PAPEL P WHERE P.CD_PAPEL = AC.CD_PAPEL)),'FILIAL: ' || (SELECT P.NM_FANTASIA FROM TB_FILIAL F, TB_PESSOA P WHERE F.CD_FILIAL = AC.CD_FILIAL AND P.CD_PESSOA = F.CD_PESSOA))) DETALHE,
             DECODE(NVL(upper(ac.cd_tela),''),'','','TELA: ' || upper(ac.cd_tela) || '  ' || CHR(13)) ||
             DECODE(NVL(upper(ac.nm_atividade),''),'','','ATIVIDADE: ' || upper(ac.nm_atividade) || CHR(13)) ATIVIDADE,
             AC.CD_TERMINAL
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA
      WHERE AC.CD_ACAO      IN (1,2,3,4,5,6) AND
            AC.CD_ACAO      = AA.CD_ACAO
      UNION
-- ********************************************************************************* PRESCRICAO
      SELECT AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA,
             P.NM_PACIENTE DETALHE,
             'PESO: ' || PM.QT_PESO_KG_REGISTRADO ATIVIDADE,
             AC.CD_TERMINAL
      FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_MEDICA PM, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO      IN (11,12,13) AND
            AC.CD_ACAO       = PM.CD_ACAO AND
            AC.CD_OPERADOR2  = PM.CD_OPERADOR AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            AC.ID_SESSION    = PM.ID_SESSION AND
            A.CD_ATENDIMENTO = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE    = A.CD_PACIENTE
      UNION
-- ********************************************************************************* MEDICAMENTOS
      SELECT AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA,
             P.NM_PACIENTE DETALHE,
             'CD_MAT_MED: ' || MM.CD_MAT_MED  ||  CHR(13) ||
             'NM_MAT_MED: ' || MM.NM_MAT_MED  ||  CHR(13) ||
             'QT_DOSAGEM: ' || PP.QT_DOSAGEM  ||  ' ' || PP.CD_UNIDADE_USUAL  ||  CHR(13) ||
             'QT_MAT_MED: ' || PP.QT_MAT_MED  ||  CHR(13) ||
             'FL_ACM: ' || PP.FL_ACM  ||  CHR(13) ||
             'FL_NECESSARIO: ' || PP.FL_NECESSARIO  ||  CHR(13) ||
             'FL_BOMBA_INFUSAO: ' || PP.FL_BOMBA_INFUSAO  ||  CHR(13)
             ATIVIDADE,
             AC.CD_TERMINAL
        FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_PLANO PP, TB_ACOES_AUDITORIA AA, TB_PRESCRICAO_MEDICA PM, TB_PACIENTE P, TB_ATENDIMENTO A, TB_MAT_MED MM
        WHERE AC.CD_ACAO      IN (14,15,26,27,28,29) AND
              AC.CD_ACAO      = PP.CD_ACAO AND
              AC.CD_OPERADOR2 = PP.CD_OPERADOR AND
              ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--              to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
              AC.ID_SESSION   = PP.ID_SESSION AND
              AA.CD_ACAO      = PP.CD_ACAO AND
              PM.CD_ATENDIMENTO = PP.CD_ATENDIMENTO AND
              PM.CD_OCORRENCIA_PLANO = PP.CD_OCORRENCIA_PLANO AND
              PM.CD_ORDEM_PRESCRICAO = PP.CD_ORDEM_PRESCRICAO AND
              A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
              P.CD_PACIENTE          = A.CD_PACIENTE AND
              MM.CD_MAT_MED          = PP.CD_MAT_MED

        UNION
-- ********************************************************************************* PROCEDIMENTOS
      SELECT DT_ACAO, CD_ACAO, CD_OPERADOR2, ID_SESSION, CD_ATENDIMENTO, NU_PRESCRICAO_MEDICA, DETALHE, ATIVIDADE, CD_TERMINAL
      FROM  (SELECT distinct AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, P.NM_PACIENTE DETALHE,
                   'CD_PROCEDIMENTO: ' || PPU.CD_PROCEDIMENTO  ||  CHR(13) ||
                   'NM_PROCEDIMENTO: ' || upper(PPU.NM_PROCEDIMENTO)  ||  CHR(13) ||
                   'QT_PROCEDIMENTO: ' || PPU.QT_PROCEDIMENTO  ||  ' ' || PPU.CD_UNIDADE_USUAL  ||  CHR(13) ||
                   'FL_ACM: ' || PPU.FL_ACM  ||  CHR(13) ||
                   'FL_NECESSARIO: ' || PPU.FL_NECESSARIO  ||  CHR(13)
                   ATIVIDADE,
                   AC.CD_TERMINAL,
                   PPU.CD_ORDEM_PROC_PLANO_USO, NVL(PPU.CD_PROC_PLANO_PAI, PPU.CD_ORDEM_PROC_PLANO_USO) ORDEM
              FROM TB_AUDIT_ACOES AC, AU_PROCEDIMENTO_PLANO_USO PPU, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
              WHERE AC.CD_ACAO             IN (16,17) AND
                    AC.CD_ACAO             = PPU.CD_ACAO AND
                    AC.CD_OPERADOR2        = PPU.CD_OPERADOR AND
                    AC.ID_SESSION          = PPU.ID_SESSION AND
                    ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--                    to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
                    PM.CD_ATENDIMENTO      = PPU.CD_ATENDIMENTO AND
                    PM.CD_OCORRENCIA_PLANO = PPU.CD_OCORRENCIA_PLANO AND
                    PM.CD_ORDEM_PRESCRICAO = PPU.CD_ORDEM_PRESCRICAO AND
                    AA.CD_ACAO             = PPU.CD_ACAO AND
                    A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
                    P.CD_PACIENTE          = A.CD_PACIENTE AND
                    PPU.CD_PROC_PLANO_PAI  IS NULL
              UNION
              SELECT distinct AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, P.NM_PACIENTE DETALHE,
                     '*** ITEM DO PROCEDIMENTO: ' || NVL((SELECT upper(PPU3.NM_PROCEDIMENTO) FROM AU_PROCEDIMENTO_PLANO_USO PPU3 WHERE PPU3.CD_ATENDIMENTO = PPU.CD_ATENDIMENTO AND PPU3.CD_OCORRENCIA_PLANO = PPU.CD_OCORRENCIA_PLANO AND PPU3.CD_ORDEM_PRESCRICAO = PPU.CD_ORDEM_PRESCRICAO AND PPU3.CD_ORDEM_PROC_PLANO_USO = PPU.CD_PROC_PLANO_PAI),'')  || ' ***' || CHR(13) ||
                     'CD_PROCEDIMENTO: ' || PPU.CD_PROCEDIMENTO  ||  CHR(13) ||
                     'NM_PROCEDIMENTO: ' || upper(PPU.NM_PROCEDIMENTO)  ||  CHR(13) ||
                     'QT_PROCEDIMENTO: ' || PPU.QT_PROCEDIMENTO  ||  ' ' || PPU.CD_UNIDADE_USUAL  ||  CHR(13) ||
                     'FL_ACM: ' || PPU.FL_ACM  ||  CHR(13) ||
                     'FL_NECESSARIO: ' || PPU.FL_NECESSARIO  ||  CHR(13)
                     ATIVIDADE,
                     AC.CD_TERMINAL,
                     PPU.CD_ORDEM_PROC_PLANO_USO, NVL(PPU.CD_PROC_PLANO_PAI, PPU.CD_ORDEM_PROC_PLANO_USO) ORDEM
              FROM TB_AUDIT_ACOES AC, AU_PROCEDIMENTO_PLANO_USO PPU, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
              WHERE AC.CD_ACAO             IN (16,17) AND
                    AC.CD_ACAO             = PPU.CD_ACAO AND
                    AC.CD_OPERADOR2        = PPU.CD_OPERADOR AND
                    AC.ID_SESSION          = PPU.ID_SESSION AND
                    ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--                    to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
                    PM.CD_ATENDIMENTO      = PPU.CD_ATENDIMENTO AND
                    PM.CD_OCORRENCIA_PLANO = PPU.CD_OCORRENCIA_PLANO AND
                    PM.CD_ORDEM_PRESCRICAO = PPU.CD_ORDEM_PRESCRICAO AND
                    AA.CD_ACAO             = PPU.CD_ACAO AND
                    A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
                    P.CD_PACIENTE          = A.CD_PACIENTE AND
                    PPU.CD_PROC_PLANO_PAI  IS NOT NULL
           ORDER BY ORDEM, CD_ORDEM_PROC_PLANO_USO)

      UNION
-- ********************************************************************************* HIDRATACAO VENOSA
      SELECT DT_ACAO, CD_ACAO, CD_OPERADOR2, ID_SESSION, CD_ATENDIMENTO, NU_PRESCRICAO_MEDICA, DETALHE, ATIVIDADE, CD_TERMINAL
        FROM (SELECT  AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PP.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, PP.CD_ORDEM_PRESCRICAO, PP.CD_ORDEM_HV,
                      P.NM_PACIENTE DETALHE,
                      'CD_MAT_MED: ' || MM.CD_MAT_MED  ||  CHR(13) ||
                      'NM_MAT_MED: ' || MM.NM_MAT_MED  ||  CHR(13) ||
                      'QT_DOSAGEM: ' || PP.QT_DOSAGEM  ||  ' ' || PP.CD_UNIDADE_USUAL  ||  CHR(13) ||
                      'QT_MAT_MED: ' || PP.QT_MAT_MED  ||  CHR(13) ||
                      'FL_ACM: ' || PP.FL_ACM  ||  CHR(13) ||
                      'FL_NECESSARIO: ' || PP.FL_NECESSARIO  ||  CHR(13) ||
                      'FL_BOMBA_INFUSAO: ' || PP.FL_BOMBA_INFUSAO  ||  CHR(13)
                      ATIVIDADE,
                      AC.CD_TERMINAL, 2 ORDEM
                 FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_PLANO PP, TB_ACOES_AUDITORIA AA, TB_PRESCRICAO_MEDICA PM, TB_PACIENTE P, TB_ATENDIMENTO A, TB_MAT_MED MM
                 WHERE AC.CD_ACAO      IN (28,29) AND --(14,15,26,27,28,29) AND
                       AC.CD_ACAO      = PP.CD_ACAO AND
                       AC.CD_OPERADOR2 = PP.CD_OPERADOR AND
                       ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--                       to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
                       AC.ID_SESSION   = PP.ID_SESSION AND
                       AA.CD_ACAO      = PP.CD_ACAO AND
                       PM.CD_ATENDIMENTO = PP.CD_ATENDIMENTO AND
                       PM.CD_OCORRENCIA_PLANO = PP.CD_OCORRENCIA_PLANO AND
                       PM.CD_ORDEM_PRESCRICAO = PP.CD_ORDEM_PRESCRICAO AND
                       A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
                       P.CD_PACIENTE          = A.CD_PACIENTE AND
                       MM.CD_MAT_MED          = PP.CD_MAT_MED AND
                       EXISTS (SELECT CD_ORDEM_HV
                                 FROM AU_PRESCRICAO_MEDICA_HV PMH
                                WHERE PMH.CD_ATENDIMENTO      = PP.CD_ATENDIMENTO AND
                                      PMH.CD_OCORRENCIA_PLANO = PP.CD_OCORRENCIA_PLANO AND
                                      PMH.CD_ORDEM_PRESCRICAO = PP.CD_ORDEM_PRESCRICAO AND
                                      PMH.CD_ORDEM_HV         = PP.CD_ORDEM_HV)
               UNION
               SELECT  AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PP.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, PP.CD_ORDEM_PRESCRICAO, PP.CD_ORDEM_HV,
                      P.NM_PACIENTE DETALHE,
                      'VOLUME TOTAL: ' || NVL(PMH.VOLUME_TOTAL,'')  ||  ' ML'  || CHR(13) ||
                      'TIPO ACESSO: ' || DECODE(NVL(PMH.CD_TIPO_ACESSO_INFUSAO,''),'','','P','PERIFÉRICO','C','CENTRAL')  || CHR(13) ||
                      'GOTEJAMENTO: ' || PMH.QT_GOTEJAMENTO || ' ' || NVL((SELECT UPPER(G.NM_GOTEJAMENTO) FROM TB_GOTEJAMENTO G WHERE CD_GOTEJAMENTO = NVL(PMH.CD_GOTEJAMENTO,0)),'')  || CHR(13) ||
                      'TIPO DE FASE: ' || DECODE(PMH.CD_TIPO_FASE,'U','ÚNICA','R','RÁPIDA',PMH.CD_TIPO_FASE) ||  CHR(13) ||
                      DECODE(NVL(PMH.QT_TEMPO_FASE_RAPIDA,''),'','',
                      'TEMPO FASE RÁPIDA: ' || NVL(PMH.QT_TEMPO_FASE_RAPIDA,'') || ' ' || NVL(PMH.CD_UNID_TEMPO_FASE_RAPIDA,'') || CHR(13)) ||
                      'VIG: ' || NVL(PMH.VIG,'')  ||  CHR(13) ||
                      'FL_ACM: ' || PMH.FL_ACM  ||  CHR(13) ||
                      'FL_NECESSARIO: ' || PMH.FL_NECESSARIO  ||  CHR(13) ||
                      'FL_BOMBA_INFUSAO: ' || PMH.FL_BOMBA_INFUSAO  ||  CHR(13)
                      ATIVIDADE,
                      AC.CD_TERMINAL, 1 ORDEM
                 FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_PLANO PP, TB_ACOES_AUDITORIA AA, TB_PRESCRICAO_MEDICA PM, TB_PACIENTE P, TB_ATENDIMENTO A, AU_PRESCRICAO_MEDICA_HV PMH
                 WHERE AC.CD_ACAO              IN (28,29) AND
                       AC.CD_ACAO              = PP.CD_ACAO AND
                       AC.CD_OPERADOR2         = PP.CD_OPERADOR AND
                       ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--                       to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
                       AC.ID_SESSION           = PP.ID_SESSION AND
                       AA.CD_ACAO              = PP.CD_ACAO AND
                       PM.CD_ATENDIMENTO       = PP.CD_ATENDIMENTO AND
                       PM.CD_OCORRENCIA_PLANO  = PP.CD_OCORRENCIA_PLANO AND
                       PM.CD_ORDEM_PRESCRICAO  = PP.CD_ORDEM_PRESCRICAO AND
                       A.CD_ATENDIMENTO        = PM.CD_ATENDIMENTO AND
                       P.CD_PACIENTE           = A.CD_PACIENTE AND
                       PMH.CD_ATENDIMENTO      = PP.CD_ATENDIMENTO AND
                       PMH.CD_OCORRENCIA_PLANO = PP.CD_OCORRENCIA_PLANO AND
                       PMH.CD_ORDEM_PRESCRICAO = PP.CD_ORDEM_PRESCRICAO AND
                       PMH.CD_ORDEM_HV         = PP.CD_ORDEM_HV
              ORDER BY DT_ACAO, CD_ACAO, CD_OPERADOR2, CD_ORDEM_HV, ORDEM)
      UNION
-- ********************************************************************************* DIETAS
      SELECT DT_ACAO, CD_ACAO, CD_OPERADOR2, ID_SESSION, CD_ATENDIMENTO, NU_PRESCRICAO_MEDICA, DETALHE, ATIVIDADE, CD_TERMINAL
      FROM (SELECT distinct AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, P.NM_PACIENTE DETALHE,
                     'CD_DIETA: ' || DP.CD_DIETA         ||  CHR(13) ||
                     'NM_DIETA: ' || upper(D.NM_DIETA)   ||  CHR(13) ||
                     'QT_DIETA: ' || DP.QT_DIETA         ||  CHR(13)
                     ATIVIDADE,
                     AC.CD_TERMINAL,
                     DP.QT_DIETA ORDEM
                FROM TB_AUDIT_ACOES AC, au_dieta_paciente DP, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A, TB_DIETA D
               WHERE AC.CD_ACAO             IN (18,19) AND
                     AC.CD_ACAO             = DP.CD_ACAO AND
                     AC.CD_OPERADOR2        = DP.CD_OPERADOR AND
                     AC.ID_SESSION          = DP.ID_SESSION AND
                     ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
                     PM.CD_ATENDIMENTO      = DP.CD_ATENDIMENTO AND
                     PM.CD_OCORRENCIA_PLANO = DP.CD_OCORRENCIA_PLANO AND
                     PM.CD_ORDEM_PRESCRICAO = DP.CD_ORDEM_PRESCRICAO AND
                     AA.CD_ACAO             = DP.CD_ACAO AND
                     A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
                     P.CD_PACIENTE          = A.CD_PACIENTE AND
                     D.CD_DIETA             = DP.CD_DIETA
               UNION
              SELECT distinct AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, PM.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, P.NM_PACIENTE DETALHE,
                     'CD_MAT_MED: ' || MM.CD_MAT_MED         ||  CHR(13) ||
                     'NM_MAT_MED: ' || upper(MM.NM_MAT_MED)   ||  CHR(13)
                     ATIVIDADE,
                     AC.CD_TERMINAL,
                     10000 ORDEM
                FROM TB_AUDIT_ACOES AC, au_dieta_paciente DP, TB_PRESCRICAO_MEDICA PM,
                     TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A,
                     tb_composicao_dieta_paciente CDP, TB_MAT_MED MM
               WHERE AC.CD_ACAO             IN (18,19) AND
                     AC.CD_ACAO              = DP.CD_ACAO AND
                     AC.CD_OPERADOR2         = DP.CD_OPERADOR AND
                     AC.ID_SESSION           = DP.ID_SESSION AND
                     ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
                     PM.CD_ATENDIMENTO       = DP.CD_ATENDIMENTO AND
                     PM.CD_OCORRENCIA_PLANO  = DP.CD_OCORRENCIA_PLANO AND
                     PM.CD_ORDEM_PRESCRICAO  = DP.CD_ORDEM_PRESCRICAO AND
                     AA.CD_ACAO              = DP.CD_ACAO AND
                     A.CD_ATENDIMENTO        = PM.CD_ATENDIMENTO AND
                     P.CD_PACIENTE           = A.CD_PACIENTE AND
                     CDP.CD_ATENDIMENTO      = DP.CD_ATENDIMENTO AND
                     CDP.CD_OCORRENCIA_PLANO = DP.CD_OCORRENCIA_PLANO AND
                     CDP.CD_ORDEM_PRESCRICAO = DP.CD_ORDEM_PRESCRICAO AND
                     CDP.CD_ORDEM_DIETA      = DP.CD_ORDEM_DIETA AND
                     MM.CD_MAT_MED           = CDP.CD_MAT_MED
            ORDER BY ORDEM)
-- ********************************************************************************* MAPA NUTRICAO
      UNION
      SELECT AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, AC.CD_ATIVIDADE CD_ATENDIMENTO, NULL NU_PRESCRICAO_MEDICA,
             PACIE.NM_PACIENTE DETALHE,
             DECODE(NVL(upper(ac.cd_tela),''),'','','TELA: ' || upper(ac.cd_tela) || '  ' || CHR(13)) ||
             DECODE(NVL(upper(ac.nm_atividade),''),'','','ATIVIDADE: ' || upper(ac.nm_atividade) || CHR(13)) ATIVIDADE,
             AC.CD_TERMINAL
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA, TB_ATENDIMENTO A, TB_PACIENTE PACIE
      WHERE AC.CD_ACAO      IN (31,32) AND
            AC.CD_ACAO      = AA.CD_ACAO AND
            A.CD_ATENDIMENTO = AC.CD_ATIVIDADE AND
            PACIE.CD_PACIENTE  = A.CD_PACIENTE
      UNION
      SELECT AC.DT_ACAO, AC.CD_ACAO, AC.CD_OPERADOR2, AC.ID_SESSION, NULL CD_ATENDIMENTO, NULL NU_PRESCRICAO_MEDICA,
             UPPER(DECODE(CD_FILIAL,NULL, DECODE(CD_PAPEL,NULL, '','PAPEL: ' || (SELECT NM_PAPEL FROM TB_PAPEL P WHERE P.CD_PAPEL = AC.CD_PAPEL)),'FILIAL: ' || (SELECT P.NM_FANTASIA FROM TB_FILIAL F, TB_PESSOA P WHERE F.CD_FILIAL = AC.CD_FILIAL AND P.CD_PESSOA = F.CD_PESSOA))) DETALHE,
             DECODE(NVL(upper(ac.cd_tela),''),'','','TELA: ' || upper(ac.cd_tela) || '  ' || CHR(13)) ||
             DECODE(NVL(upper(ac.nm_atividade),''),'','','ATIVIDADE: ' || upper(ac.nm_atividade) || CHR(13)) ATIVIDADE,
             AC.CD_TERMINAL
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA
      WHERE AC.CD_ACAO      = 30 AND
            AC.CD_ACAO      = AA.CD_ACAO )
ORDER BY ID_SESSION, DT_ACAO
/

