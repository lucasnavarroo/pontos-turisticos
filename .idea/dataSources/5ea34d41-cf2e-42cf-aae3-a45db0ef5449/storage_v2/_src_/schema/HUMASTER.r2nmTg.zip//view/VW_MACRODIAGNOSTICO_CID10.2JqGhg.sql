create view VW_MACRODIAGNOSTICO_CID10 as
select mcid.cd_macrodiag_cid10, mcid.nm_macrodiag_cid10
     from tb_macrodiag_cid10 mcid
/

