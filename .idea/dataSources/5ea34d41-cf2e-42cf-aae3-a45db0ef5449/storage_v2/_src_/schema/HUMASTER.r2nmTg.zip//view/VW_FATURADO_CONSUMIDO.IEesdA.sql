create view VW_FATURADO_CONSUMIDO as
    with vw_consumidos as
   (select f.cd_filial cd_filial,
           f.nm_fantasia nm_filial,
           s.cd_setor cd_setor_origem,
           s.nm_setor nm_setor_origem,
           e.cd_setor_destino cd_setor_destino,
           s1.nm_setor nm_setor_destino,
           sum(e.qt_material * decode(m.fl_fragmenta, 'S', nvl(m.qt_conteudo_armaz, 1), 1)) qt_consumido,
           round(sum(e.qt_material * sah.fu_custo_mat_med_filial(e.cd_material,
                                                                 trunc(e.dt_transacao),
                                                                 s.cd_setor_emp)),
                 2) vl_consumido
      from vw_filial f,
           tm_setor s1,
           tm_setor s,
           tb_material m,
           tb_tipo_classificacao tc,
           tb_classificacao c,
           (select 2 cd_tipo,
                   'REQ' cd_doc,
                   aa.cd_requisicao cd_nota,
                   '' nr_fornecedor,
                   aa.cd_setor_controle cd_setor_controle,
                   aa.cd_setor_destino cd_setor_destino,
                   aa.dt_emissao dt_emissao,
                   a.cd_material cd_material,
                   nvl(a.qt_material_c + a.qt_material_n, 0) qt_material,
                   nvl(a.vl_material_c, 0) vl_material,
                   nvl(aa.dt_transacao, aa.dt_emissao) dt_transacao,
                   aaa.cd_setor_emp empresa,
                   0 qt_contada,
                   aa.cd_usuario cd_usuario,
                   aa.nu_comanda nu_comanda,
                   a.cd_lote cd_lote,
                   a.dt_validade_lote dt_validade_lote,
                   0 nu_seq_nota,
                   aa.fl_status fl_status,
                   aa.id_kit id_kit,
                   aa.fl_perda_outros fl_perdas,
                   aa.nu_protocolo nu_protocolo
              from tm_setor           aaa,
                   tm_requisicao      aa,
                   tb_item_requisicao a
             where 1 = 1
                  -- Filtros
               and a.fl_status_item in (1, 2, 3)
               and aa.dt_transacao between
                   (select to_date(t.cd_filtro || ' 00:00:00',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 6
                       and t.nm_operador = fn_user)
               and (select to_date(t.cd_filtro || ' 23:59:59',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 7
                       and t.nm_operador = fn_user)
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 1
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 1
                        and t.cd_filtro = aaa.cd_setor_emp
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 2
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 2
                        and t.cd_filtro = aa.cd_setor_controle
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 3
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 3
                        and t.cd_filtro = aa.cd_setor_destino
                        and t.nm_operador = fn_user))
               and exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 4
                        and t.cd_filtro = to_char(a.cd_material)
                        and t.nm_operador = fn_user)
               and aaa.fl_controla = 'S'
               and aaa.fl_estoque_proprio = 'S'
                  -- Joins
                  -- a -- aa
               and aa.cd_requisicao = a.cd_requisicao
                  -- aa -- aaa
               and aaa.cd_setor = aa.cd_setor_controle
            union all
            select 3,
                   'DEV',
                   aa.cd_devolucao,
                   '',
                   aa.cd_setor_controle,
                   aa.cd_setor_destino,
                   aa.dt_emissao,
                   a.cd_material,
                   nvl(a.qt_material, 0) * -1,
                   nvl(a.vl_material, 0),
                   nvl(aa.dt_transacao, aa.dt_emissao) dt_transacao,
                   aaa.cd_setor_emp empresa,
                   0 qt_contada,
                   aa.cd_usuario,
                   aa.nu_comanda,
                   a.cd_lote,
                   a.dt_validade_lote,
                   0 nu_seq_nota,
                   aa.fl_status,
                   null id_kit,
                   'N' fl_perdas,
                   aa.nu_protocolo
              from tm_setor          aaa,
                   tm_devolucao      aa,
                   tb_item_devolucao a
             where 1 = 1
                  -- Filtros
               and a.fl_status_item in (1, 2, 3)
               and aa.dt_transacao between
                   (select to_date(t.cd_filtro || ' 00:00:00',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 6
                       and t.nm_operador = fn_user)
               and (select to_date(t.cd_filtro || ' 23:59:59',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 7
                       and t.nm_operador = fn_user)
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 1
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 1
                        and t.cd_filtro = aaa.cd_setor_emp
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 2
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 2
                        and t.cd_filtro = aa.cd_setor_controle
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 3
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 3
                        and t.cd_filtro = aa.cd_setor_destino
                        and t.nm_operador = fn_user))
               and exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 4
                        and t.cd_filtro = to_char(a.cd_material)
                        and t.nm_operador = fn_user)
               and aaa.fl_controla = 'S'
               and aaa.fl_estoque_proprio = 'S'
                  -- Joins
                  -- a -- aa
               and aa.cd_devolucao = a.cd_devolucao
                  -- aa -- aaa
               and aaa.cd_setor = aa.cd_setor_controle
            union all
            select 5,
                   'TRN',
                   aa.cd_transferencia,
                   '',
                   aa.cd_setor_controle,
                   aa.cd_setor_destino,
                   aa.dt_emissao,
                   a.cd_material,
                   nvl(a.qt_material_c + a.qt_material_n, 0),
                   nvl(a.vl_material_c, 0),
                   nvl(aa.dt_transacao, aa.dt_emissao) dt_transacao,
                   aaa.cd_setor_emp empresa,
                   0 qt_contada,
                   aa.cd_usuario,
                   aa.nu_comanda,
                   a.cd_lote,
                   a.dt_validade_lote,
                   0 nu_seq_nota,
                   aa.fl_status,
                   null id_kit,
                   'N' fl_perdas,
                   aa.nu_protocolo
              from tm_setor              aaa,
                   tm_transferencia      aa,
                   tb_item_transferencia a
             where 1 = 1
                  -- Filtros
               and a.fl_status_item in (1, 2, 3)
               and aa.dt_transacao between
                   (select to_date(t.cd_filtro || ' 00:00:00',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 6
                       and t.nm_operador = fn_user)
               and (select to_date(t.cd_filtro || ' 23:59:59',
                                   'dd/mm/yyyy hh24:mi:ss')
                      from tb_filtro_t43gc t
                     where t.tp_filtro = 7
                       and t.nm_operador = fn_user)
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 1
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 1
                        and t.cd_filtro = aaa.cd_setor_emp
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 2
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 2
                        and t.cd_filtro = aa.cd_setor_controle
                        and t.nm_operador = fn_user))
               and (1 = (select 1
                           from tb_filtro_t43gc t
                          where t.tp_filtro = 3
                            and t.cd_filtro = '%'
                            and t.nm_operador = fn_user) or exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 3
                        and t.cd_filtro = aa.cd_setor_destino
                        and t.nm_operador = fn_user))
               and  exists
                    (select 1
                       from tb_filtro_t43gc t
                      where t.tp_filtro = 4
                        and t.cd_filtro = to_char(a.cd_material)
                        and t.nm_operador = fn_user)
               and aaa.fl_controla = 'S'
               and aaa.fl_estoque_proprio = 'S'
                  -- Joins
                  -- a -- aa
               and aa.cd_transferencia = a.cd_transferencia
                  -- aa -- aaa
               and aaa.cd_setor = aa.cd_setor_controle) e
     where 1 = 1
       and e.dt_transacao between
           (select to_date(t.cd_filtro || ' 00:00:00',
                           'dd/mm/yyyy hh24:mi:ss')
              from tb_filtro_t43gc t
             where t.tp_filtro = 6
               and t.nm_operador = fn_user)
       and (select to_date(t.cd_filtro || ' 23:59:59',
                           'dd/mm/yyyy hh24:mi:ss')
              from tb_filtro_t43gc t
             where t.tp_filtro = 7
               and t.nm_operador = fn_user)
       and e.nu_protocolo is null
       and s.cd_setor = e.cd_setor_controle
       and (s.fl_farmacia_central = 'S' or s.fl_principal = 'S' or
           s.fl_centro_cirurgico = 'S' or s.fl_emergencia = 'S' or
           s.fl_hemodinamica = 'S' or s.fl_farmacia_apoio = 'S')
       and m.cd_material = e.cd_material
       and c.cd_classificacao = m.cd_classificacao
       and tc.cd_tipo_classificacao = c.cd_tipo_classificacao
       and (tc.fl_tipo_classificacao in (1, 2) or
           tc.fl_tipo_classificacao = 9)
       and s1.cd_setor = e.cd_setor_destino
       and f.cd_filial = s.cd_setor_emp
       and ((e.cd_tipo in (2, 3)) or
           (e.cd_tipo = 5 and s.cd_setor_emp = s1.cd_setor_emp and
           m.fl_fragmenta = 'S' and nvl(s1.fl_principal, 'N') = 'N' and
           nvl(s1.fl_farmacia_central, 'N') = 'N'))
     group by f.cd_filial,
              f.nm_fantasia,
              s.cd_setor,
              s.nm_setor,
              e.cd_setor_destino,
              s1.nm_setor),vw_faturados as
   (select f.cd_filial cd_filial,
           f.nm_fantasia nm_filial,
           s.cd_setor cd_setor_origem,
           s.nm_setor nm_setor_origem,
           s2.cd_setor cd_setor_destino,
           s2.nm_setor nm_setor_destino,
           sum(cmm.qt_material + nvl(cmm.qt_devolvido, 0)) qt_faturado,
           round(sum(cmm.vl_total), 2) vl_faturado
      from vw_filial          f,
           tm_setor           s2,
           tm_setor           s,
           tb_mat_med         mm,
           tb_comanda_mat_med cmm,
           tb_comanda         c
     where 1 = 1
          --- Filtros
       and c.dt_comanda between
           (select to_date(t.cd_filtro, 'DD/MM/YYYY')
              from tb_filtro_t43gc t
             where t.tp_filtro = 6
               and t.nm_operador = fn_user)
       and (select to_date(t.cd_filtro, 'DD/MM/YYYY')
              from tb_filtro_t43gc t
             where t.tp_filtro = 7
               and t.nm_operador = fn_user)
       and (1 = (select 1
                   from tb_filtro_t43gc t
                  where t.tp_filtro = 1
                    and t.cd_filtro = '%'
                    and t.nm_operador = fn_user) or exists
            (select 1
               from tb_filtro_t43gc t
              where t.tp_filtro = 1
                and t.cd_filtro = f.cd_filial
                and t.nm_operador = fn_user))
       and (1 = (select 1
                   from tb_filtro_t43gc t
                  where t.tp_filtro = 2
                    and t.cd_filtro = '%'
                    and t.nm_operador = fn_user) or exists
            (select 1
               from tb_filtro_t43gc t
              where t.tp_filtro = 2
                and t.cd_filtro = c.cd_setor_origem
                and t.nm_operador = fn_user))
       and (1 = (select 1
                   from tb_filtro_t43gc t
                  where t.tp_filtro = 3
                    and t.cd_filtro = '%'
                    and t.nm_operador = fn_user) or exists
            (select 1
               from tb_filtro_t43gc t
              where t.tp_filtro = 3
                and t.cd_filtro = c.cd_setor_destino
                and t.nm_operador = fn_user))
       and exists
            (select 1
               from tb_filtro_t43gc t
              where t.tp_filtro = 4
                and t.cd_filtro = to_char(cmm.cd_mat_med)
                and t.nm_operador = fn_user)
          --- Joins
          --- c -< cmm
       and cmm.cd_atendimento = c.cd_atendimento
       and cmm.cd_ocorrencia = c.cd_ocorrencia
       and cmm.cd_ordem = c.cd_ordem
       and cmm.cd_ordem_cmd = c.cd_ordem_cmd
          --- cmm -- mm
       and mm.cd_mat_med = cmm.cd_mat_med
          --- c -- s
       and s.cd_setor = c.cd_setor_origem
          --- s -- f
       and f.cd_filial = s.cd_setor_emp
          --- c -- s2
       and s2.cd_setor = c.cd_setor_destino
     group by f.cd_filial,
              f.nm_fantasia,
              s.cd_setor,
              s.nm_setor,
              s2.cd_setor,
              s2.nm_setor)
  select t.cd_filial,
         t.nm_filial,
         t.cd_setor_origem,
         t.nm_setor_origem,
         t.cd_setor_destino,
         t.nm_setor_destino,
         t.qt_consumido,
         t.vl_consumido,
         t.qt_faturado,
         t.vl_faturado
    from (select y.cd_filial,
                 y.nm_filial,
                 y.cd_setor_origem,
                 y.nm_setor_origem,
                 y.cd_setor_destino,
                 y.nm_setor_destino,
                 y.qt_consumido,
                 y.vl_consumido,
                 x.qt_faturado,
                 x.vl_faturado
            from vw_faturados  x,
                 vw_consumidos y
           where 1 = 1
             and y.cd_filial = x.cd_filial
             and y.cd_setor_origem = x.cd_setor_origem
             and y.cd_setor_destino = x.cd_setor_destino
          union all
          select x.cd_filial,
                 x.nm_filial,
                 x.cd_setor_origem,
                 x.nm_setor_origem,
                 x.cd_setor_destino,
                 x.nm_setor_destino,
                 0                  qt_consumido,
                 0                  vl_consumido,
                 x.qt_faturado,
                 x.vl_faturado
            from vw_faturados x
           where 1 = 1
             and not exists
           (select 1
                    from vw_consumidos y
                   where y.cd_filial = x.cd_filial
                     and y.cd_setor_origem = x.cd_setor_origem
                     and y.cd_setor_destino = x.cd_setor_destino)
          union all
          select y.cd_filial,
                 y.nm_filial,
                 y.cd_setor_origem,
                 y.nm_setor_origem,
                 y.cd_setor_destino,
                 y.nm_setor_destino,
                 y.qt_consumido,
                 y.vl_consumido,
                 0                  qt_faturado,
                 0                  vl_faturado
            from vw_consumidos y
           where 1 = 1
             and not exists
           (select 1
                    from vw_faturados x
                   where y.cd_filial = x.cd_filial
                     and y.cd_setor_origem = x.cd_setor_origem
                     and y.cd_setor_destino = x.cd_setor_destino)) t
   order by 1 asc,
            3 asc,
            5 asc
/

