create view VW_EXAME_PLANO_USO as
select t.cd_atendimento,
          t.cd_ocorrencia_plano,
          t.cd_ordem,
          t.cd_solicitacao_exame,
          t.dt_solicitacao_exame,
          t.hr_solicitacao_exame,
          t.cd_profissional,
          t.fl_validado,
          t.cd_profissional_valida,
          t.fl_status_uso,
          t.nu_guia_gerada,
          t.fl_impresso,
          t.cd_profissional_imprime,
          it.cd_procedimento,
          it.qt_exame,
          t.ds_justificativa_exame_urgente,
          t.ds_indicacao_clinica,
          t.dt_exame_programado,
          t.hr_exame_programado
   from tb_item_exame_plano_uso it,tb_exame_plano_uso t
   where it.cd_atendimento=t.cd_atendimento and
         it.cd_ocorrencia_plano=t.cd_ocorrencia_plano and
         it.cd_ordem=t.cd_ordem
/

