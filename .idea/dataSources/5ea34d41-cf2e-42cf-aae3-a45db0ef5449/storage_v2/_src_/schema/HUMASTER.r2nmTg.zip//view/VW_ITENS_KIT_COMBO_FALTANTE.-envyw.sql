create view VW_ITENS_KIT_COMBO_FALTANTE as
select /*
             Fred Monteiro - IVIA - 18/06/2018
             View que contem os itens do combo que ainda nao foram bipados ou nao foram bipados em toda a sua  totalidade
         */
         c.cd_agenda,
         c.dt_agenda,
         c.dt_nascimento,
         c.cd_paciente,
         c.idade_meses,
         c.cd_material,
         c.qt_produto,
         c.cd_ato_cirurgico,
         c.id_kit,
         c.cd_setor_controle,
         c.qtd_padrao,
         c.qtd_bipada
    from (
          select b.cd_agenda,
                 b.dt_agenda,
                 b.dt_nascimento,
                 b.cd_paciente,
                 b.idade_meses,
                 b.cd_material,
                 b.qt_produto,
                 b.cd_ato_cirurgico,
                 b.id_kit,
                 b.cd_setor_controle,
                 sum(decode(b.status, 'P', b.qt_produto, 0)) qtd_padrao,
                 sum(decode(b.status, 'B', b.qt_produto, 0)) qtd_bipada
            from (select a.cd_agenda,
                         a.dt_agenda,
                         a.dt_nascimento,
                         a.cd_paciente,
                         a.idade_meses,
                         a.cd_material,
                         a.qt_produto,
                         a.cd_ato_cirurgico,
                         a.id_kit,
                         a.cd_setor_controle,
                         'P' status
                    from vw_itens_kit_combo_padrao a -- itens padrao do combo
                   where 1 = 1
                   union all
                  select a.cd_agenda,
                         a.dt_agenda,
                         a.dt_nascimento,
                         a.cd_paciente,
                         a.idade_meses,
                         a.cd_material,
                         a.qt_produto,
                         a.cd_ato_cirurgico,
                         a.id_kit,
                         a.cd_setor_controle,
                         'B' status
                    from vw_itens_kit_combo_bipado a -- itens padrao do combo que foram bipados
                   where 1 = 1) b
           where 1 = 1
           group by b.cd_agenda,
                    b.dt_agenda,
                    b.dt_nascimento,
                    b.cd_paciente,
                    b.idade_meses,
                    b.cd_material,
                    b.qt_produto,
                    b.cd_ato_cirurgico,
                    b.id_kit,
                    b.cd_setor_controle) c
   where 1 = 1
     and c.qtd_padrao <> c.qtd_bipada
/

