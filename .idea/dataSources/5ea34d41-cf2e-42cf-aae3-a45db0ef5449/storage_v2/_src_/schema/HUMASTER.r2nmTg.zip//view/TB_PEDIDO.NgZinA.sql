create view TB_PEDIDO as
select
 CD_PEDIDO                ,
 FL_PEDIDO                ,
 CD_FORNECEDOR            ,
 DT_PEDIDO                ,
 CD_FILIAL                ,
 CD_MOTIVO_ACEITE_PEDIDO  ,
 CD_CONDICAO_ENTREGA      ,
 CD_UM                    ,
 VL_PEDIDO                ,
 VL_SALDO_PEDIDO          ,
 VL_SALDO_NOTA            ,
 VL_SALDO_OBRIGACAO       ,
 DT_VALIDADE_PEDIDO       ,
 QT_DIAS_ENTREGA          ,
 CD_COTACAO               ,
 DS_FORMA_PAGAMENTO       NM_FORMA_PAGAMENTO,
 PC_ICMS                  ,
 DS_OBSERVACAO            NM_OBSERVACAO,
 DT_PREVISTA_ENTRAGA      DT_PREVISTA_ENTREGA,
 DT_ENTREGA,
 CD_SETOR_CONTROLE,
 QT_DIAS_EXPIRACAO,
 TP_REF_DATA,
 QT_DIAS_APOS,
 FL_GNHAP
from humaster.tm_pedido_fornecedor
/

