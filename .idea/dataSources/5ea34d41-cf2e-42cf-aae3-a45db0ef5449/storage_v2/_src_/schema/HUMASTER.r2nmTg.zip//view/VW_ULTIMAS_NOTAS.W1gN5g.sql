create view VW_ULTIMAS_NOTAS as
select it.cd_material,
         n.dt_saida,
         n.dt_entrada,
         it.qt_material,
         ((nvl(it.vl_material,0)+
           nvl(it.vl_ipi,0)+
           nvl(it.vl_desconto,0))
         / it.qt_material)  vl_custo,
         n.vl_um,
         n.fl_estoque,
         n.cd_fornecedor,
         n.cd_nota_fornecedor,
         n.cd_nota
    from humaster.tm_nota n,
         sah.tb_item_nota it
   where n.cd_nota = it.cd_nota
     and it.qt_material>0
     and it.vl_material>0
/

