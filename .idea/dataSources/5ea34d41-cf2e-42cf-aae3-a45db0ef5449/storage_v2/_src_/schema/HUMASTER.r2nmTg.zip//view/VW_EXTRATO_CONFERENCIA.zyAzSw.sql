create view VW_EXTRATO_CONFERENCIA as
    select
   a.cd_movimento_conta,
   b.cd_filial,
   a.dt_transacao,
   a.cd_um,
   'REC CHEQUE '||a.cd_documento_debito||' - '||c.nm_agencia||' C/C '||
   b.cd_conta_corrente nm_historico,
   a.vl_movimento vl_credito,
   decode(0,1,0) vl_debito
    from tb_agencia_bancaria c, tm_conta_corrente b, tm_movimento_conta a
    where b.cd_conta_bancaria = a.cd_conta_corrente_debito and
     c.cd_banco = b.cd_banco and c.cd_agencia = b.cd_agencia and
     a.dt_estorno is null and cd_tipo_transacao_db='CHQ'
  union all
  select a.cd_movimento_conta,
   b.cd_filial,
   a.dt_transacao,
   a.cd_um,
   ltrim(c.ds_historico_padrao||' '||b.nm_historico,' '),
   decode(b.fl_lancamento,'D',(1+sign(b.vl_transacao))/2,
          (sign(b.vl_transacao)-1)/(-2))*b.vl_transacao vl_credito,
   decode(b.fl_lancamento,'C',(1+sign(b.vl_transacao))/2,
          (sign(b.vl_transacao)-1)/(-2))*b.vl_transacao vl_debito
    from tb_historico_padrao c,tm_movimento_transacao b,
    tm_movimento_conta a
    where b.cd_movimento_conta = a.cd_movimento_conta and
    c.cd_historico_padrao(+) = b.cd_historico_padrao and
    a.dt_estorno is null
/

