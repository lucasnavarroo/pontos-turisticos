create view VW_UNIDADE_USUAL as
select CD_UNIDADE_USUAL,
       NM_UNIDADE_USUAL,
       FL_USO_PRESCRICAO,
       NR_UNIDADE_USUAL
  from tb_unidade_usual
/

