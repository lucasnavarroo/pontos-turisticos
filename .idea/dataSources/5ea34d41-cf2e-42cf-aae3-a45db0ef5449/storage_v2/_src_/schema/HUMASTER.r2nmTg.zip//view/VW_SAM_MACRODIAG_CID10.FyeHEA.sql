create view VW_SAM_MACRODIAG_CID10 as
select nvl(mcid.cd_macrodiag_cid10, 99) as cd_macrodiag_cid10,
       cid."CID10",
       cid."OPC",
       cid."CAT",
       cid."SUBCAT",
       cid."DESCR",
       cid."RESTRSEXO",
       cid."CD_GRUPO_CID10",
       cid."CD_SUBGRUPO_CID10",
       cid."CD_CATEGORIA_CID10",
       cid."NM_CID10",
       cid."FL_USO",
       cid."OBS",
       rownum cd_identificador
  from tb_macro_cid10 mcid, tb_cid10 cid
 where mcid.cid10(+) = cid.cid10
 order by mcid.cd_macrodiag_cid10 nulls last
/

