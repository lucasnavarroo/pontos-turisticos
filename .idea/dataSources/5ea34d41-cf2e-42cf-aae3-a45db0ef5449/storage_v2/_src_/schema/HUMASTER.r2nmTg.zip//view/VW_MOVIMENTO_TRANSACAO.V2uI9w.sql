create view VW_MOVIMENTO_TRANSACAO as
select
 v.CD_MOVIMENTO_CONTA      ,
 v.dt_transacao            ,
 f.cd_filial               ,
 f.cd_empresa_organizacao  ,
 cc.cd_tipo_conta_corrente ,
 cc.cd_conta_bancaria      ,
 c.cd_classe_tipo_operacao ,
 c.nm_classe_tipo_operacao ,
 c.fl_natureza             ,
 m.fl_financeiro           ,
 t.cd_tipo_operacao        ,
 t.nm_tipo_operacao        ,
 n.cd_nivel_operacao       ,
 n.nm_nivel_operacao       ,
 ot.CD_OPERACAO            ,
 o.nm_operacao             ,
 ot.cd_setor               ,
 s.nm_setor                ,
 m.DT_EMISSAO_DOCUMENTO    ,
 m.CD_HISTORICO_PADRAO     ,
 ltrim(h.ds_historico_padrao||' '||m.NM_HISTORICO,' ') nm_historico,
 decode(c.fl_natureza,'R',decode(m.fl_lancamento,'D',1,-1),
            'D',decode(m.fl_lancamento,'C',1,-1),1)*
            m.VL_TRANSACAO*ot.vl_rateio/100 vl_transacao,
 m.CD_UM_TRANSACAO         ,
 decode(sign(decode(c.fl_natureza,'R',decode(m.fl_lancamento,'D',1,-1),
              'D',decode(m.fl_lancamento,'C',1,-1),1)*
  m.vl_transacao),-1,decode(m.fl_lancamento,'C','D','D','C'),m.FL_LANCAMENTO) fl_lancamento,
 v.DT_ESTORNO
from    tb_historico_padrao h,
        tb_filial f,
        tb_classe_tipo_operacao c,
        tb_tipo_operacao t,
        tb_nivel_operacao n,
        tm_setor s,
        tb_operacao o,
        tb_operacao_transacao ot,
        tm_movimento_transacao m,
        tm_conta_corrente cc,
        tm_movimento_conta v
where   cc.cd_conta_bancaria = nvl(v.cd_conta_corrente_debito,v.cd_conta_corrente_credito) and
--        cc.cd_unidade_atendimento like fn_unidade and
        m.cd_movimento_conta = v.cd_movimento_conta and
--        v.cd_unidade_atendimento like fn_unidade and
        ot.cd_movimento_conta = m.cd_movimento_conta and
        ot.cd_ordem_transacao = m.cd_ordem_transacao and
        o.cd_operacao = ot.cd_operacao and
        s.cd_setor = ot.cd_setor and
        n.cd_nivel_operacao = o.cd_nivel_operacao and
        n.cd_tipo_operacao = o.cd_tipo_operacao and
        t.cd_tipo_operacao = n.cd_tipo_operacao and
        c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao and
        f.cd_filial(+) = s.cd_setor_emp and
        h.cd_historico_padrao(+) = m.cd_historico_padrao and
        (v.cd_conta_corrente_credito is null or
         v.cd_conta_corrente_debito is null)
/

