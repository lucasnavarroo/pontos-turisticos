create view VW_MOVIMENTACAO_ATENDIMENTO as
    select 'MAT/MED' cd_tipo_movimento,
       a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino cd_posto,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       cp.cd_convenio_base cd_convenio_pagador,
       pc.nm_fantasia nm_convenio,
       ct.ds_fl_tipo_classificacao,
       m.cd_mat_med cd_item,
       d.nm_material||' '||d.cd_apresentacao||' '||to_char(d.qt_conteudo)||d.cd_unidade_usual ds_item,
       sum(m.qt_material) qt_item,
       sum(m.qt_entregue + nvl(qt_devolvido,0)) qt_item_entregue,
       sum(m.vl_material)/decode(sum(m.qt_entregue + nvl(qt_devolvido,0)),0,1,sum(m.qt_entregue + nvl(qt_devolvido,0))) vl_unit,
       sum(m.vl_material) vl_item,
       sum(m.vl_total) vl_total_item
from tb_material d,
     tb_tipo_classificacao tc,
     tb_classe_tipo_classificacao ct,
     tb_classificacao c,
     tb_pessoa pc,
     tb_setor s,
     tb_convenio e,
     tb_paciente p,
     tb_convenio_pagador cp,
     tb_atendimento a,
     tb_comanda n,
     tb_comanda_mat_med m
where n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and n.cd_ordem_cmd = m.cd_ordem_cmd
  and a.cd_atendimento = n.cd_atendimento
  and p.cd_paciente = a.cd_paciente
  and s.cd_setor = n.cd_setor_destino
  and d.cd_material = m.cd_mat_med
  and c.cd_classificacao = d.cd_classificacao
  and tc.cd_tipo_classificacao = c.cd_tipo_classificacao
  and ct.fl_tipo_classificacao = tc.fl_tipo_classificacao
  and cp.cd_atendimento = m.cd_atendimento
  and cp.cd_convenio_pagador = m.cd_convenio_pagador
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
group by a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       cp.cd_convenio_base,
       pc.nm_fantasia,
       ct.ds_fl_tipo_classificacao,
       m.cd_mat_med,
       d.nm_material||' '||d.cd_apresentacao||' '||to_char(d.qt_conteudo)||d.cd_unidade_usual
union all
select 'TAXAS' cd_tipo_movimento,
       a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino cd_posto,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       cp.cd_convenio_base cd_convenio_pagador,
       pc.nm_fantasia,
       'TAXAS COBRADAS',
       to_number(m.cd_taxas),
       d.nr_taxas,
       sum(m.qt_taxa),
       sum(m.qt_taxa),
       sum(m.vl_taxa)/decode(sum(m.qt_taxa),0,1,sum(m.qt_taxa)),
       sum(m.vl_taxa),
       sum(m.vl_total)
from tb_taxas d,
     tb_pessoa pc,
     tb_convenio e,
     tb_setor s,
     tb_paciente p,
     tb_convenio_pagador cp,
     tb_atendimento a,
     tb_comanda n,
     tb_comanda_taxa m
where n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and n.cd_ordem_cmd = m.cd_ordem_cmd
  and a.cd_atendimento = m.cd_atendimento
  and p.cd_paciente = a.cd_paciente
  and s.cd_setor = n.cd_setor_destino
  and d.cd_taxas = m.cd_taxas
  and cp.cd_atendimento = m.cd_atendimento
  and cp.cd_convenio_pagador = m.cd_convenio_pagador
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
group by a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       cp.cd_convenio_base,
       pc.nm_fantasia,
       to_number(m.cd_taxas),
       d.nr_taxas
union all
select 'PABX' cd_tipo_movimento,
       a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino cd_posto,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       FN_CONVENIO_PARTICULAR,
       'UNIPAR',
       'PABX',
       0,
       'LIGACOES TELEFONICAS',
       0,
       0,
       m.vl_custo,
       m.vl_custo,
       m.vl_custo
from tb_setor s,
     tb_paciente p,
     tb_atendimento a,
     tb_comanda n,
     tb_comanda_pabx m
where n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and a.cd_atendimento = m.cd_atendimento
  and p.cd_paciente = a.cd_paciente
  and s.cd_setor = n.cd_setor_destino
union all
Select 'RESTAURANTE' cd_tipo_movimento,
       a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino cd_posto,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       FN_CONVENIO_PARTICULAR,
       'UNIPAR',
       'CONSUMO RESTAURANTE',
       i.cd_material,
       d.nm_mat_med,
       sum(i.qt_comanda),
       sum(i.qt_comanda),
       sum(i.vl_comanda)/decode(sum(i.qt_comanda),0,1,sum(i.qt_comanda)),
       sum(i.vl_comanda),
       sum(i.vl_comanda)
from tb_setor s,
     tb_paciente p,
     tb_mat_med d,
     tb_atendimento a,
     tb_item_restaurante i,
     tb_comanda n,
     tb_comanda_restaurante m
where n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and a.cd_atendimento = m.cd_atendimento
  and i.cd_comanda_restaurante = m.nu_comanda_restaurante
  and i.nu_ocorrencia = m.cd_ocorrencia
  and d.cd_mat_med = i.cd_material
  and p.cd_paciente = a.cd_paciente
  and s.cd_setor = n.cd_setor_destino
group by a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino,
       n.dt_comanda,
       s.nm_setor,
       m.cd_ocorrencia,
       FN_CONVENIO_PARTICULAR,
       'UNIPAR',
       i.cd_material,
       d.nm_mat_med
union all
select 'PROCEDIMENTOS' cd_tipo_movimento,
       a.cd_atendimento,
       a.dt_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       n.cd_setor_destino cd_posto,
       nvl(pr.dt_procedimento_realizado,a.dt_atendimento) dt_comanda,
       s.nm_setor,
       pr.cd_ocorrencia,
       cp.cd_convenio_base cd_convenio_pagador,
       pc.nm_fantasia,
       'PROCEDIMENTOS REALIZADOS',
       to_number(pr.cd_procedimento),
       d.nr_procedimento,
       pr.qt_procedimento,
       pr.qt_procedimento,
       pr.vl_procedimento/decode(nvl(pr.qt_procedimento,0),0,1,nvl(pr.qt_procedimento,0)),
       pr.vl_procedimento,
       pr.vl_procedimento
from tb_procedimento d,
     tb_pessoa pc,
     tb_convenio e,
     tb_setor s,
     tb_paciente p,
     tb_convenio_pagador cp,
     tb_atendimento a,
     tb_guia g,
     tb_procedimento_realizado pr,
     (select distinct cd_atendimento,
		      cd_ocorrencia,
		      cd_ordem,
		      cd_setor_destino
      from tb_comanda) n
where pr.cd_atendimento = n.cd_atendimento
  and pr.cd_ocorrencia = n.cd_ocorrencia
  and pr.cd_ordem = n.cd_ordem
  and pr.cd_procedimento between '00000000' and '90000000'
  and g.cd_atendimento = pr.cd_atendimento
  and g.cd_ocorrencia = pr.cd_ocorrencia
  and a.cd_atendimento = g.cd_atendimento
  and p.cd_paciente = a.cd_paciente
  and s.cd_setor = n.cd_setor_destino
  and d.cd_procedimento = pr.cd_procedimento
  and cp.cd_atendimento = pr.cd_atendimento
  and cp.cd_convenio_pagador = g.cd_convenio_pagador
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
/

