create view VW_SAM_EXAMES_IMG as
select /* + first_rows(10) */
            pr.cd_procedimento,
            pr.nu_prioridade_exame,
            pr.nr_procedimento,
            pr.cd_procedimento_cbhpm,
            pr.fl_urgencia,
            pr.fl_membros_pares
       from tb_procedimento pr
      where nvl(pr.fl_urgencia,'N') = 'S'
        and pr.fl_tipo_exame     = 2 -- exames de imagem
        and nvl(pr.fl_cbhpm,'N') = 'N'
     order by pr.nu_prioridade_exame
/

