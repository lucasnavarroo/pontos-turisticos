create view VW_PESSOA_TITULAR_S as
select b.nu_usuario,b.cd_pessoa cd_pessoa_titular
from tb_usuario@hapvida b
where b.nu_usuario = b.nu_titular
/

