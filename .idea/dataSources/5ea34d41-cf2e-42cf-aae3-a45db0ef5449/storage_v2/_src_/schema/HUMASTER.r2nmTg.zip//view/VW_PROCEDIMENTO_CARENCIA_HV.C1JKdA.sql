create view VW_PROCEDIMENTO_CARENCIA_HV as
select "CD_CARENCIA","CD_PROCEDIMENTO" from tb_procedimento_carencia@hapvida
/

