create view VW_AERO_PROCEDIMENTO_COMPL as
select m.cd_modelo,
       m.cd_ordem_proc_plano_uso,
       m.cd_procedimento,
       m.nm_procedimento,
       m.qt_procedimento,
       m.cd_proc_plano_pai
  from tb_proced_plano_uso_modelo m
 where m.fl_tipo_aprazamento is null
 and m.cd_proc_plano_pai is not null
/

