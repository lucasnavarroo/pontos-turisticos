create view VW_ITENS_KIT_AGENDA_N1 as
select /*+ choose */
        a.cd_agenda,
        to_date(to_char (a.dt_agenda,'dd/mm/yyyy')||' '||fn_hora(a.HR_AGENDA),'dd/mm/yyyy hh24:mi')dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        ( a.dt_agenda - a.dt_nascimento ) / 30 idade_meses,
        aaaa.cd_param_grupo_proc,
        aab.cd_procedimento,
        aac.procedimento_pai cd_procedimento_pai,
        aab.cd_porte_anestesia,
        aaaa.cd_mat_med cd_material,
        decode (AB.FL_KIT_REDUZIDO ,'S', nvl(aaaa.qt_kit_reduzido,0) ,aaaa.qt_produto)qt_produto,
        ab.id_kit,
        ab.cd_setor_controle,
        aaaa.qt_kit_reduzido,
        ab.cd_faixa
    from
        tm_kit_cirurgia_lote          ab,
        vw_procedimento_pai_filho    aac,  -- pai x filhos procedimentos
        tb_procedimento              aab,  -- descricao do procedimento
        tb_prod_grupo_proc          aaaa,  -- material x grupo de procedimento
        tb_proc_grupo_proc           aaa,  -- procedimento x grupo de procedimento
        tb_agenda_intern_procedimento aa,  -- procedimentos do agendamento
        tm_agenda_internacao           a      -- agendamento
    where 1 = 1
   -- filtros
    and aaaa.cd_grupo_prod_proc                 = 2
   -- join a -- aa
    and a.cd_agenda                             = aa.cd_agenda
   -- join aa -- aaa
    and aa.cd_procedimento                      = aaa.cd_procedimento
   -- join aaa -- aaaa
    and aaa.cd_param_grupo_proc                 = aaaa.cd_param_grupo_proc
   -- join aa -- aab
    and aa.cd_procedimento                      = aab.cd_procedimento
   -- join aa -- aac
    and aa.cd_procedimento                      = aac.procedimento_filho
   -- join a -- ab
    and a.cd_agenda                             = ab.cd_agenda (+)
    and aaaa.dt_fin_vigencia                    is null
/

