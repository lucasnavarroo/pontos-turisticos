create view VW_RVER as
    select a.cd_atendimento,
	a.dt_atendimento,
	n.cd_setor_destino cd_posto,
	s.nm_setor nm_posto,
	n.dt_comanda dt_comanda,
	cp.cd_convenio_base cd_convenio,
	pc.nm_fantasia nm_convenio,
	m.cd_taxas cd_produto,
	d.nr_taxas nm_produto,
	m.qt_taxa qt_produto,
	m.vl_taxa vl_produto,
	m.vl_total vl_total,
	a.fl_internacao,
	a.cd_tipo_atendimento
from tm_setor s,
     tb_taxas d,
     tb_pessoa pc,
     tm_convenio e,
     tb_convenio_pagador cp,
     tm_atendimento a,
     tb_comanda_taxa m,
     tb_comanda n
where n.dt_comanda between add_months(sysdate,-12) and sysdate
  and n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and n.cd_ordem_cmd = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and m.qt_taxa is not null
  and a.cd_atendimento = m.cd_atendimento
  and a.cd_unidade_atendimento like '006'
  and cp.cd_atendimento = a.cd_atendimento
  and cp.cd_convenio_pagador = m.cd_convenio_pagador
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
  and d.cd_taxas = m.cd_taxas
  and s.cd_setor = n.cd_setor_destino
union all
select a.cd_atendimento,
	a.dt_atendimento,
	n.cd_setor_destino cd_posto,
	s.nm_setor nm_posto,
	n.dt_comanda dt_comanda,
	cp.cd_convenio_base cd_convenio,
	pc.nm_fantasia nm_convenio,
	to_char(m.cd_mat_med) cd_produto,
	d.nm_mat_med||' '||d.cd_apresentacao||'/'||d.cd_unidade nm_produto,
	m.qt_material qt_produto,
	m.vl_total/m.qt_material vl_produto,
	m.vl_total vl_total,
	a.fl_internacao,
        a.cd_tipo_atendimento
from tm_setor s,
     tb_mat_med d,
     tb_pessoa pc,
     tm_convenio e,
     tb_convenio_pagador cp,
     tm_atendimento a,
     tb_comanda_mat_med m,
     tb_comanda n
where n.dt_comanda between add_months(sysdate,-12) and sysdate
  and n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and n.cd_ordem_cmd = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and m.qt_material is not null
  and m.qt_material not in (0)
  and a.cd_atendimento = m.cd_atendimento
  and a.cd_unidade_atendimento like '006'
  and cp.cd_atendimento = a.cd_atendimento
  and cp.cd_convenio_pagador = m.cd_convenio_pagador
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
  and d.cd_mat_med = m.cd_mat_med
  and s.cd_setor = n.cd_setor_destino
union all
select a.cd_atendimento,
       a.dt_atendimento,
       a.cd_setor cd_posto,
       s.nm_setor nm_posto,
       a.dt_atendimento dt_comanda,
       FN_CONVENIO_PARTICULAR,
       'UNIPAR',
       '99999999',
       'LIGACOES TELEFONICAS',
       0,
       m.vl_custo,
       m.vl_custo,
       a.fl_internacao,
       a.cd_tipo_atendimento
from tm_setor s,
     tb_comanda_pabx m,
     tm_atendimento a
where a.dt_atendimento between add_months(sysdate,-12) and sysdate
  and a.cd_atendimento = m.cd_atendimento
  and a.cd_unidade_atendimento like '006'
  and s.cd_setor = a.cd_setor
union all
Select a.cd_atendimento,
	a.dt_atendimento,
       m.cd_setor_atendimento cd_posto,
       s.nm_setor,
       m.dt_comanda,
       FN_CONVENIO_PARTICULAR,
       'UNIPAR',
       '99998888',
       'CONSUMO RESTAURANTE',
       i.qt_comanda,
       1.1 * i.vl_comanda,
       1.1 * i.vl_comanda,
       a.fl_internacao,
       a.cd_tipo_atendimento
from tm_setor s,
     tm_atendimento a,
     tb_item_restaurante i,
     tb_comanda_restaurante m
where m.dt_comanda between add_months(sysdate,-12) and sysdate
  and i.cd_comanda_restaurante=m.nu_comanda_restaurante
  and i.nu_ocorrencia=m.cd_ocorrencia
  and a.cd_atendimento = m.cd_atendimento
  and a.cd_unidade_atendimento like '006'
  and s.cd_setor = m.cd_setor_atendimento
union all
select a.cd_atendimento,
	a.dt_atendimento,
       a.cd_setor cd_posto,
       s.nm_setor,
       pr.dt_procedimento_realizado dt_comanda,
       cp.cd_convenio_base cd_convenio,
       pc.nm_fantasia nm_convenio,
       pr.cd_procedimento,
       d.nr_procedimento,
       nvl(pr.qt_procedimento,0),
       nvl(pr.vl_procedimento,0),
       nvl(pr.vl_total,0),
       a.fl_internacao,
       a.cd_tipo_atendimento
from tm_setor s,
     tb_pessoa pc,
     tm_convenio e,
     tb_procedimento d,
     tm_atendimento a,
     tb_convenio_pagador cp,
     tb_guia g,
     tb_procedimento_realizado pr
where pr.dt_procedimento_realizado between add_months(sysdate,-12) and sysdate
  and g.cd_atendimento = pr.cd_atendimento
  and g.cd_ocorrencia = pr.cd_ocorrencia
  and pr.cd_procedimento not in ('99995555','99997777','99998888','99999999')
  and pr.cd_pessoa_cobra = 4278
  and pr.qt_procedimento is not null
  and d.cd_procedimento=pr.cd_procedimento
  and cp.cd_atendimento = g.cd_atendimento
  and cp.cd_convenio_pagador = g.cd_convenio_pagador
  and a.cd_atendimento = pr.cd_atendimento
  and a.cd_unidade_atendimento like '006'
  and e.cd_convenio = cp.cd_convenio_base
  and pc.cd_pessoa = e.cd_pessoa
  and s.cd_setor = a.cd_setor
/

