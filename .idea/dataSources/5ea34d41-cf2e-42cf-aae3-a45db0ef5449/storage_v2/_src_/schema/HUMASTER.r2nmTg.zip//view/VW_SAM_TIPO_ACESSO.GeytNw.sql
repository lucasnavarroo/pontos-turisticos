create view VW_SAM_TIPO_ACESSO as
select CD_TIPO_ACESSO, NM_TIPO_ACESSO, CD_MNEMONICO from tb_tipo_acesso
/

