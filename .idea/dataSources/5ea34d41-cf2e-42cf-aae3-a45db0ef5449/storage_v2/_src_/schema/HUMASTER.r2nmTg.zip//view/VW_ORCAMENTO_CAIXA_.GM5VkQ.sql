create view VW_ORCAMENTO_CAIXA_ as
    select cd_operacao,dt_previsao,
       sum(nvl(vl_obrigacao,0)+nvl(vl_multa,0)+nvl(vl_juros,0)) valor
from vw_fluxo_caixa_analitico
where dt_previsao between to_date('11/08/1997','dd/mm/yyyy') and
      to_date('31/08/1997','dd/mm/yyyy') and cd_filial like '007'
group by cd_operacao,dt_previsao
union
select 0 cd_operacao,dt_saldo dt_previsao,vl_saldo valor
from tb_saldo_fluxo
union
select 999999 cd_operacao,dt_saldo dt_previsao,vl_saldo_final valor
from tb_saldo_fluxo
union
select cd_operacao,least(to_date('31/08/1997','dd/mm/yyyy') + 1,dt_previsao +
       decode(to_char(dt_previsao,'d'),2,5,3,4,4,3,5,2,6,1)) dt_previsao,
       sum(nvl(vl_obrigacao,0)+nvl(vl_multa,0)+nvl(vl_juros,0)) valor
from vw_fluxo_caixa_analitico
where dt_previsao between to_date('11/08/1997','dd/mm/yyyy') and
      to_date('31/08/1997','dd/mm/yyyy') and cd_filial like '007'
group by cd_operacao,least(to_date('31/08/1997','dd/mm/yyyy') + 1,
         dt_previsao+decode(to_char(dt_previsao,'d'),2,5,3,4,4,3,5,2,6,1))
union
select cd_operacao,to_date('31/08/1997','dd/mm/yyyy')+2 dt_previsao,
       sum(nvl(vl_obrigacao,0)+nvl(vl_multa,0)+nvl(vl_juros,0)) valor
from vw_fluxo_caixa_analitico
where dt_previsao between to_date('11/08/1997','dd/mm/yyyy') and
      to_date('31/08/1997','dd/mm/yyyy') and cd_filial like '007'
group by cd_operacao
/

