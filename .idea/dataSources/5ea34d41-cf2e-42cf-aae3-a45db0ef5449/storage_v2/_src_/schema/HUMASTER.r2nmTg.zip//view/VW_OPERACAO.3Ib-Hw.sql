create view VW_OPERACAO as
select  a.cd_operacao,
   substr(a.nm_operacao||'. '||b.nm_tipo_operacao,1,70) nm_operacao,
   a.ds_historico, c.fl_natureza
from    tb_classe_tipo_operacao c, tb_tipo_operacao b, tb_operacao a
where   b.cd_tipo_operacao = a.cd_tipo_operacao and
   c.cd_classe_tipo_operacao = b.cd_classe_tipo_operacao
/

