create view VW_PEDIDOS_BLOQUEADOS as
    with consulta1 as (select pe.cd_atendimento,
       pe.cd_ocorrencia,
       pe.nu_pedido,
       pe.dt_pedido,
       g.cd_pessoa_realiza,
       g.cd_setor_origem,
       a.cd_motivo_atendimento,
       f.cd_pessoa,
       pa.nm_paciente,
       igp.cd_grupo_produto,
       min(pz.dt_prazo) dt_prazo
 from  tb_item_grupo_procedimento igp,
       tb_procedimento            p,
       tb_filial                  f,
       tm_setor                   s,
       tb_paciente                pa,
       tm_atendimento             a,
       tb_prazo_exame             pz,
       tb_pedido_exame            pe,
       tb_guia                    g,
       tb_procedimento_realizado  pr
 where 1 = 1
   and pr.cd_atendimento = g.cd_atendimento
   and pr.cd_ocorrencia = g.cd_ocorrencia
   and g.cd_atendimento = pe.cd_atendimento
   and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = pz.cd_atendimento
   and pr.cd_ocorrencia  = pz.cd_ocorrencia
   and pr.cd_ordem       = pz.cd_ordem
   and pr.cd_atendimento = a.cd_atendimento
   and a.cd_paciente = pa.cd_paciente
   and pr.cd_setor = s.cd_setor
   and s.cd_setor_emp = f.cd_filial
   and pr.cd_procedimento = p.cd_procedimento
   and p.cd_procedimento = igp.cd_procedimento(+)
   and p.fl_tipo_exame in (0, 1)
   and pr.cd_procedimento not in ('99995555', '99996666', '99999999')
   and pr.dt_resultado is not null
   and pr.dt_libera_laudo is null
   and pr.cd_bioquimico_responsavel is null
   and not exists (select 'x'
          from tb_pedido_historico_bio bio
         where pe.nu_pedido = bio.nu_pedido
           and pe.cd_ocorrencia = bio.cd_ocorrencia
           and rownum = 1)
   group by pe.cd_atendimento,
       pe.cd_ocorrencia,
       pe.nu_pedido,
       pe.dt_pedido,
       g.cd_pessoa_realiza,
       g.cd_setor_origem,
       a.cd_motivo_atendimento,
       pa.nm_paciente,
       f.cd_pessoa,
       igp.cd_grupo_produto)
-----------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL, O PRAZO DE LIBERAÇÃO VENCEU E É POSSÍVEL REALIZAR MUDANÇA
, consulta2 as
 (select pe.nu_pedido,
         pe.dt_pedido,
         pe.cd_atendimento,
         pe.cd_ocorrencia,
         g.cd_pessoa_realiza,
         g.cd_setor_origem,
         min(pz.dt_prazo) dt_prazo,
         a.cd_motivo_atendimento,
         pa.nm_paciente,
         igp.cd_grupo_produto,
         f.cd_pessoa
    from tb_item_grupo_procedimento igp,
         tb_procedimento            p,
         tb_filial                  f,
         tm_setor                   s,
         tb_paciente                pa,
         tb_pedido_historico_bio    bio,
         tm_atendimento             a,
         tb_prazo_exame             pz,
         tb_pedido_exame            pe,
         tb_guia                    g,
         tb_procedimento_realizado  pr
   where 1 = 1
     and pr.cd_atendimento = g.cd_atendimento
     and pr.cd_ocorrencia = g.cd_ocorrencia
     and g.cd_atendimento = pe.cd_atendimento
     and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
     and pr.cd_atendimento = pz.cd_atendimento
     and pr.cd_ocorrencia = pz.cd_ocorrencia
     and pr.cd_ordem = pz.cd_ordem
     and pr.cd_atendimento = a.cd_atendimento
     and pe.nu_pedido = bio.nu_pedido
     and pe.cd_ocorrencia = bio.cd_ocorrencia
     and a.cd_paciente = pa.cd_paciente
     and pr.cd_setor = s.cd_setor
     and s.cd_setor_emp = f.cd_filial
     and pr.cd_procedimento = p.cd_procedimento
     and p.cd_procedimento = igp.cd_procedimento(+)
     and p.fl_tipo_exame in (0, 1)
     and pr.cd_procedimento not in ('99995555', '99996666', '99999999')
     and pr.dt_resultado is not null
     and pr.dt_libera_laudo is null
     and bio.dt_historico_fim is null
     and sysdate >= (case
           when a.cd_motivo_atendimento = 1 then
            bio.dt_historico +
            ((select pal.nu_tempo_emergencia from tb_param_laboratorio pal) / 1440)
           else
            bio.dt_historico +
            ((select pal.nu_tempo_eletivo from tb_param_laboratorio pal) / 1440)
         end)
  -- CONTROLE DA QUANTIDADE DE MUDANÇAS DE BIOQUÍMICO
   group by pe.nu_pedido,
            pe.dt_pedido,
            pe.cd_atendimento,
            pe.cd_ocorrencia,
            g.cd_pessoa_realiza,
            g.cd_setor_origem,
            a.cd_motivo_atendimento,
            pa.nm_paciente,
            igp.cd_grupo_produto,
            f.cd_pessoa
  having (select count(*)
           from tb_pedido_historico_bio bio2
          where bio2.nu_pedido = pe.nu_pedido
            and bio2.cd_ocorrencia = pe.cd_ocorrencia) <= (select (case
                                                                   when max(a.cd_motivo_atendimento) = 1 then
                                                                    pla.nu_mudanca_emergencia
                                                                   else
                                                                    pla.nu_mudanca_eletivo
                                                                 end)
                                                            from tb_param_laboratorio pla))
----------------------------------------------------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL E O PRAZO DE LIBERAÇÃO NÃO VENCEU
, consulta3 as
 (select pe.nu_pedido,
         pe.dt_pedido,
         pe.cd_atendimento,
         pe.cd_ocorrencia,
         g.cd_pessoa_realiza,
         g.cd_setor_origem,
         max(pr.cd_bioquimico_responsavel),
         min(pz.dt_prazo) dt_prazo,
         a.cd_motivo_atendimento,
         f.cd_pessoa,
         igp.cd_grupo_produto,
         pa.nm_paciente
    from tb_item_grupo_procedimento igp,
         tb_procedimento            p,
         tb_filial                  f,
         tm_setor                   s,
         tb_paciente                pa,
         tb_pedido_historico_bio    bio,
         tm_atendimento             a,
         tb_prazo_exame             pz,
         tb_pedido_exame            pe,
         tb_guia                    g,
         tb_procedimento_realizado  pr
   where 1 = 1
     and pr.cd_atendimento = g.cd_atendimento
     and pr.cd_ocorrencia = g.cd_ocorrencia
     and g.cd_atendimento = pe.cd_atendimento
     and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
     and pr.cd_atendimento = pz.cd_atendimento
     and pr.cd_ocorrencia = pz.cd_ocorrencia
     and pr.cd_ordem = pz.cd_ordem
     and pr.cd_atendimento = a.cd_atendimento
     and pe.nu_pedido = bio.nu_pedido
     and pe.cd_ocorrencia = bio.cd_ocorrencia
     and a.cd_paciente = pa.cd_paciente
     and pr.cd_setor = s.cd_setor
     and pr.cd_procedimento = p.cd_procedimento
     and s.cd_setor_emp = f.cd_filial
     and p.cd_procedimento = igp.cd_procedimento(+)
     and p.fl_tipo_exame in (0, 1)
     and pr.cd_procedimento not in ('99995555', '99996666', '99999999')
     and pr.dt_resultado is not null
     and pr.dt_libera_laudo is null
     and bio.dt_historico_fim is null
     and sysdate <= (case
           when a.cd_motivo_atendimento = 1 then
            bio.dt_historico +
            ((select pal.nu_tempo_emergencia from tb_param_laboratorio pal) / 1440)
           else
            bio.dt_historico +
            ((select pal.nu_tempo_eletivo from tb_param_laboratorio pal) / 1440)
         end)
   group by pe.nu_pedido,
            pe.dt_pedido,
            pe.cd_atendimento,
            pe.cd_ocorrencia,
            g.cd_pessoa_realiza,
            g.cd_setor_origem,
            a.cd_motivo_atendimento,
            f.cd_pessoa,
            igp.cd_grupo_produto,
            pa.nm_paciente)
------------------------------------------------------------------------------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL, O PRAZO DE LIBERAÇÃO VENCEU E NÃO É POSSÍVEL REALIZAR MUDANÇA
,consulta4 as (
select pe.nu_pedido,
         pe.dt_pedido,
         pe.cd_atendimento,
         pe.cd_ocorrencia,
         pa.nm_paciente,
         g.cd_pessoa_realiza,
         g.cd_setor_origem,
         max(pr.cd_bioquimico_responsavel) cd_bioquimico_responsavel,
         min(pz.dt_prazo) dt_prazo,
         a.cd_motivo_atendimento,
         igp.cd_grupo_produto,
         f.cd_pessoa
from tb_item_grupo_procedimento igp,
     tb_procedimento            p,
     tb_filial                  f,
     tm_setor                   s,
     tb_paciente                pa,
     tb_pedido_historico_bio    bio,
     tm_atendimento             a,
     tb_prazo_exame             pz,
     tb_pedido_exame            pe,
     tb_guia                    g,
     tb_procedimento_realizado  pr
where 1 = 1
    and pr.cd_atendimento = g.cd_atendimento
     and pr.cd_ocorrencia = g.cd_ocorrencia
     and g.cd_atendimento = pe.cd_atendimento
     and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
     and pr.cd_atendimento = pz.cd_atendimento
     and pr.cd_ocorrencia  = pz.cd_ocorrencia
     and pr.cd_ordem = pz.cd_ordem
     and pr.cd_atendimento = a.cd_atendimento
     and pe.nu_pedido = bio.nu_pedido
     and pe.cd_ocorrencia = bio.cd_ocorrencia
     and a.cd_paciente = pa.cd_paciente
     and pr.cd_setor = s.cd_setor
     and s.cd_setor_emp = f.cd_filial
     and pr.cd_procedimento = p.cd_procedimento
     and p.cd_procedimento = igp.cd_procedimento(+)
     and p.fl_tipo_exame in (0, 1)
     and pr.cd_procedimento not in ('99995555', '99996666', '99999999')
     and pr.dt_resultado is not null
     and pr.dt_libera_laudo is null
     and bio.dt_historico_fim is null
     and sysdate >= (case
           when a.cd_motivo_atendimento = 1 then
            bio.dt_historico +
            ((select pal.nu_tempo_emergencia from tb_param_laboratorio pal) / 1440)
           else
            bio.dt_historico +
            ((select pal.nu_tempo_eletivo from tb_param_laboratorio pal) / 1440)
         end)
  -- CONTROLE DA QUANTIDADE DE MUDANÇAS DE BIOQUÍMICO
   group by pe.nu_pedido,
            pe.dt_pedido,
            pe.cd_atendimento,
            pe.cd_ocorrencia,
            pa.nm_paciente,
            g.cd_pessoa_realiza,
            g.cd_setor_origem,
            pz.dt_prazo,
            a.cd_motivo_atendimento,
            igp.cd_grupo_produto,
            f.cd_pessoa
  having (select count(*)
            from tb_pedido_historico_bio bio2
           where bio2.nu_pedido = pe.nu_pedido
             and bio2.cd_ocorrencia = pe.cd_ocorrencia) > (select (case
                                                                    when max(a.cd_motivo_atendimento) = 1 then
                                                                     pla.nu_mudanca_emergencia
                                                                    else
                                                                     pla.nu_mudanca_eletivo
                                                                  end)
                                                             from tb_param_laboratorio pla)
)
------------------------------------------------------------------------------------------------------------------
---- CONSULTA PRINCIPAL
---  PEDIDOS COM RESULTADO E SEM BIOQUÍMICO RESPONSÁVEL
select x.nu_pedido,
       x.dt_pedido,
       x.cd_atendimento,
       x.cd_ocorrencia,
       x.nm_paciente,
       x.cd_pessoa_realiza,
       x.cd_setor_origem,
       nvl((select /*+ FIRST_ROWS(1) */
            1 fl_protocolo
             from tb_protocolo_exame_sa  aa,
                  tb_exame_solicitado_sa a
            where 1 = 1
                 --- Filtros
              and a.nu_pedido = x.nu_pedido
              and a.dt_pedido = x.dt_pedido
                 --- Joins
                 --- aa -- a
              and aa.cd_senha_master = a.cd_senha_master
              and aa.cd_atendimento = a.cd_atendimento
              and aa.cd_procedimento = a.cd_procedimento
              and aa.cd_exame = a.cd_exame
              and rownum = 1),
           0) fl_protocolo,
       null cd_bioquimico_responsavel,
       gp.cd_grupo_produto,
       gp.nm_grupo_produto,
       ep.nm_cidade_endereco,
       ep.cd_uf_endereco,
       x.dt_prazo dt_prazo,
       x.cd_motivo_atendimento
  from tb_grupo_produto           gp,
       tb_endereco_pessoa         ep,
       consulta1                  x
where   1 = 1
   and x.cd_pessoa = ep.cd_pessoa
   and x.cd_grupo_produto = gp.cd_grupo_produto
union all
-------------------------------------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL, O PRAZO DE LIBERAÇÃO VENCEU E É POSSÍVEL REALIZAR MUDANÇA
select x.nu_pedido,
       x.dt_pedido,
       x.cd_atendimento,
       x.cd_ocorrencia,
       x.nm_paciente,
       x.cd_pessoa_realiza,
       x.cd_setor_origem,
       nvl((select /*+ FIRST_ROWS(1) */
            1 fl_protocolo
             from tb_protocolo_exame_sa  aa,
                  tb_exame_solicitado_sa a
            where 1 = 1
                 --- Filtros
              and a.nu_pedido = x.nu_pedido
              and a.dt_pedido = x.dt_pedido
                 --- Joins
                 --- aa -- a
              and aa.cd_senha_master = a.cd_senha_master
              and aa.cd_atendimento = a.cd_atendimento
              and aa.cd_procedimento = a.cd_procedimento
              and aa.cd_exame = a.cd_exame
              and rownum = 1),
           0) fl_protocolo,
       null cd_bioquimico_responsavel,
       gp.cd_grupo_produto,
       gp.nm_grupo_produto,
       ep.nm_cidade_endereco,
       ep.cd_uf_endereco,
       x.dt_prazo dt_prazo,
       x.cd_motivo_atendimento
  from tb_grupo_produto           gp,
       tb_endereco_pessoa         ep,
       consulta2                  x
 where 1 = 1
   and x.cd_pessoa = ep.cd_pessoa
   and x.cd_grupo_produto = gp.cd_grupo_produto
union all
------------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL E O PRAZO DE LIBERAÇÃO NÃO VENCEU
select x.nu_pedido,
       x.dt_pedido,
       x.cd_atendimento,
       x.cd_ocorrencia,
       x.nm_paciente,
       x.cd_pessoa_realiza,
       x.cd_setor_origem,
       nvl((select /*+ FIRST_ROWS(1) */
            1 fl_protocolo
             from tb_protocolo_exame_sa  aa,
                  tb_exame_solicitado_sa a
            where 1 = 1
                 --- Filtros
              and a.nu_pedido = x.nu_pedido
              and a.dt_pedido = x.dt_pedido
                 --- Joins
                 --- aa -- a
              and aa.cd_senha_master = a.cd_senha_master
              and aa.cd_atendimento = a.cd_atendimento
              and aa.cd_procedimento = a.cd_procedimento
              and aa.cd_exame = a.cd_exame
              and rownum = 1),
           0) fl_protocolo,
       null cd_bioquimico_responsavel,
       gp.cd_grupo_produto,
       gp.nm_grupo_produto,
       ep.nm_cidade_endereco,
       ep.cd_uf_endereco,
       x.dt_prazo dt_prazo,
       x.cd_motivo_atendimento
  from tb_grupo_produto           gp,
       tb_endereco_pessoa         ep,
       consulta3                  x
 where 1 = 1
   and x.cd_pessoa = ep.cd_pessoa
   and x.cd_grupo_produto = gp.cd_grupo_produto
union all
------------------------------------------------------------------------------------------------------------
-- PEDIDOS QUE POSSUI BIOQUÍMICO RESPONSÁVEL, O PRAZO DE LIBERAÇÃO VENCEU E NÃO É POSSÍVEL REALIZAR MUDANÇA
 select x.nu_pedido,
         x.dt_pedido,
         x.cd_atendimento,
         x.cd_ocorrencia,
         x.nm_paciente,
         x.cd_pessoa_realiza,
         x.cd_setor_origem,
         nvl((select /*+ FIRST_ROWS(1) */
              1 fl_protocolo
               from tb_protocolo_exame_sa aa, tb_exame_solicitado_sa a
              where 1 = 1
                   --- Filtros
                and a.nu_pedido = x.nu_pedido
                and a.dt_pedido = x.dt_pedido
                   --- Joins
                   --- aa -- a
                and aa.cd_senha_master = a.cd_senha_master
                and aa.cd_atendimento = a.cd_atendimento
                and aa.cd_procedimento = a.cd_procedimento
                and aa.cd_exame = a.cd_exame
                and rownum = 1),
             0) fl_protocolo,
         x.cd_bioquimico_responsavel,
         gp.cd_grupo_produto,
         gp.nm_grupo_produto,
         ep.nm_cidade_endereco,
         ep.cd_uf_endereco,
         x.dt_prazo,
         x.cd_motivo_atendimento
    from tb_grupo_produto           gp,
         tb_endereco_pessoa         ep,
         consulta4                   x
   where 1 = 1
     and x.cd_pessoa = ep.cd_pessoa
     and x.cd_grupo_produto = gp.cd_grupo_produto
/

