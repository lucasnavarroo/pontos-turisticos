create view VW_SAM_RECEITA_ATENDIMENTO as
    select ra.cd_atendimento,
       ra.cd_ocorrencia_plano,
       ra.cd_ordem_receita,
       to_char(ra.dt_receita, 'dd/mm/yyyy') dt_receita,
       fn_hora(ra.hr_receita) hr_receita,
       ra.fl_validado,
       ra.cd_profissional_valida,
       pro.nm_pessoa_razao_social nm_profissional_valida,
       to_char(ra.dt_transacao_valida, 'dd/mm/yyyy') dt_transacao_valida,
       ra.fl_cancelada,
       ra.nu_documento_id,
       ra.cd_ordem_plano_trat,
       ra.ds_receita,
       ra.ds_receita_especial
  from tb_receita_atendimento ra, vw_profissional pro
 where pro.cd_profissional = ra.cd_profissional_valida
 union all
 select ra.cd_atendimento,
       ra.cd_ocorrencia_plano,
       ra.cd_ordem_receita,
       to_char(ra.dt_receita, 'dd/mm/yyyy') dt_receita,
       fn_hora(ra.hr_receita) hr_receita,
       ra.fl_validado,
       null cd_profissional_valida,
       null nm_profissional_valida,
       to_char(ra.dt_transacao_valida, 'dd/mm/yyyy') dt_transacao_valida,
       ra.fl_cancelada,
       ra.nu_documento_id,
       ra.cd_ordem_plano_trat,
       ra.ds_receita,
       ra.ds_receita_especial
  from tb_receita_atendimento ra
 where ra.cd_profissional_valida is null
 order by 4 desc, 5 desc
/

