create view VW_SAM_PROCEDIMENTO_FILHO as
select cd_procedimento,
       cd_unidade_usual,
       case
         when nvl(fl_gas, 'N') = 'S' then
          'H'
         when nvl(cd_referencia, 'X') in
              ('TIPO_DRENO', 'TIPO_APARELHO') then
          'H'
         else
          null
       end fl_tipo_aprazamento,
       fl_tipo_exame,
       cd_procedimento_pai
  from tb_procedimento where cd_procedimento_pai is not null
/

