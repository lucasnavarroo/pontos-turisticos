create view VW_PEDIDO_EXAME_PA as
select   /*+driving_site(pa) */
         pe.cd_atendimento,
         a.cd_unidade_atendimento,
         a.cd_motivo_atendimento,
         pe.cd_ocorrencia,
         pe.nu_pedido,
         pe.dt_pedido,
         pe.nm_operador,
         pe.cd_ocorrencia_ocupacao,
         pe.cd_tipo_exame,
         pe.cd_tipo_entrega,
         substr(pa.nu_carteira_convenio,1,14) cd_usuario,
         pa.nu_cgc_cpf,
         pa.cd_paciente,
         pa.nm_paciente,
         pa.cd_sexo,
         pa.dt_nascimento,
         a.dt_atendimento,
         a.cd_tipo_atendimento,
         pe.hr_pedido
  from tb_paciente pa,
       tm_atendimento a,
       tb_pedido_exame pe
  where a.cd_atendimento = pe.cd_atendimento
    and pa.cd_paciente   = a.cd_paciente
/

