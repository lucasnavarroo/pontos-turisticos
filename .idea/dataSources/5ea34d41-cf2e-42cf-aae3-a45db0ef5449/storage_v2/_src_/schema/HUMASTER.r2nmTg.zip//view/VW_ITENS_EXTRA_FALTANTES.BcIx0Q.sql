create view VW_ITENS_EXTRA_FALTANTES as
select /*+ choose driving_site(cc) */
       c.id_kit, c.cd_atendimento, c.cd_unidade_atendimento, c.nm_unidade_atendimento, c.cd_procedimento, c.nm_procedimento, c.dt_transacao, c.cd_material, c.nm_material, c.qtd, c.status, c.cd_pessoa, cc.nm_pessoa_razao_social nm_pessoa
  from ((-- itens kit padrao
        select a.id_kit, a.cd_atendimento, ab.cd_unidade_atendimento, aba.nm_unidade_atendimento, a.cd_procedimento, ac.nm_procedimento, a.dt_transacao, aaaa.cd_mat_med cd_material, aaaaa.nm_material, aaaa.qt_produto qtd, 'F' status, a.cd_pessoa_func_montou cd_pessoa
          from         tb_procedimento           ac,
                          tb_unidade_atendimento aba,
                       tm_atendimento            ab,
                           tb_material           aaaaa,
                        tb_prod_grupo_proc       aaaa,
                     tb_param_grupo_proc         aaa,
                  tb_proc_grupo_proc             aa,
               tm_kit_cirurgia_lote              a
         where 1 = 1
           -- filtros
           and nvl(aaa.fl_ativo, 'S') = 'S'
           and aaaa.cd_grupo_prod_proc = 2
           -- join a -- aa
           and a.cd_procedimento = aa.cd_procedimento
           -- join aa -- aaa
           and aa.cd_param_grupo_proc = aaa.cd_param_grupo_proc
           -- join aaa -- aaaa
           and aaa.cd_param_grupo_proc = aaaa.cd_param_grupo_proc
           -- join aaaa -- aaaaa
           and aaaa.cd_mat_med = aaaaa.cd_material
           -- join a -- ab
           and a.cd_atendimento = ab.cd_atendimento
           -- join ab -- aba
           and ab.cd_unidade_atendimento = aba.cd_unidade_atendimento
           -- join a -- ac
           and a.cd_procedimento = ac.cd_procedimento
         minus
        -- itens kit bipado
        select a.id_kit, a.cd_atendimento, ab.cd_unidade_atendimento, aba.nm_unidade_atendimento, a.cd_procedimento, ac.nm_procedimento, a.dt_transacao, aa.cd_material, aaa.nm_material, nvl(sum(aa.qt_material),0) qtd, 'F' status, a.cd_pessoa_func_montou cd_pessoa
          from    tb_procedimento           ac,
                     tb_unidade_atendimento aba,
                  tm_atendimento            ab,
                     tb_material            aaa,
                  tb_item_kit_cirurgia_lote aa,
               tm_kit_cirurgia_lote         a
         where 1 = 1
           -- filtros
           and aa.cd_codigo_barra is not null
           -- join a -- aa
           and a.id_kit = aa.id_kit
           -- join aa -- aaa
           and aa.cd_material = aaa.cd_material
           -- join a -- ab
           and a.cd_atendimento = ab.cd_atendimento
           -- join ab -- aba
           and ab.cd_unidade_atendimento = aba.cd_unidade_atendimento
           -- join a -- ac
           and a.cd_procedimento = ac.cd_procedimento
         group by a.id_kit, a.cd_atendimento, ab.cd_unidade_atendimento, aba.nm_unidade_atendimento, a.cd_procedimento, ac.nm_procedimento, a.dt_transacao, aa.cd_material, aaa.nm_material, 'F', a.cd_pessoa_func_montou)
         union all
        -- itens extras
        select a.id_kit, a.cd_atendimento, aa.cd_unidade_atendimento, aaa.nm_unidade_atendimento, ab.cd_procedimento, aba.nm_procedimento, ab.dt_transacao, a.cd_material, ac.nm_material, sum(nvl(a.qt_dispensada, 0)) qtd, 'E' status, a.cd_pessoa_func_recebeu_extra cd_pessoa
          from    tb_material               ac,
                     tb_procedimento        aba,
                  tm_kit_cirurgia_lote      ab,
                     tb_unidade_atendimento aaa,
                  tm_atendimento            aa,
               tb_registro_saidas_extras    a
         where 1 = 1
           -- join a -- aa
           and a.cd_atendimento = aa.cd_atendimento
           -- join aa -- aaa
           and aa.cd_unidade_atendimento = aaa.cd_unidade_atendimento
           -- join a -- ab
           and a.id_kit = ab.id_kit
           -- join ab -- aba
           and ab.cd_procedimento = aba.cd_procedimento
           -- join a -- ac
           and a.cd_material = ac.cd_material
         group by a.id_kit, a.cd_atendimento, aa.cd_unidade_atendimento, aaa.nm_unidade_atendimento, ab.cd_procedimento, aba.nm_procedimento, ab.dt_transacao, a.cd_material, ac.nm_material, 'E', a.cd_pessoa_func_recebeu_extra) c,
         tb_pessoa@hapvida cc
 where 1 = 1
   -- join  c -- cc
   and c.cd_pessoa = cc.cd_pessoa
/

