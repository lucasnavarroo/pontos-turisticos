create view VW_PROCEDIMENTO_PLANTAO as
select "CD_MEDICO","DT_AGENDA","SS_AGENDA","HR_AGENDA","CD_PROCEDIMENTO" from tt_procedimento_plantao
/

