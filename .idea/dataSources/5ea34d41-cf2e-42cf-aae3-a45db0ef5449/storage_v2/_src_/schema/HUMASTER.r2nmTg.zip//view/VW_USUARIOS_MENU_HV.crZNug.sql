create view VW_USUARIOS_MENU_HV as
select "COD_USUARIO","COD_GRUPO" from tb_usuarios_menu@hapvida
/

