create view VW_RESULTADO_LAUDO_EXAME as
select cp.nu_carteira_convenio    cd_beneficiario,
       pac.cd_paciente            cd_prontuario,
       pr.cd_atendimento,
       g.nu_guia,
       e.nu_pedido,
       e.dt_pedido,
       e.cd_procedimento,
       p.nr_procedimento          nm_reduzido_procedimento,
       p.nm_procedimento          nm_extenso_procedimento,
       c.cd_convenio,
       pes.nm_pessoa_razao_social ds_convenio,
       lp.ds_laudo_medico         ds_texto_laudo_medico
  from tb_paciente               pac,
       tm_atendimento            a,
       tb_pessoa                 pes,
       tm_convenio               c,
       tb_laudo_paciente         lp,
       tb_procedimento           p,
       tb_procedimento_realizado pr,
       tb_convenio_pagador       cp,
       tb_guia                   g,
       tb_exame_solicitado_sa    e
 where g.cd_atendimento = e.cd_atendimento
   and g.nu_guia = e.nu_guia
   and cp.cd_atendimento = pr.cd_atendimento
   and cp.cd_convenio_pagador = 1
   and pr.cd_atendimento = g.cd_atendimento
   and pr.cd_ocorrencia = g.cd_ocorrencia
   and p.cd_procedimento = pr.cd_procedimento
   and lp.cd_atendimento = pr.cd_atendimento
   and lp.cd_ocorrencia = pr.cd_ocorrencia
   and lp.cd_ordem = pr.cd_ordem
   and c.cd_convenio = cp.cd_convenio_base
   and pes.cd_pessoa = c.cd_pessoa
   and a.cd_atendimento = pr.cd_atendimento
   and pac.cd_paciente = a.Cd_Paciente
   and e.cd_ocorrencia = pr.cd_ocorrencia
   and e.cd_ordem = pr.cd_ordem
/

