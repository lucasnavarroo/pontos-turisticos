create view VW_PROCEDIMENTO_CONVENIO as
select distinct pc.cd_tabela_procedimento,
       t.ds_tabela_procedimento,
       pc.dt_vigencia
  from tb_vl_procedimento_convenio pc,
       tb_tabela_procedimento t
 where t.cd_tabela_procedimento = pc.cd_tabela_procedimento
 order by 3 desc
/

