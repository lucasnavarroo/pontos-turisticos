create view VW_PROCEDIMENTOS_MODELO as
select /*
          Fred Monteiro - IVIA - 16/05/2018
          View que concentra todas as informacoes dos procedimentos padronizados ativos da tela T4131
       */
       ae.cd_modelo                                 cd_modelo,
       ae.ds_modelo                                 ds_modelo,
       a.cd_ocorrencia_procedimento                 cd_ocorrencia_procedimento,
       ad.cd_procedimento                           cd_procedimento_pai,
       ad.nm_procedimento                           nm_procedimento_pai,
       nvl(aaa.cd_tipo_anestesia, -99)              cd_tipo_anestesia,
       nvl(aaa.nm_tipo_anestesia, 'NÃO CADASTRADA') nm_tipo_anestesia,
       nvl(ab.tp_sala_cirurgica, 0)                 tp_sala_cirurgica,
       nvl(ab.tp_permanencia, 0)                    tp_permanencia,
       nvl(ab.tp_uti, 0)                            tp_uti,
       nvl(aca.cd_procedimento, ad.cd_procedimento) cd_procedimento_filho,
       nvl(aca.nm_procedimento, ad.nm_procedimento) nm_procedimento_filho
  from    tb_modelo_plano_tratamento    ae,  -- modelos
          tb_procedimento               ad,  -- descrucai do procedimento padronizado
             tb_procedimento            aca, -- descricao do procedimento filho
          tb_procedimento_modelo_filhos ac,  -- filhos do procedimento padronizado
          tb_procedimento_modelo_tempo  ab,  -- tempos do procedimento padronizado
             tb_tipo_anestesia          aaa, -- descricao da tecnica anestesica
          tb_procedimento_modelo_anest  aa,  -- tecnica anestesica do procedimento padronizado
       tb_procedimento_modelo           a    -- procedimento padronizado
 where 1 = 1
   -- filtros
   and a.fl_status + 0 = 1
   and ae.fl_tipo_modelo + 0 = 1
   -- join a -- aa
   and a.cd_modelo = aa.cd_modelo(+)
   and a.cd_ocorrencia_procedimento = aa.cd_ocorrencia_procedimento(+)
   -- join aa -- aaa
   and aa.cd_tipo_anestesia = aaa.cd_tipo_anestesia(+)
   -- join a -- ab
   and a.cd_modelo = ab.cd_modelo(+)
   and a.cd_ocorrencia_procedimento = ab.cd_ocorrencia_procedimento(+)
   -- join a -- ac
   and a.cd_modelo = ac.cd_modelo(+)
   and a.cd_ocorrencia_procedimento = ac.cd_ocorrencia_procedimento(+)
   -- join ac -- aca
   and ac.cd_procedimento = aca.cd_procedimento(+)
   -- join a -- ad
   and a.cd_procedimento = ad.cd_procedimento
   -- join a -- ae
   and a.cd_modelo = ae.cd_modelo
/

