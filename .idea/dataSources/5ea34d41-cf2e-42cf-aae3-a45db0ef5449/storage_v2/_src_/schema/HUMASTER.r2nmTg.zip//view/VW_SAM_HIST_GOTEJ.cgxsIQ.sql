create view VW_SAM_HIST_GOTEJ as
select to_char(hg.dt_transacao, 'dd/mm/yyyy hh24:mi') dt_transacao,
       hg.qt_gotejamento_anterior,
       hg.qt_gotejamento,
       hg.cd_gotejamento_anterior,
       hg.cd_gotejamento,
       hg.cd_profissional_altera,
       hg.cd_atendimento,
       hg.cd_ocorrencia_plano,
       hg.cd_ordem_prescricao,
       hg.cd_ordem_hv,
       hg.cd_ordem_gotej,
       p.nm_pessoa_razao_social nm_profissional_altera
  from TB_HV_HISTORICO_GOTEJ hg, vw_profissional p
 where hg.cd_profissional_altera(+) = p.cd_profissional
/

