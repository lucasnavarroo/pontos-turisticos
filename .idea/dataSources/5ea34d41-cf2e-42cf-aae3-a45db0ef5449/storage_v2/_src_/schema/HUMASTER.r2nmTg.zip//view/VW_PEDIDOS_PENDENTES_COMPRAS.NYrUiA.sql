create view VW_PEDIDOS_PENDENTES_COMPRAS as
select b.cod_material            cd_material,
        a.id_pedido_compra       cd_pedido,
        a.dt_entrega             dt_prevista,
        a.obs              ds_situacao,
        (nvl(b.qtd,0) - nvl(qtd_atendida,0)) qt_pendente,
        f.nm_fornecedor                 nm_fornecedor,
        b.id_centro_custo        id_centro_custo,
        c.cd_filial              id_filial,
        s.cd_setor                  cd_setor
    from tb_filial c,
            gc_cotacao@matera e,
            gc_ordem_compra@matera d,
            gc_ordem_compra_item@matera b,
            gc_pedido_compra@matera a,
            tm_setor s,
            tb_fornecedor f
 where a.id_ordem_compra  = b.id_ordem_compra
    and a.id_filial       = c.id_filial_finpac
    and b.id_ordem_compra = d.id_ordem_compra
    and b.num_seq_item    = e.num_seq_item
    and b.id_ordem_compra = e.id_ordem_compra
    and a.id_forncd       = e.id_forncd
    and d.id_filial       = c.id_filial_finpac
    and d.dt_ordem_compra >= sysdate - 60
--    and a.dt_entrega      <= sysdate + 30
--  retirado por solicitação de Rodrigo com conhecimento da Paula Nunes
    and c.cd_filial       = s.cd_setor_emp
    and (nvl(b.qtd,0) - nvl(qtd_atendida,0)) > 0
    and a.cod_sit_pedido_compra in ('V','R')
    and a.id_forncd = f.cd_fornecedor(+)
/

