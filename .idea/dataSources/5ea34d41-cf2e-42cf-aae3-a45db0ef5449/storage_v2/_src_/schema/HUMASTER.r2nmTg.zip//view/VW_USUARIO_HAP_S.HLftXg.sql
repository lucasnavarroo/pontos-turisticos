create view VW_USUARIO_HAP_S as
select  "CD_USUARIO",
        "FL_STATUS_USUARIO",
        "DT_CANCELAMENTO",
        "CD_PESSOA",
        "NU_VIA",
        "FL_CUSTO_OPERACIONAL",
        "FL_TIPO_PLANO",
        "QT_DIAS_VENCIDOS",
        "NM_PESSOA_RAZAO_SOCIAL",
        "DT_NASCIMENTO_FUNDACAO",
        "QT_DIAS_LIMITE",
        "FL_ATENDIMENTO",
        "NU_USUARIO",
        "CD_PESSOA_TITULAR",
        "NM_PESSOA_TITULAR",
        "NU_CGC_CPF_TITULAR",
        "DT_CADASTRAMENTO",
        "CD_EMP_CONVENIADA",
        "NM_EMPRESA_CONVENIADA",
        "CD_USUARIO_EMPRESA_PARCEIRA",
        "CD_TIPO_ACOMODACAO",
        "FL_TIPO_EMPRESA",
        "FL_SEXO"
     from vw_usuario_hap@hapvida
/

