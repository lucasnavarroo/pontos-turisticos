create view TB_INADIMPLENTES_ATENDIDOS as
select "CD_ATENDIMENTO","DT_ATENDIMENTO","QT_DIAS_ATRASO","NM_OPERADOR","CD_UNIDADE_ATENDIMENTO","FL_TIPO_PLANO" from tm_inadimplentes_atendidos
where cd_unidade_atendimento like fn_unidade
/

