create view VW_SAM_DADOS_PACIENTE as
select pac.cd_paciente cd_prontuario,
       pac.nm_paciente,
       to_char(pac.dt_nascimento, 'ddmmyyyy') dt_nascimento,
       pac.cd_sexo,
       pac.cd_cor,
       pac.fl_tipo_sanguineo,
       pac.fl_fator_rh,
       pac.cd_estado_civil,
       pac.nm_mae,
       pac.nu_cgc_cpf,
       pac.nm_municipio,
       pac.cd_uf,
       pac.NU_CARTEIRA_CONVENIO NU_CARTEIRA,
       decode(pac.NU_CARTEIRA_CONVENIO, null, null, substr(pac.NU_CARTEIRA_CONVENIO, 1, 14)) cd_usuario,
       nvl(to_char(trunc(months_between(trunc(sysdate),
                                        nvl(pac.dt_nascimento,
                                            trunc(sysdate))) / 12)),
           0) nr_idade,
       Pac.NU_RG || ' ' || Pac.CD_ORGAO_EXPEDIDOR || ' ' || Pac.CD_UF_ORGAO RG,
       Pac.NU_CARTEIRA_PROF || Pac.NU_SERIE CP,
       Pac.CD_TIPO_ENDERECO || ' ' || Pac.NM_ENDERECO || ',' || Pac.NU_ENDERECO ||
       ' - ' || Pac.NM_BAIRRO || ', ' || Pac.NM_MUNICIPIO || '(' || Pac.CD_UF || ')' ||
       DECODE(Pac.NU_CEP, NULL, '', ' CEP ') || TO_CHAR(Pac.NU_CEP) NM_ENDERECO,
       pac.NU_CEP,
       pac.NU_TELEFONE,
       pac.NU_RAMAL,
       pac.NU_TELEFONE_TRABALHO
  from tb_paciente pac
/

