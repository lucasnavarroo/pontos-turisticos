create view VW_OBRIGACAO_PEND_ENV_FINPAC as
select /*+ choose*/
       rowidtochar(o.rowid) ri_obrigacao,
       o.dt_vencimento,
       o.vl_bruto,
       o.dt_emissao,
       o.cd_obrigacao,
       o.cd_documento_gerador,
       o.dt_liberou_obrigacao,
       o.cd_filial,
       o.cd_cedente_sacado,
       o.cd_unidade_atendimento,
       o.cd_oper_liberou
 from
       tm_obrigacao o
where o.cd_status in (1,2) --EM ABERTO, LIQUIDACAO PARCIAL
  and o.cd_tipo_obrigacao = 2 --A RECEBER
  and o.dt_emissao        < trunc(sysdate + 4)
  and o.cd_documento_gerador is not null
  and (SUBSTR(o.CD_DOCUMENTO_GERADOR, 1, INSTR(o.CD_DOCUMENTO_GERADOR, ' ')) IS NOT NULL) --DOCUMENTO GERADOR POSSUI REMESSA E TIPO DE ARQUIVO
  and o.dt_liberou_obrigacao is null
  and o.cd_oper_liberou is null
  and not exists (select /*+ choose driving_site(x) */
                         'X'
                    from tb_obrigacao_finpac@hapvida x
                   where x.cd_obrigacao        = o.cd_obrigacao
                     and x.cd_sistema_origem   = 2 --CONTAS A RECEBER
                     and x.cd_origem_obrigacao = 2 --HOSPITAL
                     and rownum = 1)
  and exists (select /*+ choose driving_site(ps) */
                     'Y'
                from tb_producao_servico@hapvida ps,
                     tb_item_remessa_convenio ir
                where ir.cd_obrigacao = o.cd_obrigacao
                  and ir.cd_processo_hapvida is not null
                  and ps.dt_pagamento is not null
                  and ps.vl_servico_prestado is not null
                  and ps.fl_status is not null
                  and ps.nu_ordem = ir.cd_processo_hapvida
                  and rownum = 1)
/

