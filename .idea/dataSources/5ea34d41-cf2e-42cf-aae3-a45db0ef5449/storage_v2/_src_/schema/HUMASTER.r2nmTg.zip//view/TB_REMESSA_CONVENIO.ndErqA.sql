create view TB_REMESSA_CONVENIO as
select nu_remessa,
         cd_empresa_cobra,
         cd_convenio,
         dt_remessa,
         dt_inicio,
         dt_fim,
         dt_pagamento,
         vl_total_honorario,
         vl_total_diaria,
         vl_total_taxa,
         vl_total_mat,
         vl_total_med,
         dt_processamento,
         cd_usuario,
         vl_total_outros,
         fl_status,
         cd_unidade_atendimento,
         nu_seq_remessa,
         nu_remessa_origem,
         fl_custo_operacional,
         cd_classe_atendimento,
         fl_gerar_automaticamente
    from humaster.tm_remessa_convenio
   where cd_unidade_atendimento like humaster.fn_unidade
/

