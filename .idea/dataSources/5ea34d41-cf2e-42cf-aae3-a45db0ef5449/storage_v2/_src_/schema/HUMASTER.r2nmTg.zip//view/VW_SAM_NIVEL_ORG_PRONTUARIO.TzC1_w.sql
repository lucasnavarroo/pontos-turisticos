create view VW_SAM_NIVEL_ORG_PRONTUARIO as
SELECT level nivel,
       cd_organizacao_prontuario || ' ' || nm_organizacao_prontuario nm_organizacao_prontuario,
       cd_organizacao_prontuario
  FROM TB_ORGANIZACAO_PRONTUARIO OP
CONNECT BY PRIOR
            OP.cd_organizacao_prontuario = OP.cd_organizacao_prontuario_pai
 START WITH OP.cd_organizacao_prontuario_pai IS NULL
 ORDER SIBLINGS BY OP.nu_ordem_apresentacao
/

