create view VW_INTERFACEAMENTO_ERRO as
select er.cd_filial,
       er.cd_processo,
       er.cd_erro,
       er.dt_erro,
       ec.ds_correcao,
       ec.dt_correcao,
       ec.cd_operador
from tb_interfaceamento_erro er,
     tb_interfaceamento_correcao ec
where ec.cd_interfaceamento_erro = er.cd_interfaceamento_erro
/

