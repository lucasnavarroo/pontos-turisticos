create view VW_LAUDO_SEM_ARQUIVO as
select lp.cd_atendimento,
       lp.cd_ocorrencia,
       lp.cd_ordem,
       pe.nu_pedido,
       pe.dt_pedido,
       p.cd_procedimento,
       pr.dt_libera_laudo
  from tb_classe_medico cm,
       tb_modalidade_worklist w,
       tb_setor_pacs sp,
        tb_item_grupo_produto igp,
       tm_setor se,
       tb_assinatura_medico as1,
       tb_procedimento p,
       tb_profissional pf,
       tb_laudo_arquivo la,
       tb_laudo_paciente lp,
       tb_pedido_exame pe,
       tm_atendimento a,
       tb_guia g,
       tb_procedimento_realizado pr,
       tb_prof_proced_realizado ppr
  where 1=1
    and pr.cd_atendimento = ppr.cd_atendimento
    and pr.cd_ocorrencia = ppr.cd_ocorrencia
    and pr.cd_ordem = ppr.cd_ordem
    and as1.cd_medico(+) = ppr.cd_profissional
    and a.cd_atendimento = pr.cd_atendimento
    and g.cd_atendimento = pr.cd_atendimento
    and g.cd_ocorrencia = pr.cd_ocorrencia
    and g.cd_atendimento = a.cd_atendimento
    and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
    and g.cd_setor_origem = se.cd_setor
    and pe.cd_atendimento = a.cd_atendimento
    and pr.cd_procedimento = p.cd_procedimento
    and pr.cd_atendimento = lp.cd_atendimento
    and pr.cd_ocorrencia = lp.cd_ocorrencia
    and pr.cd_ordem = lp.cd_ordem
    and p.cd_procedimento = igp.cd_produto
    and igp.cd_grupo_produto = w.cd_grupo_produto
    and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem = la.na_accessionnumber
    and se.cd_setor_pacs = sp.cd_setor_pacs
    and ppr.cd_profissional = pf.cd_profissional
    and cm.cd_classe_medico(+) = pf.cd_classe_medico
    and pr.dt_libera_laudo is not null
    and la.bl_arquivo is null
    and p.fl_tipo_exame in (2,7)
    and ppr.cd_tipo_ato_profissional = 20
    and round(to_number(sysdate - pr.dt_libera_laudo) * 1440) > nvl(cm.nu_tempo_correcao,0)
/

