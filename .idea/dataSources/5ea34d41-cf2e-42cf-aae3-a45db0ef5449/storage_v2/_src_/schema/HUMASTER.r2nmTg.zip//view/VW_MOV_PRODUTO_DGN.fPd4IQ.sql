create view VW_MOV_PRODUTO_DGN as
    select /*+ ordered index(s CT_SETOR1) */
       a.cd_atendimento,
       a.cd_unidade_atendimento,
       n.cd_setor_destino cd_posto,
       s.nm_setor nm_posto,
       n.dt_comanda dt_comanda,
       m.cd_taxas cd_produto,
       m.qt_taxa qt_produto
from tb_comanda n,
     tb_comanda_taxa m,
     tm_atendimento a,
     tm_setor s
where
  n.fl_requisicao_devolucao in (1,3,5)
  and m.cd_atendimento = n.cd_atendimento
  and m.cd_ocorrencia = n.cd_ocorrencia
  and m.cd_ordem = n.cd_ordem
  and m.cd_ordem_cmd = n.cd_ordem_cmd
  and m.qt_taxa is not null
  and a.cd_atendimento = m.cd_atendimento
  and s.cd_setor = n.cd_setor_destino
union all
select /*+ index(a CP_ATENDIMENTO) index(s CT_SETOR1) */
 a.cd_atendimento,
 a.cd_unidade_atendimento,
 n.cd_setor_destino cd_posto,
 s.nm_setor nm_posto,
 n.dt_comanda dt_comanda,
 to_char(m.cd_mat_med) cd_produto,
 m.qt_material qt_produto
from tm_setor s,
     tm_atendimento a,
     tb_comanda_mat_med m,
     tb_comanda n
where
      n.cd_atendimento = m.cd_atendimento
  and n.cd_ocorrencia = m.cd_ocorrencia
  and n.cd_ordem = m.cd_ordem
  and n.cd_ordem_cmd = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and m.qt_material is not null
  and m.qt_material not in (0)
  and a.cd_atendimento = m.cd_atendimento
  and s.cd_setor = n.cd_setor_destino
union all
select /*+ index(s CT_SETOR1) */
       a.cd_atendimento,
       a.cd_unidade_atendimento,
       a.cd_setor cd_posto,
       s.nm_setor,
       pr.dt_procedimento_realizado dt_comanda,
       pr.cd_procedimento,
       nvl(pr.qt_procedimento,0)
from tm_setor s,
     tm_atendimento a,
     tb_procedimento_realizado pr
where
  pr.cd_procedimento not in ('99995555','99997777','99998888','99999999')
  and pr.cd_pessoa_cobra = fn_pessoa_unidade
  and pr.qt_procedimento is not null
  and a.cd_atendimento = pr.cd_atendimento
  and s.cd_setor = a.cd_setor
/

