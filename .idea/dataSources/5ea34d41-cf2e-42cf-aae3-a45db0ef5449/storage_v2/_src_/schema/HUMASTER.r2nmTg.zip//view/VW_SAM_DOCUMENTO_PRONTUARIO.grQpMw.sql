create view VW_SAM_DOCUMENTO_PRONTUARIO as
select nu_documento_id,
       cd_atendimento,
       cd_paciente,
       cd_organizacao_prontuario,
       to_char(dt_documento, 'dd/mm/yyyy hh24:mi') dt_documento,
       SUBSTR(USER_ID, 1, INSTR(USER_ID, ':', 1) - 1) nm_medico,
       t.ds_status
  from tb_documento_prontuario t
/

