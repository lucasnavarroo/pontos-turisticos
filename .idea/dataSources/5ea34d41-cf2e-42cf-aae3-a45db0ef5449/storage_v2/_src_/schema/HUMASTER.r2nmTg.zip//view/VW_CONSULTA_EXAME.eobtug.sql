create view VW_CONSULTA_EXAME as
select cp.nu_carteira_convenio    cd_beneficiario,
       pac.cd_paciente            cd_prontuario,
       e.cd_exame,
       e.cd_atendimento,
       g.nu_guia,
       e.nu_pedido,
       e.cd_ocorrencia,
       e.cd_ordem,
       e.dt_pedido,
       e.cd_procedimento,
       p.nr_procedimento          nm_reduzido_procedimento,
       p.nm_procedimento          nm_extenso_procedimento,
       c.cd_convenio,
       pes.nm_pessoa_razao_social ds_convenio,
       e.fl_exame_cancelado
  from tb_paciente            pac,
       tm_atendimento         a,
       tb_pessoa              pes,
       tm_convenio            c,
       tb_procedimento        p,
       tb_convenio_pagador    cp,
       tb_guia                g,
       tb_exame_solicitado_sa e
 where g.cd_atendimento = e.cd_atendimento
   and g.nu_guia = e.nu_guia
   and cp.cd_atendimento = e.cd_atendimento
   and cp.cd_convenio_pagador = 1
   and p.cd_procedimento = e.cd_procedimento
   and c.cd_convenio = cp.cd_convenio_base
   and pes.cd_pessoa = c.cd_pessoa
   and a.cd_atendimento = e.cd_atendimento
   and pac.cd_paciente = a.cd_paciente
/

