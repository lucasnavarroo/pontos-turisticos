create view VW_CARENCIA_HV as
select "CD_CARENCIA","NM_CARENCIA","NR_CARENCIA","FL_EMISSAO","FL_SEXO" from tb_carencia@hapvida
/

