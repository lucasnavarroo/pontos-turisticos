create view VW_SAM_DOCUMENTOS_PENDENTES as
select /*+ parallel(pa,12) parallel(dp,12) */
  dp.NU_DOCUMENTO_ID,
  to_char(dp.DT_DOCUMENTO, 'dd/mm/yyyy hh24:mi') DT_DOCUMENTO,
  dp.DS_STATUS ds_status_documento,
  dp.DS_OBSERVACAO, --jsonignore
  dp.CD_ATENDIMENTO,
  rowidtochar(dp.rowid) rowid_documento_prontuario, --jsonignore
  rowidtochar(pa.rowid) rowid_pendencia_assinatura, --jsonignore
  pa.nu_pendencia_assinatura, --jsonignore
  pa.nm_operador,
  pa.ds_operador,
  tdp.nm_tipo_documento_prontuario,
  dbms_lob.substr(pa.ds_motivo_assinatura, 4000, 1) ds_motivo_assinatura, --jsonignore
  pa.ds_local_assinatura, --jsonignore
  pa.cd_nivel, --jsonignore
  pa.ds_status ds_status_assinatura,
  oc.user_id, --jsonignore
  p.nm_paciente,
  a1.ds_alias user_id_a1 --jsonignore
   from tb_paciente                  p,
        adm.tb_certificado           oc,
        tb_documento_prontuario      dp,
        tb_pendencia_assinatura      pa,
        tb_tipo_documento_prontuario tdp,
        tb_sign_key                  a1
  where dp.nu_documento_id = pa.nu_documento_id
    and pa.nm_operador = oc.NM_OPERADOR(+)
    and pa.nm_operador = a1.nm_operador(+)
    and p.cd_paciente = dp.cd_paciente
    and dp.cd_tipo_documento_prontuario = tdp.cd_tipo_documento_prontuario
    and dp.ds_status = 'PENDENTE'
    and pa.ds_status = 'PENDENTE'
    and rowidtochar(pa.rowid) not in
        (select max(rowid)
           from tb_pendencia_assinatura b
          where b.nm_operador = dp.nm_operador
            and b.ds_status = 'PENDENTE'
          group by b.nu_documento_id
         having count(1) > 1)
/

