create view VW_ACOMODACAO as
select b."CD_ACOMODACAO",b."CD_CLASSE_ACOMODACAO",b."CD_POSTO",b."QT_LEITOS",b."FL_ATIVO",b."CD_UNIDADE_ATENDIMENTO",a.nm_classe_acomodacao,
       c.nm_setor,
       c.ds_localizacao
from tb_classe_acomodacao a, tb_acomodacao b, tb_setor c
where a.cd_classe_acomodacao=b.cd_classe_acomodacao and
      c.cd_setor=b.cd_posto
/

