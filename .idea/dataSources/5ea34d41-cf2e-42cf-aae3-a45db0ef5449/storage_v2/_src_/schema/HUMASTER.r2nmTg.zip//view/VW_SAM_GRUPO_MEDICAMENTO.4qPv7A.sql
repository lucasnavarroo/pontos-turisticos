create view VW_SAM_GRUPO_MEDICAMENTO as
    select cd_indicacao_terapeutica cd_item,
       nm_indicacao_terapeutica nm_item,
       'I' grupo
  from tb_indicacao_terapeutica
union
select cd_principio_ativo, nm_principio_ativo, 'P'
  from tb_principio_ativo
union
select cd_grupo_farmacologico, nm_grupo_farmacologico, 'F'
  from tb_grupo_farmacologico
union
select cd_generico, nm_generico, 'G'
  from tb_medicamento_generico
union
select c.cd_classificacao, c.nm_classificacao, 'C'
  from tb_classificacao c, tb_tipo_classificacao cl
 where cl.cd_tipo_classificacao = c.cd_tipo_classificacao
   and cl.cd_tipo_classificacao in
       (select cd_tipo_classificacao
          from tb_tipo_classificacao
         where fl_tipo_classificacao in (1, 2))
order by 3, 1
/

