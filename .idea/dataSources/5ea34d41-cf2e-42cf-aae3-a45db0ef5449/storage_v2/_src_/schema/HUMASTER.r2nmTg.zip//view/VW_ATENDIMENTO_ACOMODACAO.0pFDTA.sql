create view VW_ATENDIMENTO_ACOMODACAO as
select a."CD_ATENDIMENTO",a."CD_PACIENTE",a."CD_MOTIVO_ATENDIMENTO",a."FL_NIVEL",a."DT_ATENDIMENTO",a."HR_ATENDIMENTO",a."CD_ATENDIMENTO_MAE",a."CD_SETOR",a."CD_CLINICA",a."CD_MEDICO_ATENDENTE",a."CD_MEDICO_ACOMPANHA",a."CD_ENCAMINHA",a."CD_TIPO_ATENDIMENTO",a."CD_GRUPO_ATENDIMENTO",a."CD_MATRICULA",a."CD_TIPO_DOCUMENTO",a."CD_CONDICAO_SOCIAL",a."CD_ESTADO_PACIENTE",a."CD_ASPECTO",a."CD_PROCEDENCIA",a."CD_NATUREZA_CONSULTA",a."NM_QUEIXA_PRINCIPAL",a."FL_TOMA_ANTIBIOTICO",a."FL_INTERNACAO",a."DT_FIM_ATENDIMENTO",a."HR_FIM_ATENDIMENTO",a."QT_PESO",a."QT_TAMANHO",a."DS_OBSERVACAO",a."CD_USUARIO_DIGITADOR",a."NU_PEDIDO_POSTO",a."FL_DIFERENCA_ACOMODACAO",a."CD_UNIDADE_ATENDIMENTO",a."VL_GLOSA",a."VL_GLOSA_ANALISAR",a."DT_CANC_ATEND",a."CD_DIAGNOSTICO",a."DT_ENT_CONTROLADORIA",a."DT_ENT_FATURAMENTO",a."FL_BLOQUEIO",a."DT_BLOQUEIO",a."CD_USUARIO",a."DT_COLETA_DIGITAL",a."CD_ATENDIMENTO_ORIGEM",a."FL_GERADO_AUTO",a."DT_COLETA_DIGITAL_EXAME",a."DS_JUST_CONS_RETORNO",a."CD_USU_LIBEROU_RETORNO",a."DT_ENT_PRONT_AUDITORIA",a."DT_DEV_PRONT_PENDENCIA",a."DT_ENT_NSALA_AUDITORIA",a."CD_USUARIO_CANCELOU",a."NU_GAB",a."FL_TIPO_GAB",a."DS_JUST_AUT_DOC",a."DT_AUT_DOC",a."CD_USU_AUT_DOC",a."CD_ATENDIMENTO_CONTIGUO",
       to_date(to_char(a.dt_atendimento,'dd/mm/yyyy')||' '||fn_hora(a.hr_atendimento)||':00','dd/mm/yyyy hh24:mi:ss') dt_atendimento_fn,
       oa.cd_ocorrencia, oa.fl_ocupacao, cd_acomodacao, oa.cd_posto, oa.cd_classe_acomodacao, oa.nu_leito, dt_ocupacao, hr_ocupacao,
       to_date(to_char(oa.dt_ocupacao,'dd/mm/yyyy')||' '||fn_hora(oa.hr_ocupacao)||':00','dd/mm/yyyy hh24:mi:ss') dt_ocupacao_fn,
       oa.dt_liberacao, oa.hr_liberacao
  from tb_ocupacao_acomodacao oa,
       tm_atendimento a
 where a.dt_atendimento between sysdate - 30
                            and sysdate
   and a.dt_canc_atend is null
   and a.cd_tipo_atendimento in (0, 7, 8)
   and oa.cd_atendimento = a.cd_atendimento
/

