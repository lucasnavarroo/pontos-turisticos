create view VW_OPERACAO_CCUSTO as
    select
 m.dt_emissao_documento dt_emissao,
 M.CD_FILIAL               ,
 x.cd_centro_custo         ,
 c.cd_classe_tipo_operacao ,
 c.nm_classe_tipo_operacao ,
 t.cd_tipo_operacao        ,
 t.nm_tipo_operacao        ,
 ot.CD_OPERACAO             ,
 o.nm_operacao             ,
 m.VL_TRANSACAO*x.vl_rateio/100*ot.vl_rateio/100 vl_centro_custo,
 h.ds_historico_padrao||' '||m.nm_historico nm_historico
from tb_historico_padrao h,
     tb_classe_tipo_operacao c,tb_tipo_operacao t,tb_operacao o,
     tb_centro_custo_transacao x,tb_operacao_transacao ot,
     tm_movimento_transacao m, tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta and
   ot.cd_movimento_conta = m.cd_movimento_conta and
   ot.cd_ordem_transacao = m.cd_ordem_transacao and
   x.cd_movimento_conta = m.cd_movimento_conta and
   x.cd_ordem_transacao = m.cd_ordem_transacao and
   o.cd_operacao = ot.cd_operacao and
   t.cd_tipo_operacao = o.cd_tipo_operacao and
   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao and
   v.dt_estorno is null and v.fl_movimento_conta = 2 and
   h.cd_historico_padrao(+) = m.cd_historico_padrao
union all
select
 m.dt_emissao,
 m.CD_FILIAL               ,
 x.cd_centro_custo         ,
 c.cd_classe_tipo_operacao ,
 c.nm_classe_tipo_operacao ,
 t.cd_tipo_operacao        ,
 t.nm_tipo_operacao        ,
 ot.CD_OPERACAO             ,
 o.nm_operacao             ,
 decode(nvl(m.VL_SALDO_OBRIGACAO,0),0,m.vl_obrigacao,m.vl_saldo_obrigacao)*x.vl_rateio/100*ot.vl_rateio/100 vl_centro_custo,
 decode(m.cd_tipo_obrigacao,1,'REF PAG A ','REF REC DE ')||p.nm_pessoa_razao_social nm_historico
from tb_pessoa p,
     tb_classe_tipo_operacao c,tb_tipo_operacao t,tb_operacao o,
     tb_centro_custo_obrigacao x,tb_operacao_obrigacao ot,tm_obrigacao m,
     tb_movimento_obrigacao om
where   m.cd_obrigacao = om.cd_obrigacao and
   ot.cd_obrigacao = m.cd_obrigacao and
   x.cd_obrigacao = m.cd_obrigacao and
   o.cd_operacao = ot.cd_operacao and
   t.cd_tipo_operacao = o.cd_tipo_operacao and
   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao and
   m.cd_status<>8 and
   p.cd_pessoa = m.cd_cedente_sacado
/

