create view VW_SAM_AEROSSOL_MED as
select cd_atendimento,
       cd_ocorrencia_plano,
       cd_ordem_prescricao,
       cd_ordem_proc_plano_uso,
       cd_mat_med,
       nu_produto,
       qt_dosagem,
       cd_unidade_usual,
       qt_frequencia_uso,
       fl_frequencia_uso,
       cd_tipo_acesso,
       fl_necessario,
       fl_acm,
       fl_validado,
       fl_status_uso,
       cd_ordem_prescricao_plano,
       ds_observacao
  from TB_PRESCRICAO_PLANO
 where cd_tipo_prescricao_plano = 3
 order by decode(cd_tipo_prescricao_plano,
                 2,
                 nvl(nu_ordem_apresentacao, 999),
                 999),
          decode(cd_prescricao_plano_pai,
                 null,
                 cd_ordem_prescricao_plano,
                 cd_prescricao_plano_pai),
          cd_ordem_prescricao_plano
/

