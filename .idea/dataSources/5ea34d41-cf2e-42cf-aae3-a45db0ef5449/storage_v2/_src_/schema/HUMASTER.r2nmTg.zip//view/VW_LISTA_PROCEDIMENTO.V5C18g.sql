create view VW_LISTA_PROCEDIMENTO as
select distinct pro.cd_procedimento,
                pro.nr_procedimento,
                pro.nm_procedimento,
                pro.fl_cirurgia cd_classe_procedimento,
                decode(pro.fl_cirurgia,
                       0,
                       'outros',
                       1,
                       'cirurgico',
                       2,
                       'exames',
                       3,
                       'parenteral',
                       'outros') ds_classe_procedimento,
                tp.cd_tipo_procedimento cd_tp_procedimento,
                tp.nm_tipo_procedimento nm_tp_procedimento,
                fl_membros_pares,
                fl_parto,
                fl_permite_atestado,
                fl_procedimento_ficticio,
                fl_procedimento_vida_imagem,
                fl_protocolo_sepse,
                fl_solic_inter_na_emergencia,
                fl_somente_emergencia,
                fl_somente_internacao,
                fl_tipo_exame,
                fl_urgencia,
                qt_dias,
                qt_dias_terceirizados,
                qt_hr_padrao_exame_eme,
                qt_idade_final,
                qt_idade_inicial,
                decode(ppu.cd_modelo, null, 'N', 'S') fl_ambulatorio
  from tb_tipo_procedimento       tp,
       tb_procedimento            pro,
       tb_proced_plano_uso_modelo ppu
 where pro.fl_cirurgia != 2
   and pro.fl_tipo_exame not in (0, 1, 2, 3, 5)
   and pro.cd_procedimento = ppu.cd_procedimento(+)
   and tp.cd_tipo_procedimento = pro.fl_tipo_exame
/

