create view VW_AUTORIZA_CHEQUE_CAD as
select  tb_pessoa.cd_pessoa,
   tb_pessoa.nu_cgc_cpf,
   tb_pessoa.nm_pessoa_razao_social,
   tb_pessoa.nm_fantasia,
   tb_pessoa.dt_nascimento_fundacao,
   tb_pessoa.nu_ident_insc_est,
   tb_pessoa.nm_orgao_expedidor_ident,
   tb_pessoa.cd_uf_orgao_expedidor_ident,
   tb_pessoa.fl_tipo_pessoa,
   rowidtochar(tb_pessoa.rowid) ri_pessoa,
   tb_autoriza_cheque.dt_validade,
   rowidtochar(tb_autoriza_cheque.rowid) ri_autoriza_cheque
from tb_autoriza_cheque,tb_pessoa
where tb_autoriza_cheque.cd_pessoa=tb_pessoa.cd_pessoa and
   tb_pessoa.fl_tipo_pessoa=1
/

