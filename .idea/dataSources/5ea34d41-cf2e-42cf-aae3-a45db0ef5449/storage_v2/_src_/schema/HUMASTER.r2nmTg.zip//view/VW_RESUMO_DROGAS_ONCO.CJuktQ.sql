create view VW_RESUMO_DROGAS_ONCO as
select /*
         Fred Monteiro - IVIA - 23/08/2017
         Retorna as drogas oncologicas que foram autorizadas, agendadas, planejadas, compradas, manipuladas, administradas e com perda de estabilidade
      */
       b.tipo, b.cd_unidade_atendimento, b.nm_unidade_atendimento,
       b.carteira, b.nm_pessoa, to_char(b.dt_nascimento, 'dd/mm/yyyy') dt_nascimento, b.nome_mae,
       b.periodo, b.cd_mat_med, b.nm_mat_med, sum(b.qtd_mat_med) qtd_mat_med, b.cd_unidade_dosagem
  from (/*Drogas autorizadas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_autorizacao, 'yyyymm') periodo, 'AUT' tipo, a.cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_autor_onco_hist a
         where 1 = 1
         union all
        /*Drogas agendadas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_agenda, 'yyyymm') periodo, 'AGD' tipo, a.cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_agend_onco_hist a
         where 1 = 1
         union all
        /*Drogas planejadas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_planejamento, 'yyyymm') periodo, 'PLN' tipo, a.cd_material cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_plan_onco_hist a
         where 1 = 1
         union all
        /*Drogas compradas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               '-1' carteira, 'COMPRA', a.dt_nota dt_nascimento, 'COMPRA' nome_mae,
               to_char(a.dt_nota, 'yyyymm') periodo, 'CPR' tipo, a.cd_mat_med, a.nm_mat_med, a.qtd_mat_med, 'ESTOQ' cd_unidade_dosagem
          from tb_compr_onco_hist a
         where 1 = 1
         union all
        /*Drogas manipuladas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_manipulacao, 'yyyymm') periodo, 'MAN' tipo, a.cd_material cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_manip_onco_hist a
         where 1 = 1
         union all
         /*Drogas com perda de estabilidade*/
         select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_agenda, 'yyyymm') periodo, 'PDE' tipo, a.cd_mat_med cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_perd_estab_onco_hist a
         where 1 = 1
         union all
        /*Drogas faturadas*/
        select a.cd_unidade_atendimento, a.nm_unidade_atendimento,
               substr(a.nu_carteira_convenio, 1, 14) carteira, a.nm_pessoa, a.dt_nascimento, a.nome_mae,
               to_char(a.dt_comanda, 'yyyymm') periodo, 'FAT' tipo, a.cd_mat_med, a.nm_mat_med, a.qtd_mat_med, a.cd_unidade_dosagem
          from tb_fat_onco_hist a
         where 1 = 1) b
 where 1 = 1
 group by b.tipo, b.cd_unidade_atendimento, b.nm_unidade_atendimento,
          b.carteira, b.nm_pessoa, to_char(b.dt_nascimento, 'dd/mm/yyyy'), b.nome_mae,
          b.periodo, b.cd_mat_med, b.nm_mat_med, b.cd_unidade_dosagem
/

