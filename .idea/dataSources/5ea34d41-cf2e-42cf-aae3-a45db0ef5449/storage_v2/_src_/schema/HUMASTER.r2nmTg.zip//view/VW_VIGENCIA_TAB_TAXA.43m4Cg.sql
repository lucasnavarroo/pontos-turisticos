create view VW_VIGENCIA_TAB_TAXA as
select a.cd_tabela_taxa,
	a.ds_tabela_taxa,
	b.dt_vigencia
from tb_vl_taxas_convenio b,tb_tabela_taxa a
where a.cd_tabela_taxa = b.cd_tabela_taxa
group by a.cd_tabela_taxa,
	a.ds_tabela_taxa,
	b.dt_vigencia
/

