create view VW_ESPERA_OBSERVACAO as
SELECT     A.CD_SETOR,TS.NM_SETOR,A.CD_ATENDIMENTO,TO_CHAR(A.DT_ATENDIMENTO,'dd/mm/yyyy' )||' '||
           FN_HORA( A.HR_ATENDIMENTO) DATA_ATENDIMENTO, PA.NU_CARTEIRA_CONVENIO,
           PA.NM_PACIENTE,
           SA.CD_SENHA_ATENDIMENTO,
           TO_DATE(TO_CHAR(SA.DT_INICIO_ATENDIMENTO,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy hh24:mi:ss') DT_INICIO_ATENDIMENTO,
           (TRUNC((NVL(SA.DT_FIM_ATENDIMENTO, TO_DATE('01/01/2014')) -
                  SA.DT_INICIO_ATENDIMENTO) * 24) * 60 +
           ROUND((((NVL(SA.DT_FIM_ATENDIMENTO, TO_DATE('01/01/2014')) -
                  SA.DT_INICIO_ATENDIMENTO) * 24) -
                  (TRUNC((NVL(SA.DT_FIM_ATENDIMENTO, TO_DATE('01/01/2014')) -
                          SA.DT_INICIO_ATENDIMENTO) * 24))) * 60)) TOTAL_MINUTOS,
                          SA.DT_INICIO_ATENDIMENTO DT_INICIO,
                          SA.DT_FIM_ATENDIMENTO    DT_FIM,
                          SA.CD_LOCAL_ATENDIMENTO
      FROM TB_SENHA_ATENDIMENTO_SA SA,
           TB_UNIDADE_ATENDIMENTO   U,
           TM_ATENDIMENTO           A,
           TB_PACIENTE             PA,
           TM_SETOR                TS
     WHERE SA.FL_STATUS             IN (5, 8, 10)
       AND SA.CD_ATENDIMENTO        = A.CD_ATENDIMENTO
       AND U.CD_UNIDADE_ATENDIMENTO = A.CD_UNIDADE_ATENDIMENTO
       AND A.CD_PACIENTE            = PA.CD_PACIENTE
       AND A.CD_SETOR               = TS.CD_SETOR
       and A.DT_ATENDIMENTO > ( sysdate - 15)
       AND EXISTS(SELECT A.CD_ATENDIMENTO
                   FROM TB_OCUPACAO_ACOMODACAO A
                  WHERE A.CD_ATENDIMENTO = CD_ATENDIMENTO  )
/

