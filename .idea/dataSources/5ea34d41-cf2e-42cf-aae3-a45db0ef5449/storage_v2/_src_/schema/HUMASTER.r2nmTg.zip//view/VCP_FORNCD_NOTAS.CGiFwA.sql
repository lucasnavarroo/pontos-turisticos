create view VCP_FORNCD_NOTAS as
select --
       emp.id_pessoa,
       emp.nome,
       emp.apelido,
       substr(sFnRetornaEndereco@hapvprod(emp.id_pessoa), 1, 120),
	   emp.cep,
       emp.bairro,
       emp.inscr_munic,
       eum.cod_um,
       eum.descricao,
       emp.cod_uf,
       ejur.cgc,
       forn.id_pessoa,
       forn.nome,
       forn.apelido,
       substr(sFnRetornaEndereco@hapvprod(forn.id_pessoa), 1, 120),
	   forn.cep,
       forn.bairro,
       forn.inscr_munic,
       fum.cod_um,
       fum.descricao,
       forn.cod_uf,
       fjur.cgc,
       tit.id_tit,
       tit.num_doc,
       tit.dt_emissao,
       tit.vlr_tit,
       tit.vlr_trib_iss,
       it.vlr,
       (it.vlr * 100 / tit.vlr_trib_iss)  aliquota,
       dtit.descricao_adicional,
       grp.dt_pgto
from fn_um@hapvprod                eum,
     fn_um@hapvprod                fum,
     fn_pessoa_juridica@hapvprod   ejur,
     fn_pessoa_juridica@hapvprod   fjur,
     fn_pessoa@hapvprod            emp,
     fn_pessoa@hapvprod            forn,
     cp_grupo_tit@hapvprod         grp,
     cp_rel_tit_descricao@hapvprod dtit,
     cp_item_imposto@hapvprod      imp,
     cp_item_tit@hapvprod          it,
     cp_tit@hapvprod               tit
where tit.id_tit         = it.id_tit               and
      it.id_item_tit     = imp.id_item_tit         and
      tit.id_forncd      = forn.id_pessoa          and
      forn.id_pessoa     = fjur.id_pessoa_juridica and
      tit.id_empresa     = emp.id_pessoa           and
      emp.id_pessoa      = ejur.id_pessoa_juridica and
      grp.id_grupo_tit(+)= tit.id_grupo_tit        and
      dtit.id_tit   (+)  = tit.id_tit              and
      forn.cod_um        = fum.cod_um              and
      emp.cod_um         = eum.cod_um              and
      tit.ind_cancelado  = 'N'                     and
      it.cod_tipo_item   = 'IMP'                   and
      imp.cod_imposto    = 'ISSJ'
/

