create view FN_CENTRO_CUSTO as
select "ID_CENTRO_CUSTO","COD_CENTRO_CUSTO","DESCRICAO","ID_CENTRO_CUSTO_PAI"
     from fn_centro_custo@matera
/

