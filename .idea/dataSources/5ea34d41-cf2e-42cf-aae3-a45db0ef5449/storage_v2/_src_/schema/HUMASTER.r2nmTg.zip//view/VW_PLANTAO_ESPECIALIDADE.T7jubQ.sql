create view VW_PLANTAO_ESPECIALIDADE as
select b.dt_inicio+a.cd_dia_semana-1 dt_plantao,a.cd_medico,a.hr_inicial,
	  a.hr_final, a.nu_atendimentos_dia, c.cd_especialidade
from tb_especialidade_profissional c,tb_semana_ano b,tb_plantao_medico a
where b.dt_ano=a.dt_ano and
	 b.cd_semana=a.cd_semana and
	 c.cd_profissional=a.cd_medico
/

