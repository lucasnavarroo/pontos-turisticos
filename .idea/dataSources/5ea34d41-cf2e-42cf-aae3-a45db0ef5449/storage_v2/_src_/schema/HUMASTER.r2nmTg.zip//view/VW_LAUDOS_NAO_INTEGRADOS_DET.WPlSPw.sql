create view VW_LAUDOS_NAO_INTEGRADOS_DET as
select trunc(pr.dt_resultado) dt_resultado,
       sp.nm_setor_pacs,
       pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem na_accessionnumber,
       pr.dt_procedimento_realizado,
       pa.cd_paciente,
       pa.nm_paciente
from tb_paciente pa,
     tm_atendimento a,
     tm_setor se,
     tb_setor_pacs sp,
     tb_laudo_arquivo a,
     tb_prof_proced_realizado ppr,
     tb_item_grupo_produto igp,
     tb_procedimento p,
     tb_laudo_paciente lp,
     tb_procedimento_realizado pr,
     tb_guia g
where g.cd_atendimento = pr.cd_atendimento
  and g.cd_ocorrencia = pr.cd_ocorrencia
  and pr.cd_atendimento = lp.cd_atendimento
  and pr.cd_ocorrencia = lp.cd_ocorrencia
  and pr.cd_ordem = lp.cd_ordem
  and pr.cd_procedimento = p.cd_procedimento
  and p.cd_procedimento = igp.cd_produto
  and pr.cd_atendimento = ppr.cd_atendimento
  and pr.cd_ocorrencia = ppr.cd_ocorrencia
  and pr.cd_ordem = ppr.cd_ordem
  and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem = a.na_accessionnumber
  and g.cd_setor_origem = se.cd_setor
  and se.cd_setor_pacs = sp.cd_setor_pacs
  and pr.cd_atendimento = a.cd_atendimento
  and a.cd_paciente = pa.cd_paciente
  and pr.dt_libera_laudo is not null
  and a.bl_arquivo is not null
  and pr.dt_libera_laudo between trunc(sysdate - 30) and sysdate
  and nvl(decode(igp.cd_grupo_produto,501,'CT',502,'US',503,'CR',504,'NM',505,'MR',506,'MG',508,'ES',null),'SS') <> 'SS'
  and p.fl_tipo_exame = 2
  and ppr.cd_tipo_ato_profissional = 20
  and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem not in ( select na_accessionumber
                                                                from pixeon_report_integrated i
                                                                where i.na_accessionumber = pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem )
order by dt_resultado,nm_setor_pacs
/

