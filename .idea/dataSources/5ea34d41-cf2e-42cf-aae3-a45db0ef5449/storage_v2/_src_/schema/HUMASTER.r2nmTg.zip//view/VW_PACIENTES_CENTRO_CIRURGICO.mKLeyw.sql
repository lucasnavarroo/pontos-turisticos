create view VW_PACIENTES_CENTRO_CIRURGICO as
SELECT
  "CD_ATENDIMENTO",
  "DT_ATENDIMENTO",
  "CD_MEDICO_ACOMPANHA",
  "CD_PACIENTE",
  "NM_PACIENTE",
  "CD_TIPO_ATENDIMENTO",
  "NM_TIPO_ATENDIMENTO",
  "DT_NASCIMENTO"
FROM
  (
    SELECT DISTINCT
      a.cd_atendimento,
      a.dt_atendimento,
      a.cd_medico_acompanha,
      a.cd_paciente,
      pa.nm_paciente,
      a.cd_tipo_atendimento,
      decode (a.cd_tipo_atendimento,0,'INT',5,'PQA')nm_tipo_atendimento,
      PA.DT_NASCIMENTO
    FROM
      tm_atendimento a,
      tb_procedimento_realizado pr,
      tb_paciente pa,
      tb_procedimento p,
      tb_tipo_atendimento ta
    WHERE
      1 = 1
    AND cd_unidade_atendimento LIKE fn_unidade
    AND p.fl_cirurgia                                + 0 = 1
    AND a.dt_atendimento BETWEEN add_months(sysdate, -12) AND sysdate
    AND a.cd_tipo_atendimento                       IN (0, 5)
    AND a.dt_fim_atendimento  IS NULL
    AND pr.cd_procedimento     = p.cd_procedimento
    AND ta.cd_tipo_atendimento = a.cd_tipo_atendimento
    AND pa.cd_paciente         = a.cd_paciente
    AND pr.cd_atendimento      = a.cd_atendimento
  )
ORDER BY
  CD_ATENDIMENTO DESC
/

