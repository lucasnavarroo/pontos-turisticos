create view VW_ATEND_AMB_ALTA_AUTOMATICA as
    select a.cd_atendimento,
           pac.cd_paciente,
           pac.nm_paciente,
           a.dt_atendimento,
           a.hr_atendimento,
           a.cd_tipo_atendimento,
           decode(decode(a.cd_medico_atendente,null,h.cd_medico,a.cd_medico_atendente),null,
                                               fu_medico_solicitou_exame(a.cd_atendimento),
                       decode(a.cd_medico_atendente,null,h.cd_medico,a.cd_medico_atendente)) cd_medico,
           c.hr_encerra_atend_ambulat,
           p.cd_convenio_pagador,
           h.cid10,
           s.dt_fim_atendimento dt_enc_atend_sam,
           a.dt_canc_atend
      from tb_historico_paciente_sa h,
           tb_senha_atendimento_sa s,
           tb_convenio c,
           tb_convenio_pagador p,
           tb_paciente pac,
           tb_atendimento a
     where a.dt_atendimento         between add_months(sysdate, -3) and trunc(sysdate)
       and a.dt_fim_atendimento||'' is null
       and a.cd_tipo_atendimento+0  in (1,2,3,4,6)
       and a.cd_setor           not in ('133610','116600')
       and pac.cd_paciente          =  a.cd_paciente
       and p.cd_atendimento         =  a.cd_atendimento
       and p.cd_convenio_pagador    =  1
       and p.cd_convenio_base       = c.cd_convenio
       and c.hr_encerra_atend_ambulat is not null
       and s.cd_atendimento      =  a.cd_atendimento
       and exists (select 'X'
                     from tb_senha_atendimento_sa x
                    where x.cd_atendimento = a.cd_atendimento
                      and rownum           = 1)
       and h.cd_atendimento      = a.cd_atendimento
       and h.dt_atendimento      = (select min(y.dt_atendimento)
                                      from tb_historico_paciente_sa y
                                     where y.cd_atendimento = h.cd_atendimento)
       and not exists (select k.cd_atendimento
                         from tb_digital_motivo_autoriza k
                        where k.cd_atendimento       = a.cd_atendimento
                          and k.fl_digital_pendente = 'S'
                          and rownum                = 1)
       and a.dt_atendimento+0 + (a.hr_atendimento / 86400)  <
              sysdate - (c.hr_encerra_atend_ambulat - trunc(c.hr_encerra_atend_ambulat))
UNION ALL
    select a.cd_atendimento,
           pac.cd_paciente,
           pac.nm_paciente,
           a.dt_atendimento,
           a.hr_atendimento,
           a.cd_tipo_atendimento,
           decode(a.cd_medico_atendente,null,fu_medico_solicitou_exame(a.cd_atendimento),a.cd_medico_atendente) cd_medico,
           c.hr_encerra_atend_ambulat,
           p.cd_convenio_pagador,
           null cid10,
           a.dt_atendimento + (a.hr_atendimento / 86400) dt_enc_atend_sam,
           a.dt_canc_atend
      from tb_convenio c,
           tb_convenio_pagador p,
           tb_paciente pac,
           tb_atendimento a
     where a.dt_atendimento         between add_months(sysdate, -3) and trunc(sysdate)
       and a.dt_fim_atendimento||'' is null
       and a.cd_tipo_atendimento+0  in (1,2,3,4,6)
       and pac.cd_paciente          =  a.cd_paciente
       and p.cd_atendimento         =  a.cd_atendimento
       and p.cd_convenio_pagador    =  1
       and p.cd_convenio_base       = c.cd_convenio
       and c.hr_encerra_atend_ambulat is not null
       and not exists (select y.cd_atendimento
                         from tb_senha_atendimento_sa y
                        where y.cd_atendimento = a.cd_atendimento
                          and rownum           = 1)
       and not exists (select k.cd_atendimento
                         from tb_digital_motivo_autoriza k
                        where k.cd_atendimento       = a.cd_atendimento
                          and k.fl_digital_pendente = 'S'
                          and rownum                = 1)
       and a.dt_atendimento+0 + (a.hr_atendimento / 86400)  <
              sysdate - (c.hr_encerra_atend_ambulat - trunc(c.hr_encerra_atend_ambulat))
UNION ALL
    select a.cd_atendimento,
           pac.cd_paciente,
           pac.nm_paciente,
           a.dt_atendimento,
           a.hr_atendimento,
           a.cd_tipo_atendimento,
           decode(a.cd_medico_atendente,null,fu_medico_solicitou_exame(a.cd_atendimento),a.cd_medico_atendente) cd_medico,
           c.hr_encerra_atend_ambulat,
           p.cd_convenio_pagador,
           null cid10,
           a.dt_atendimento + (a.hr_atendimento / 86400) dt_enc_atend_sam,
           a.dt_canc_atend
      from tb_convenio c,
           tb_convenio_pagador p,
           tb_paciente pac,
           tb_atendimento a
     where a.dt_atendimento         between add_months(sysdate, -3) and trunc(sysdate)
       and a.dt_fim_atendimento||'' is null
       and a.cd_tipo_atendimento+0  in (1,2,3,4,6)
       and pac.cd_paciente          =  a.cd_paciente
       and p.cd_atendimento         =  a.cd_atendimento
       and p.cd_convenio_pagador    =  1
       and p.cd_convenio_base       = c.cd_convenio
       and c.hr_encerra_atend_ambulat is not null
       and exists (select y.cd_atendimento
                     from tb_senha_atendimento_sa y
                    where y.cd_atendimento = a.cd_atendimento
                      and rownum           = 1)
       and not exists (select z.cd_atendimento
                         from tb_historico_paciente_sa z
                        where z.cd_atendimento = a.cd_atendimento
                          and rownum           = 1)
       and not exists (select k.cd_atendimento
                         from tb_digital_motivo_autoriza k
                        where k.cd_atendimento       = a.cd_atendimento
                          and k.fl_digital_pendente = 'S'
                          and rownum                = 1)
       and a.dt_atendimento+0 + (a.hr_atendimento / 86400)  <
              sysdate - (c.hr_encerra_atend_ambulat - trunc(c.hr_encerra_atend_ambulat))
UNION ALL -- Mesmo que não exista na tb_historico, se existir cd_operador_inicio na tb_senha_atendimento_sa
          -- permite dar alta
    select distinct
        a.cd_atendimento,
         pac.cd_paciente,
         pac.nm_paciente,
         a.dt_atendimento,
         a.hr_atendimento,
         a.cd_tipo_atendimento,
         decode(decode(a.cd_medico_atendente,null,fu_medico_solicitou_exame(a.cd_atendimento),a.cd_medico_atendente),null,pes.cd_pessoa) cd_medico,
         c.hr_encerra_atend_ambulat,
         p.cd_convenio_pagador,
         null cid10,
         a.dt_atendimento + (a.hr_atendimento / 86400) dt_enc_atend_sam,
         a.dt_canc_atend
     from tb_pessoa pes,
          tb_operador o,
          tb_senha_atendimento_sa s,
          tb_convenio c,
          tb_convenio_pagador p,
          tb_paciente pac,
          tb_atendimento a
    where a.dt_atendimento         between add_months(sysdate, -3) and trunc(sysdate)
      and a.dt_fim_atendimento||'' is null
      and a.cd_tipo_atendimento+0  in (1,2,3,4,6)
      and a.cd_medico_atendente+0  is null
      and pac.cd_paciente          =  a.cd_paciente
      and p.cd_atendimento         =  a.cd_atendimento
      and p.cd_convenio_pagador    =  1
      and p.cd_convenio_base       = c.cd_convenio
      and c.hr_encerra_atend_ambulat is not null
      and s.cd_atendimento         = a.cd_atendimento
      and s.cd_operador_inicio     is not null
      and o.nm_operador            = s.cd_operador_inicio
      and pes.cd_pessoa            = o.cd_pessoa
      and not exists (select z.cd_atendimento
                        from tb_historico_paciente_sa z
                       where z.cd_atendimento = a.cd_atendimento
                         and rownum           = 1)
      and not exists (select k.cd_atendimento
                        from tb_digital_motivo_autoriza k
                       where k.cd_atendimento       = a.cd_atendimento
                         and k.fl_digital_pendente = 'S'
                         and rownum                = 1)
      and a.dt_atendimento+0 + (a.hr_atendimento / 86400)  <
             sysdate - (c.hr_encerra_atend_ambulat - trunc(c.hr_encerra_atend_ambulat))
UNION ALL -- Mesmo que não exista na tb_historico, se existir s.nm_operador_obs_retorno e se nao
          -- existir o cd_operador_inicio na tb_senha_atendimento_sa
    select distinct
        a.cd_atendimento,
         pac.cd_paciente,
         pac.nm_paciente,
         a.dt_atendimento,
         a.hr_atendimento,
         a.cd_tipo_atendimento,
         decode(decode(a.cd_medico_atendente,null,fu_medico_solicitou_exame(a.cd_atendimento),a.cd_medico_atendente),null,pes.cd_pessoa) cd_medico,
         c.hr_encerra_atend_ambulat,
         p.cd_convenio_pagador,
         null cid10,
         a.dt_atendimento + (a.hr_atendimento / 86400) dt_enc_atend_sam,
         a.dt_canc_atend
     from tb_pessoa pes,
          tb_operador o,
          tb_senha_atendimento_sa s,
          tb_convenio c,
          tb_convenio_pagador p,
          tb_paciente pac,
          tb_atendimento a
    where a.dt_atendimento         between add_months(sysdate, -3) and trunc(sysdate)
      and a.dt_fim_atendimento||'' is null
      and a.cd_tipo_atendimento+0  in (1,2,3,4,6)
      and a.cd_medico_atendente+0  is null
      and pac.cd_paciente          =  a.cd_paciente
      and p.cd_atendimento         =  a.cd_atendimento
      and p.cd_convenio_pagador    =  1
      and p.cd_convenio_base       = c.cd_convenio
      and c.hr_encerra_atend_ambulat is not null
      and s.cd_atendimento         = a.cd_atendimento
      and s.cd_operador_inicio     is null
      and s.nm_operador_obs_retorno is not null
      and o.nm_operador            = s.nm_operador_obs_retorno
      and pes.cd_pessoa            = o.cd_pessoa
      and not exists (select z.cd_atendimento
                        from tb_historico_paciente_sa z
                       where z.cd_atendimento = a.cd_atendimento
                         and rownum           = 1)
      and not exists (select k.cd_atendimento
                        from tb_digital_motivo_autoriza k
                       where k.cd_atendimento       = a.cd_atendimento
                         and k.fl_digital_pendente = 'S'
                         and rownum                = 1)
      and a.dt_atendimento+0 + (a.hr_atendimento / 86400)  <
             sysdate - (c.hr_encerra_atend_ambulat - trunc(c.hr_encerra_atend_ambulat))

    ORDER BY 4,1
/

