create view VW_LISTA_MEDICAMENTOS as
select m.cd_material cd_medicamento,
       fn_ds_mat_med(m.cd_material) ds_medicamento,
       m.marca,
       m.qt_conteudo,
       m.cd_unidade_dosagem,
       decode(m.qt_conteudo_dosagem,
              null,
              m.qt_dosagem,
              (m.qt_dosagem * m.qt_conteudo_dosagem * m.qt_conteudo)) as qt_dosagem,
       m.fl_padronizado,
       m.fl_controlado,
       m.fl_consignado,
       m.fl_invasivo,
       m.fl_critico,
       m.fl_fragmenta,
       decode(ppm.cd_modelo, null, 'N', 'S') fl_ambulatorio,
       ppm.cd_modelo
  from sah.tb_material            m,
       tb_produto_mat_med         mm,
       tb_prescricao_plano_modelo ppm
 where m.cd_material = mm.cd_mat_med
   and m.cd_material = ppm.cd_mat_med
   and ppm.cd_tipo_prescricao_plano in (1, 4)
   and fn_classif_material(m.cd_material) = 1
/

