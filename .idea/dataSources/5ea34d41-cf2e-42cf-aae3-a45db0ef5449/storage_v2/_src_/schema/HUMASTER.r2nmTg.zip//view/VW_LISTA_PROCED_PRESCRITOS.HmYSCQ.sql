create view VW_LISTA_PROCED_PRESCRITOS as
select distinct
         pm1.cd_atendimento ,
         pa.nu_carteira_convenio cd_beneficiario,
         pa.cd_paciente,
         pp.cd_procedimento cd_procedimento,
         pd.nr_procedimento nm_procedimento_prescrito,
         pp.cd_profissional_prescreve,
         pro.nm_pessoa_razao_social nm_profissional_prescreve,
         ge.nu_comanda,
         to_char(pp.dt_transacao, 'ddmmyyyy') dt_prescricao,
         fn_hora(to_number(to_char(pp.dt_transacao,'SSSSS'))) hr_prescricao,
         to_char(r.dt_transacao, 'ddmmyyyy') dt_lib_farmacia,
         fn_hora(to_number(to_char(r.dt_transacao,'SSSSS'))) hr_lib_farmacia,
         apm.dt_final + (apm.hr_final / 3600 / 24) dt_aplicado,
         fn_hora(apm.hr_final) hr_aplicado,
         pp.cd_ocorrencia_plano,
         pp.cd_ordem_prescricao,
         pp.cd_ordem_proc_plano_uso
    from vw_profissional pro,
         tb_paciente               pa,
         tm_atendimento            at,
         tb_procedimento           pd,
         tm_requisicao             r,
         tb_proced_hora_plano_uso   apm,
         tb_prescricao_medica      pm1,
         tb_procedimento_plano_uso    pp,
         tb_prescricao_gasto_extra ge
   where pp.cd_atendimento = pm1.cd_atendimento
     and pp.cd_ocorrencia_plano = pm1.cd_ocorrencia_plano
     and pp.cd_ordem_prescricao = pm1.cd_ordem_prescricao
     and pp.cd_proc_plano_pai is null
     and pp.cd_profissional_cancela is null
     and ge.cd_atendimento(+) = pp.cd_atendimento
     and ge.cd_ocorrencia_plano(+) = pp.cd_ocorrencia_plano
     and ge.cd_ordem_prescricao(+) = pp.cd_ordem_prescricao
     and ge.cd_ordem_proc_plano_uso(+) = pp.cd_ordem_proc_plano_uso
     and ge.cd_procedimento(+) = pp.cd_procedimento
     and apm.cd_atendimento(+) = ge.cd_atendimento
     and apm.cd_ocorrencia_plano(+) = ge.cd_ocorrencia_plano
     and apm.cd_ordem_prescricao(+) = ge.cd_ordem_prescricao
     and apm.cd_ordem_proc_plano_uso(+) = ge.cd_ordem_proc_plano_uso
     and apm.cd_ordem(+) = ge.cd_ordem_hora_msp
     and pd.cd_procedimento = pp.cd_procedimento
     and r.nu_comanda(+) = ge.nu_comanda
     and at.cd_atendimento = pp.cd_atendimento
     and pa.cd_paciente  = at.cd_paciente
     and pro.cd_profissional=pp.cd_profissional_prescreve
/

