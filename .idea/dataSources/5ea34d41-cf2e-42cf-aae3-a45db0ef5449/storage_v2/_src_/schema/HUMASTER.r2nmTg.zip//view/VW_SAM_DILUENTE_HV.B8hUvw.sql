create view VW_SAM_DILUENTE_HV as
select pr.nu_produto cd_diluente, pr.nm_produto nm_diluente
  from tb_produto pr
 where pr.fl_diluente = 'S'
   and pr.fl_compoe_hv = 'S'
/

