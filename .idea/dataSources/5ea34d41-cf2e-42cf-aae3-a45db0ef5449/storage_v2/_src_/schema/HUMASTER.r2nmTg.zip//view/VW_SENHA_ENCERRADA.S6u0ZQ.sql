create view VW_SENHA_ENCERRADA as
select  /*+choose */
        sa.CD_SENHA_MASTER,
        sa.CD_GRUPO_ATENDIMENTO,
        sa.CD_LOCAL_ATENDIMENTO,
        sa.CD_SENHA_ATENDIMENTO,
        sa.CD_PONTO_ATENDIMENTO_ATE,
        sa.CD_ATENDIMENTO,
        sa.dt_inicio_atendimento,
        sa.DT_GERACAO_SENHA,
        sa.dt_fim_atendimento,
        sa.NM_PACIENTE,
        sa.VL_IDADE,
        sa.CD_PACIENTE,
        sa.fl_prioridade,
        sa.FL_STATUS,
        sa.NM_OPERADOR_OBS_RETORNO,
        sa.CD_NIVEL_CLASSIFICACAO_RISCO,
        sa.CD_USUARIO,
        sa.FL_TRIAGEM
 from   tb_local_atendimento_sa loc,
        tb_senha_atendimento_sa sa
 where  sa.fl_status in (4)
 and    sa.dt_geracao_senha         >= trunc(sysdate)-3
 and    sa.dt_geracao_senha         >= trunc(sysdate)- nvl(loc.qt_dias_coleta,1)
 and    loc.cd_local_Atendimento    = sa.cd_local_atendimento
/

