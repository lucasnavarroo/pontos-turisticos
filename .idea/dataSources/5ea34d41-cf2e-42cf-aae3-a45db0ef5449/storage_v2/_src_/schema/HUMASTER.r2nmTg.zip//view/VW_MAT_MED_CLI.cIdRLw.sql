create view VW_MAT_MED_CLI as
select a.cd_mat_med,a.nm_mat_med,a.cd_apresentacao,a.qt_conteudo,
	a.cd_classificacao,b.cd_tipo_classificacao,c.fl_tipo_classificacao, m.fl_fragmenta
from  tb_tipo_classificacao c, tb_classificacao b, tb_mat_med a, tb_material m
where b.cd_classificacao = a.cd_classificacao and
      c.cd_tipo_classificacao = b.cd_tipo_classificacao and
      m.cd_material = a.cd_mat_med
/

