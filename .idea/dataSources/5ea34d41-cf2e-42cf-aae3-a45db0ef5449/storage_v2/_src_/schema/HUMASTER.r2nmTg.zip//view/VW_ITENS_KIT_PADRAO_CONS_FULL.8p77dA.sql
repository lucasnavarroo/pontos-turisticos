create view VW_ITENS_KIT_PADRAO_CONS_FULL as
select /*
             Fred Monteiro - IVIA - 18/01/2018
             View que contem os itens do kit padrao de consumo
         */
         a.id_kit,
         a.cd_atendimento,
         ab.cd_unidade_atendimento,
         aba.nm_unidade_atendimento,
         a.cd_procedimento,
         ac.nm_procedimento,
         a.dt_transacao,
         aaaaaaaa.fl_tipo_classificacao,
         aaaaaaaa.ds_fl_tipo_classificacao,
         aaaaaaaa.cd_tipo_produto_servico,
         aaaaaaa.cd_tipo_classificacao,
         aaaaaaa.ds_tipo_classificacao,
         aaaaaa.cd_classificacao,
         aaaaaa.nm_classificacao,
         aaaaa.cd_material cd_material_padrao,
         aaaaa.nm_material nm_material_padrao,
         aaaa.qt_item qtd,
         a.cd_pessoa_func_montou cd_pessoa
    from    tm_setor                                       ad,       -- setor que montou o kit
            tb_procedimento                                ac,       -- procedimento do kit
               tb_unidade_atendimento                      aba,      -- unidade de atendimento
            tm_atendimento                                 ab,       -- atendimento do kit
                              tb_classe_tipo_classificacao aaaaaaaa, -- tipo classe da classificacao
                           tb_tipo_classificacao           aaaaaaa,  -- tipo de classificacao do material
                        tb_classificacao                   aaaaaa,   -- classificacao do material
                     tb_material                           aaaaa,    -- material do kit
                  tb_procedimento_modelo_item              aaaa,     -- materiais procedimento modelo
               tb_procedimento_modelo                      aaa,      -- procedimento modelo
            vw_procedimento_pai_filho                      aa,       -- procedimento pai x filhos
         tm_kit_cirurgia_lote                              a         -- kit
   where 1 = 1
     -- filtros
     -- join a -- aa
     and a.cd_procedimento = aa.procedimento_filho
     -- join aa -- aaa
     and aa.procedimento_pai = aaa.cd_procedimento
     -- join aaa -- aaaa
     and aaa.cd_modelo                  = aaaa.cd_modelo
     and aaa.cd_ocorrencia_procedimento = aaaa.cd_ocorrencia_procedimento
     -- join aaaa -- aaaaa
     and aaaa.cd_material = aaaaa.cd_material
     -- join aaaaa -- aaaaaa
     and aaaaa.cd_classificacao = aaaaaa.cd_classificacao
     -- join aaaaaa -- aaaaaaa
     and aaaaaa.cd_tipo_classificacao = aaaaaaa.cd_tipo_classificacao
     -- join aaaaaaa -- aaaaaaaa
     and aaaaaaa.fl_tipo_classificacao = aaaaaaaa.fl_tipo_classificacao
     -- join a -- ab
     and a.cd_atendimento = ab.cd_atendimento(+)
     -- join ab -- aba
     and ab.cd_unidade_atendimento = aba.cd_unidade_atendimento(+)
     -- join a -- ac
     and a.cd_procedimento = ac.cd_procedimento
     -- join a -- ad
     and a.cd_setor_controle = ad.cd_setor
/

