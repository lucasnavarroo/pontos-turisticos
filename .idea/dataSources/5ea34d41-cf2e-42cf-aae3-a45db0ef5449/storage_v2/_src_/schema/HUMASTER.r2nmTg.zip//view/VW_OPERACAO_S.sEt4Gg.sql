create view VW_OPERACAO_S as
select "CD_OPERACAO","NM_OPERACAO","CD_TIPO_OPERACAO","DS_HISTORICO","CD_CONTA_CONTABIL" from tb_operacao@hapvida
/

