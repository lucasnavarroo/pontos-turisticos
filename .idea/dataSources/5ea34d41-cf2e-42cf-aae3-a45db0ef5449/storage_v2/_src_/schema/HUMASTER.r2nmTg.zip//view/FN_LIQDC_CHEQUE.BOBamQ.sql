create view FN_LIQDC_CHEQUE as
select "ID_LIQDC_CHEQUE","ID_CC","NUM_CHEQUE","NOME_PORTADOR","ID_CC_DESTINO","ID_CHEQUE_INTEGRACAO"
     from fn_liqdc_cheque@matera
/

