create view VW_SAM_AVALIACAO as
SELECT a.NM_AVALIACAO,
       a.CD_AVALIACAO                 cd_Avaliacao,
       sg.nm_subgrupo_avaliacao,
       ga.nm_grupo_avaliacao,
       --tsa.cd_classe_acomodacao,
       a.cd_especie_avaliacao,
       a.id_mnemonico_avaliacao,
       a.cd_tipo_documento_prontuario,
       /*null                           cd_grupo_atendimento,
       null                           cd_local_atendimento,*/
       ga.fl_tipo_grupo               cd_tipo_avaliacao
  FROM /*tb_subgrupo_avaliacao_classe tsa,*/
       tb_grupo_avaliacao           ga,
       tb_subgrupo_avaliacao        sg,
       TB_AVALIACAO                 a
 WHERE a.CD_SUBGRUPO_AVALIACAO = sg.cd_subgrupo_avaliacao
   and sg.cd_grupo_avaliacao = ga.cd_grupo_avaliacao
   --and tsa.CD_SUBGRUPO_AVALIACAO = sg.cd_subgrupo_avaliacao
/*UNION all
SELECT av.NM_AVALIACAO,
       av.CD_AVALIACAO                 cd_Avaliacao,
       sg.nm_subgrupo_avaliacao,
       ga.nm_grupo_avaliacao,
       null                            cd_classe_acomodacao,
       av.cd_especie_avaliacao         cd_especie_avaliacao,
       av.id_mnemonico_avaliacao,
       av.cd_tipo_documento_prontuario,
       sacl.cd_grupo_atendimento,
       sacl.cd_local_atendimento,
       ga.fl_tipo_grupo                cd_tipo_avaliacao
  from tb_subgrupo_avaliacao       sg,
       tb_grupo_avaliacao          ga,
       tb_subgrupo_avaliacao_local sacl,
       tb_avaliacao                av
 where sacl.cd_subgrupo_avaliacao = sg.cd_subgrupo_avaliacao
   and ga.cd_grupo_avaliacao = sg.cd_grupo_avaliacao
   and av.cd_subgrupo_avaliacao = sg.cd_subgrupo_avaliacao*/
/

