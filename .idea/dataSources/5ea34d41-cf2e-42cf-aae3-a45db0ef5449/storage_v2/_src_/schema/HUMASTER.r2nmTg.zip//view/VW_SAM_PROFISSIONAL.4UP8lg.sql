create view VW_SAM_PROFISSIONAL as
select pro.nm_pessoa_razao_social,
       pro.cd_profissional,
       ope.nm_operador nm_login,
       pro.cd_crm_profissional
  from vw_profissional pro, tb_operador ope
 where pro.cd_profissional = ope.cd_pessoa
 order by 1
/

