create view VW_PROCEDIMENTO_PAI_FILHO as
select b.procedimento_pai,
       b.modelo_pai,
       b.cd_ocorrencia_procedimento_pai,
       b.procedimento_filho
  from (select a.cd_procedimento  procedimento_pai,
               a.cd_modelo        modelo_pai,
               a.cd_ocorrencia_procedimento cd_ocorrencia_procedimento_pai,
               aa.cd_procedimento procedimento_filho
          from    tb_modelo_plano_tratamento    ab,
                  tb_procedimento_modelo_filhos aa,
               tb_procedimento_modelo           a
         where 1 = 1
           -- filtros
           and ab.fl_tipo_modelo = 1
           -- join a -< aa
           and a.cd_modelo = aa.cd_modelo
           and a.cd_ocorrencia_procedimento = aa.cd_ocorrencia_procedimento
           -- join a -- ab
           and a.cd_modelo = ab.cd_modelo
        union all
        select a.cd_procedimento procedimento_pai,
               a.cd_modelo       modelo_pai,
               a.cd_ocorrencia_procedimento cd_ocorrencia_procedimento_pai,
               a.cd_procedimento procedimento_filho
          from    tb_modelo_plano_tratamento aa,
               tb_procedimento_modelo        a
         where 1 = 1
           -- filtros
           and aa.fl_tipo_modelo = 1
           -- join a >- aa
           and a.cd_modelo = aa.cd_modelo) b
 where 1 = 1
/

