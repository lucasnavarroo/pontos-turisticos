create view VW_SAM_DADOS_ATENDIMENTO as
select a.cd_unidade_atendimento,
       pes.nm_pessoa_razao_social nm_prestador,
       a.cd_atendimento,
       to_char(a.dt_atendimento, 'ddMMyyyy') dt_atendimento,
       fn_hora(a.hr_atendimento) hr_atendimento,
       to_char(a.dt_fim_atendimento, 'ddMMyyyy') dt_fim_atendimento,
       fn_hora(a.hr_fim_atendimento) hr_fim_atendimento,
       a.cd_setor,
       s.nm_setor,
       a.cd_tipo_atendimento,
       ta.nm_tipo_atendimento,
       a.cd_paciente,
       substr(cp.nu_carteira_convenio, 1, 14) nu_carteira,
       cp.cd_convenio_base cd_convenio,
       a.fl_internacao,
       p.NM_CONVENIO,
       p.CD_PLANO_CONVENIO,
       p.NM_PLANO,
       p.DT_VALIDADE dt_validade_plano
  from tb_pessoa              pes,
       tb_unidade_atendimento u,
       tb_tipo_atendimento    ta,
       tm_setor               s,
       tb_convenio_pagador    cp,
       tm_atendimento         a,
       vw_detalhe_paciente    p
 where s.cd_setor = a.cd_setor
   and cp.cd_atendimento = a.cd_atendimento
   and cp.cd_convenio_pagador = 1
   and ta.cd_tipo_atendimento = a.cd_tipo_atendimento
   and u.cd_unidade_atendimento = a.cd_unidade_atendimento
   and pes.cd_pessoa = u.cd_pessoa_cobra
   and p.CD_ATENDIMENTO = a.cd_atendimento
   and p.CD_PACIENTE = a.cd_paciente
   and a.dt_canc_atend is null
/

