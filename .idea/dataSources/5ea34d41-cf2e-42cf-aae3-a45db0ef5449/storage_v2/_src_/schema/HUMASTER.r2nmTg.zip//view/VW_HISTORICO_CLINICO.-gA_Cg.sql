create view VW_HISTORICO_CLINICO as
select r.cd_atendimento,
       r.nm_avaliacao Tipo_Registro_Clinico,
       to_char(r.dt_evolucao, 'ddmmyyyy') dt_registro,
       fn_hora(r.hr_evolucao) hr_registro,
       r.cd_profissional,
       p.nm_fantasia nome_profissional,
       r.ds_registro_clinico
   from
  (select a.cd_atendimento,
                   c.cd_avaliacao,
                   c.nm_avaliacao,
                   b.dt_evolucao_avaliacao dt_evolucao,
                   b.hr_evolucao_avaliacao hr_evolucao,
                   a.cd_profissional,
                   a.nu_evolucao,
                   a.cd_ordem,
                   a.cd_ocorrencia_plano,
                   'AA' fl_tipo_grupo,
                   0 nu_prescricao,
                   c.cd_tipo_documento_prontuario || ';' || a.cd_atendimento || ';' ||
                   a.cd_ocorrencia_plano || ';' || a.cd_ordem || ';' ||
                   a.nu_evolucao || ';' || to_char(b.dt_evolucao_avaliacao,'dd/mm/yyyy')||';'||fn_hora(b.hr_evolucao_avaliacao) cd_chave,
                   dbms_lob.substr(pk_relat_export.fn_rpformcli(b.cd_atendimento,
                                            b.cd_ocorrencia_plano,
                                            b.cd_ordem,
                                            a.nu_evolucao,
                                            a.dt_evolucao),4000,1) ds_registro_clinico
              from tb_avaliacao c, tb_evolucao_avaliacao b, tb_evolucao a
             where a.dt_evolucao between to_date('01/01/1900','dd/mm/yyyy') and trunc(sysdate)
               and b.cd_atendimento = a.cd_atendimento
               and b.cd_ocorrencia_plano = a.cd_ocorrencia_plano
               and b.cd_ordem = a.cd_ordem
               and b.cd_avaliacao = c.cd_avaliacao
            union all
            select a.cd_atendimento,
                   null,
                   'RECEITA MÉDICA',
                   a.dt_receita dt_evolucao,
                   a.hr_receita hr_evolucao,
                   a.cd_profissional_valida,
                   0 nu_evolucao,
                   0 cd_ordem,
                   0 cd_ocorrencia_plano,
                   null,
                   null,
                   9 || ';' || a.cd_atendimento || ';' ||
                   a.cd_ocorrencia_plano || ';' || a.cd_ordem_receita || ';' ||
                   p.nm_paciente || ';' || a.cd_profissional_valida || ';' ||
                   to_char(a.dt_receita,'dd/mm/yyyy') || ';' || fn_hora(a.hr_receita) cd_chave,
                   dbms_lob.substr(ds_receita,4000,1)
              from tb_paciente p,tm_atendimento ate,tb_receita_atendimento a
             where a.dt_receita between to_date('01/01/1900','dd/mm/yyyy') and trunc(sysdate)
               and a.fl_validado = 'S'
               and a.cd_profissional_cancela is null
               and length(a.ds_receita) > 0
               and ate.cd_atendimento=a.cd_atendimento
               and p.cd_paciente=ate.cd_paciente
            union all
            select a.cd_atendimento,
                   null,
                   'RECEITA MÉDICA ESPECIAL',
                   a.dt_receita dt_evolucao,
                   a.hr_receita hr_evolucao,
                   a.cd_profissional_valida,
                   0 nu_evolucao,
                   0 cd_ordem,
                   0 cd_ocorrencia_plano,
                   null,
                   null,
                   22 || ';' || a.cd_atendimento || ';' ||
                   a.cd_ocorrencia_plano || ';' || a.cd_ordem_receita cd_chave,
                   dbms_lob.substr(ds_receita_especial,4000,1)
              from tb_receita_atendimento a
             where a.dt_receita between to_date('01/01/1900','dd/mm/yyyy') and trunc(sysdate)
               and a.fl_validado = 'S'
               and a.cd_profissional_cancela is null
               and length(a.ds_receita_especial) > 0
            Union All
            select a.cd_atendimento,
                   null,
                   'CONSULTA AMBULATORIAL',
                   a.dt_atendimento,
                   to_number(to_char(a.dt_atendimento, 'sssss')),
                   null,
                   a.cd_senha_master,
                   0,
                   0,
                   null,
                   null,
                   1009900 || ';' || a.cd_atendimento || ';' || a.cd_senha_master || ';' || to_char(a.dt_atendimento, 'dd/mm/yyyy hh24:mi:ss')||';'||a.cd_medico cd_chave,
                   a.ds_queixa_princial||' '||chr(13)||
                   a.ds_diagnostico||' '||chr(13)||
                   a.ds_evolucao||' '||chr(13)||
                   a.ds_exames_fisico
              from tb_historico_paciente_sa a
             where cd_atendimento in
                   (Select cd_atendimento
                      from tm_atendimento
                     where dt_atendimento between to_date('01/01/1900','dd/mm/yyyy') and trunc(sysdate)
                       and fl_internacao = 'N')
               and cid10 is not null
               and nvl(fn_verifica_documento(a.cd_atendimento,12),'A')!='12'
     Order By 1 Desc, 4 desc,5 Desc ) r,
     vw_profissional p
where p.cd_profissional=r.cd_profissional
/

