create view VW_DIETA_TIPO_INDICACAO as
select d.cd_dieta,d.nm_dieta,
         td.cd_tipo_dieta,td.ds_tipo_dieta,
         d.ds_indicacao_uso
  from tb_tipo_dieta td,tb_dieta d
  where d.cd_tipo_dieta=td.cd_tipo_dieta
/

