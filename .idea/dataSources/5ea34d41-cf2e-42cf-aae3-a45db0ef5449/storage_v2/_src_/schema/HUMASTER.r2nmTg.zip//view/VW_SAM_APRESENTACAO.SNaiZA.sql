create view VW_SAM_APRESENTACAO as
select cd_apresentacao, nm_apresentacao
  from tb_apresentacao
 order by nm_apresentacao
/

