create view VW_ESPECIDADE_MEDICA_HAP as
SELECT DISTINCT
    CD_ESP_PRESTADOR,
    DS_ESPECIALIDADE,
    NU_CGC_CPF
  FROM
    (
      SELECT DISTINCT
        pres.CD_ESPECIALIDADE CD_ESP_PRESTADOR,
        ES.DS_ESPECIALIDADE,
        p.NU_CGC_CPF
      FROM
        TB_SERV_REDE_ESPECIALIDADE@hapvida pres ,
        tb_pessoa@hapvida p ,
        tb_especialidade@hapvida es
      WHERE
        pres.cd_pessoa          = p.cd_pessoa
      AND pres.CD_ESPECIALIDADE = es.CD_ESPECIALIDADE
      AND TRUNC(sysdate) BETWEEN pres.DT_INICIO_VIGENCIA AND NVL(
        pres.DT_FIM_VIGENCIA,TRUNC(SYSDATE + 1))
      UNION ALL
      SELECT
        c.cd_especialidade,
        e.ds_especialidade,
        t.NU_CNPJ_CPF
      FROM
        tb_cred_med@hapvida t ,
        tb_cred_consultas@hapvida c,
        tb_especialidade@hapvida e
      WHERE
        t.cd_protocolo       = c.cd_protocolo
      AND c.cd_especialidade = e.cd_especialidade
      AND
        (
          TRUNC(SYSDATE) BETWEEN TRUNC(t.dt_solicitacao )AND TRUNC(
          t.dt_solicitacao) +
          (
            SELECT
              to_number(t.vl_propriedade)
            FROM
              tb_propriedade t
            WHERE
              t.nm_propriedade =
              'QTDE_DIAS_CAD_MEDICO_SEM_APROVACAO_COMITE_HAPVIDA'
          )
        OR t.cd_solicitacao_status = 3
        AND t.dt_ini_vigencia     IS NOT NULL
        AND t.dt_ini_vigencia     <= TRUNC(sysdate)
        )
    )
/

