create view VW_SAM_GRUPO_DIETA as
    SELECT 'TODAS' ds_tipo_dieta, '99999' cd_tipo_dieta
  FROM TB_tipo_dieta
UNION
SELECT DS_TIPO_DIETA, to_char(CD_tipo_dieta)
  FROM TB_tipo_dieta
 where nvl(fl_ativo, 'N') = 'S'
 ORDER BY 2
/

