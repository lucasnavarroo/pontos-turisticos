create view VW_DADOS_PROFISSIONAL as
select p.cd_profissional cd_codigo,
         pes.nm_pessoa_razao_social nm_profissonal,
         p.cd_crm_profissional,
         p.cd_conselho,
         p.cd_uf_conselho,
         e.ds_endereco_eletronico,
         op.nm_operador login
    from tb_operador op,
         tb_pessoa pes,
         tb_endereco_eletronico_pessoa e,
         tb_profissional p
   where p.fl_status = 'A'
     and p.cd_profissional = e.cd_pessoa(+)
     and pes.cd_pessoa     = p.cd_profissional
     and p.cd_conselho     = 'CRM'
     and op.cd_pessoa      = pes.cd_pessoa
/

