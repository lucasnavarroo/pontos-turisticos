create view VW_ATENDIMENTO_PRODUTIVIDADE as
SELECT DISTINCT A.CD_ATENDIMENTO,
       A.DT_ATENDIMENTO,
       A.HR_ATENDIMENTO,
       A.CD_MEDICO_ATENDENTE,
       A.CD_MOTIVO_ATENDIMENTO,
       A.CD_UNIDADE_ATENDIMENTO,
       A.CD_PACIENTE,
       A.FL_BLOQUEIO,
       A.DT_BLOQUEIO,
       A.CD_USUARIO,
       C.CD_CONVENIO,
       DECODE(C.CD_CONVENIO,FN_CONVENIO_PROPRIO,'S','N')CONV_PROP,
       PP.VL_NAO_COOPERADOS,
       PP.VL_COOPERADOS,
       PP.VL_CONS_NOTURNA,
       PP.VL_DEMAIS_CONVENIOS,
       P.FL_FUNCIONARIO,
       (SELECT CASE WHEN A.HR_ATENDIMENTO BETWEEN 25200 AND 46800 THEN 1
                    WHEN A.HR_ATENDIMENTO BETWEEN 46800 AND 68400 THEN 2
               ELSE 3
               END
          FROM DUAL) TIPO_HORA,
       FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) TIP_PROD,
       -- Alteração para atender a múltiplos convênios por Rômulo Varne em 30/07/2008
       --Case when DECODE(C.CD_CONVENIO,FN_CONVENIO_PROPRIO,'S','N') = 'S' then case when p.fl_funcionario = 'S' then
       Case when DECODE(C.CD_CONVENIO,FN_CONVENIO_PROPRIO_ATEND(A.CD_ATENDIMENTO),'S','N') = 'S' then case when p.fl_funcionario = 'S' then
                                                                                 case when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 0 then 0
                                                                                      when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 1 then nvl(pp.vl_nao_cooperados,0)
                                                                                      when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 2 then nvl(pp.vl_cons_noturna,0)
                                                                                 end
                                                                               else
                                                                                 case when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 0 then 0
                                                                                      when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 1 then nvl(pp.vl_cooperados,0)
                                                                                      when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 2 then nvl(pp.vl_cons_noturna,0)
                                                                                 end
                                                                              end
       else case when FN_TIPO_PROD(A.DT_ATENDIMENTO,A.HR_ATENDIMENTO,A.CD_MEDICO_ATENDENTE,PP.CD_FILIAL) = 0 then 0
            else nvl(pp.vl_demais_convenios,0)
            end
       end Vlr_prod

FROM
     TM_SETOR S,
     TB_PARAM_PRODUTIVIDADE PP,
     TB_ESPECIALIDADE E,
     TB_ESPECIALIDADE_PROFISSIONAL EP,
     TB_PROFISSIONAL P,
     TB_PESSOA M,
     TB_PROCEDIMENTO_REALIZADO PR,
     TB_GUIA G,
     TM_CONVENIO CV,
     TB_CONVENIO_PAGADOR C,
     TM_ATENDIMENTO A
WHERE A.CD_TIPO_ATENDIMENTO+0              IN      (2,3,6)
  AND A.CD_SETOR || ''                     NOT     IN   ('116600', '500000', '824700')  -- hapclina e vicunha natal
  AND A.DT_CANC_ATEND                      IS      NULL
  AND C.CD_ATENDIMENTO                      =       A.CD_ATENDIMENTO
  AND C.CD_CONVENIO_PAGADOR                 =       1
  AND C.CD_CONVENIO_BASE+0                 NOT   IN   (92,108,8888)
  AND CV.CD_CONVENIO                        =   C.CD_CONVENIO_BASE
  AND CV.FL_TIPO||''                       NOT IN (9) -- conv particular
  AND C.CD_ATENDIMENTO                      =       G.CD_ATENDIMENTO
  AND G.CD_OCORRENCIA                       BETWEEN 1 AND 9999
  AND G.CD_ATENDIMENTO                      =       PR.CD_ATENDIMENTO
  AND G.CD_OCORRENCIA                       =       PR.CD_OCORRENCIA
  AND PR.CD_ORDEM                           BETWEEN 1 AND 999
  AND PR.VL_PROCEDIMENTO                    >       0
  AND ((A.CD_UNIDADE_ATENDIMENTO       =    '007'
              AND PR.CD_PROCEDIMENTO        IN     ('00010071','10101039')  )
   OR  ((A.CD_UNIDADE_ATENDIMENTO           NOT IN ('007')  )
              AND PR.CD_PROCEDIMENTO        IN      ('00010014','10101012', '00010071','10101039') ) )
  AND M.CD_PESSOA                           =       A.CD_MEDICO_ATENDENTE
  AND M.CD_PESSOA                           =       P.CD_PROFISSIONAL
  AND P.CD_PROFISSIONAL                   NOT IN  (7463,9105,7951,239828,103446)
  AND P.CD_PROFISSIONAL                    =       EP.CD_PROFISSIONAL
  AND EP.FL_ESP_PRINCIPAL                  =       'P'
  AND EP.CD_ESPECIALIDADE                  =       E.CD_ESPECIALIDADE
  AND PP.CD_FILIAL                         =       A.CD_UNIDADE_ATENDIMENTO
  AND PP.CD_ESPECIALIDADE                  =     EP.CD_ESPECIALIDADE
  AND S.CD_SETOR                           =      A.CD_SETOR
  AND ((S.FL_PRODUTIVIDADE_MEDICA    = 'S'
         AND A.CD_ATENDIMENTO IN  (SELECT H.CD_ATENDIMENTO
                                     FROM TB_HISTORICO_PACIENTE_SA H
                                    WHERE H.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                                      AND ROWNUM = 1) )
   OR    (S.FL_PRODUTIVIDADE_MEDICA = 'N')   )
/

