create view VW_SENHA_AGUARDANDO as
select /*+choose */
       sa.CD_SENHA_MASTER,
       sa.CD_GRUPO_ATENDIMENTO,
       sa.CD_LOCAL_ATENDIMENTO,
       sa.CD_SENHA_ATENDIMENTO,
       sa.CD_PONTO_ATENDIMENTO_ATE,
       sa.CD_ATENDIMENTO,
       sa.DT_GERACAO_SENHA,
       sa.DT_INICIO_ATENDIMENTO,
       sa.DT_INICIO_CADASTRO,
       sa.NM_PACIENTE,
       sa.VL_IDADE,
       sa.FL_STATUS,
       sa.CD_PACIENTE,
       sa.FL_PRIORIDADE,
       a.cd_medico_atendente,
       nm_operador_obs_retorno,
       sa.FL_PRINCIPAL,
       sa.CD_GRUPO_CONSULTORIO,
       sa.fl_triagem,
       sa.cd_nivel_classificacao_risco,
       sa.cd_operador_inicio_triagem,
       sa.dt_inicio_triagem,
       sa.dt_fim_triagem,
       a.cd_natureza_consulta,
       a.fl_gerado_auto,
       sa.fl_retorna_para_grupo
from   TB_LOCAL_ATENDIMENTO_sa loc,
       tb_atendimento a,
       tb_senha_atendimento_sa sa
where  a.cd_atendimento        = sa.CD_ATENDIMENTO
and    loc.CD_LOCAL_ATENDIMENTO = sa.CD_LOCAL_ATENDIMENTO
and    a.cd_tipo_atendimento   not in (0,5,7,8,10)
and    a.DT_FIM_ATENDIMENTO    is null
and    sa.fl_status            in (2,6,8)
and    dt_geracao_senha        >= trunc(sysdate)- 3
and    dt_geracao_senha        >= trunc(sysdate)- nvl(loc.qt_dias_coleta,1)
/

