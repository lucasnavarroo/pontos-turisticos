create view TB_NOTA_OBRIGACAO as
select "CD_NOTA","CD_DOCUMENTO_CONTROLE","DT_VENCIMENTO","VL_PARCELA","CD_UNIDADE_ATENDIMENTO","FL_PARCELA" from tm_nota_obrigacao
where cd_unidade_atendimento like fn_unidade
/

