create view VW_SAM_DILUENTE as
SELECT DISTINCT a.nm_material || ' ' || a.cd_apresentacao NM_PRODUTO,
                A.FL_PADRONIZADO,
                A.NM_MATERIAL,
                A.CD_APRESENTACAO,
                A.QT_DOSAGEM,
                A.CD_UNIDADE_DOSAGEM,
                DECODE(A.CD_UNIDADE_CONTEUDO_DOSE,
                       NULL,
                       '',
                       '/' || TO_CHAR(A.QT_CONTEUDO_DOSAGEM) ||
                       A.CD_UNIDADE_CONTEUDO_DOSE) DOSE,
                DECODE(A.CD_APRESENTACAO, '-', NULL, A.QT_CONTEUDO) QT_CONTEUDO,
                A.CD_UNIDADE_USUAL,
                A.CD_MATERIAL,
                D.NU_PRODUTO
  FROM TB_MATERIAL A, TB_PRODUTO_MAT_MED C, TB_PRODUTO D
 WHERE D.NU_PRODUTO = C.NU_PRODUTO
   AND C.CD_MAT_MED = A.CD_MATERIAL
   AND PK_PRESCRICAO.FN_CHECK_MATERIAL(A.CD_MATERIAL) = 'S'
   AND D.FL_DILUENTE = 'S'
/

