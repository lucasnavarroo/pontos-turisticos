create view VW_ACESSO_EMPRESA as
select a.nm_operador,
         a.cd_filial,
         aaa.nm_fantasia nm_filial,
         ab.nm_unidade_atendimento nm_empresa,
         a.cd_setor_operacao,
         substr(ac.nm_setor, 1, 30) nm_setor_operacao,
         a.cd_unidade_atendimento,
         a.dt_ultimo_login,
         a.cd_terminal
    from    tm_setor               ac,
            tb_unidade_atendimento ab,
               tb_pessoa           aaa,
            tb_filial              aa,
         tb_acesso_empresa         a
   where 1 = 1
     and a.nm_operador = fn_user
     and aa.cd_filial(+) = a.cd_filial
     and aaa.cd_pessoa(+) = aa.cd_pessoa
     and ab.cd_unidade_atendimento(+) = a.cd_unidade_atendimento
     and ac.cd_setor(+) = a.cd_setor_operacao
/

