create view VW_SAM_TIPO_PADRAO_PRESCRICAO as
SELECT pmm.cd_modelo,
       pmm.ds_modelo,
       pmm.fl_prescricao_medica,
       pmm.fl_status_prescricao,
       pmm.cd_avaliacao,
       pmm.cd_profissional,
       pmm.qt_frequencia_uso,
       pmm.dt_inicio_avaliacao,
       pmm.hr_inicio_avaliacao,
       pmm.qt_peso_kg_registrado,
       pmm.cd_subgrupo_avaliacao,
       gamp.cd_grupo_atendimento,
       gamp.cd_local_atendimento
  FROM tb_prescricao_medica_modelo pmm, tb_grupo_atend_modelo_presc gamp
 WHERE pmm.cd_modelo = gamp.cd_modelo
/

