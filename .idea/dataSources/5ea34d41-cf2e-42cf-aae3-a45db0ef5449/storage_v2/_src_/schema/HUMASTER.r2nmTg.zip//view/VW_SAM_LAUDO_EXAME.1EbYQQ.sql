create view VW_SAM_LAUDO_EXAME as
SELECT lp.cd_atendimento, --filtro (exame ou procedimento)
       lp.cd_ocorrencia, --filtro
       lp.cd_ordem, --filtro
       nvl(mle.cd_mnemonico, '') cd_mnemonico,
       lp.cd_modelo_laudo,
       lp.nm_exame,
       lp.ds_laudo_medico
  from TB_LAUDO_PACIENTE lp, TB_MODELO_LAUDO_EXAME mle
 where lp.cd_modelo_laudo = mle.cd_modelo_laudo(+)
/

