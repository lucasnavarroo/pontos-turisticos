create view VW_SENHA_OBSERVACAO as
select  /*+ choose */
        sa.CD_SENHA_MASTER,
        sa.CD_GRUPO_ATENDIMENTO,
        sa.CD_LOCAL_ATENDIMENTO,
        sa.CD_SENHA_ATENDIMENTO,
        sa.CD_PONTO_ATENDIMENTO_ATE,
        sa.CD_ATENDIMENTO,
        sa.dt_inicio_atendimento,
        sa.DT_GERACAO_SENHA,
        sa.NM_PACIENTE,
        sa.VL_IDADE,
        sa.CD_PACIENTE,
        sa.fl_prioridade,
        sa.FL_STATUS,
        sa.NM_OPERADOR_OBS_RETORNO,
        sa.CD_NIVEL_CLASSIFICACAO_RISCO,
        sa.CD_USUARIO,
        sa.FL_TRIAGEM,
        NVL(sa.QT_TENT_RETOR_OBSERVACAO,0)QT_TENT_RETOR_OBSERVACAO
 from   tb_local_atendimento_sa loc,
        tb_senha_atendimento_sa sa
 where  sa.fl_status                in (5,10)
 and    sa.dt_geracao_senha         >= trunc(sysdate)-3
 and    sa.dt_geracao_senha         >= trunc(sysdate)- nvl(loc.qt_dias_coleta,1)
 and    loc.cd_local_Atendimento    = sa.cd_local_atendimento
/

