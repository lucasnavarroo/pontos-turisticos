create view VW_ITENS_KIT_EXTRA as
select /*
             Fred Monteiro - IVIA - 22/11/2017
             View que contem os itens extra do kit
         */
         a.id_kit,
         a.cd_atendimento,
         aa.cd_unidade_atendimento,
         aaa.nm_unidade_atendimento,
         abba.cd_param_grupo_proc,
         abba.nm_param_grupo_proc,
         abba.cd_tipo_grupo_proc,
         ab.cd_procedimento,
         aba.nm_procedimento,
         ab.dt_transacao,
         acaaa.fl_tipo_classificacao,
         acaaa.ds_fl_tipo_classificacao,
         acaaa.cd_tipo_produto_servico,
         acaa.cd_tipo_classificacao,
         acaa.ds_tipo_classificacao,
         aca.cd_classificacao,
         aca.nm_classificacao,
         ac.cd_material,
         ac.nm_material,
         sum(nvl(a.qt_dispensada, 0)) qtd,
         a.cd_pessoa_func_recebeu_extra cd_pessoa
    from             tb_classe_tipo_classificacao acaaa, -- tipo classe
                  tb_tipo_classificacao           acaa,  -- tipo de classificacao
               tb_classificacao                   aca,   -- classificacao do material
            tb_material                           ac,    -- tabela de materiais
                  tb_param_grupo_proc             abba,  -- grupo de procedimento
               tb_proc_grupo_proc                 abb,   -- procedimento x grupo de procedimento
               tb_procedimento                    aba,   -- procedimento do kit
            tm_kit_cirurgia_lote                  ab,    -- kit
               tb_unidade_atendimento             aaa,   -- unidade de atendimento
            tm_atendimento                        aa,    -- atendimento do kit
         tb_registro_saidas_extras                a      -- itens extra do kit
   where 1 = 1
     -- filtros
     -- join a -- aa
     and a.cd_atendimento = aa.cd_atendimento
     -- join aa -- aaa
     and aa.cd_unidade_atendimento = aaa.cd_unidade_atendimento
     -- join a -- ab
     and a.id_kit = ab.id_kit
     -- join ab -- aba
     and ab.cd_procedimento = aba.cd_procedimento
     -- join a -- ac
     and a.cd_material = ac.cd_material
     -- join ac -- aca
     and ac.cd_classificacao = aca.cd_classificacao
     -- join aca -- acaa
     and aca.cd_tipo_classificacao = acaa.cd_tipo_classificacao
     -- join acaa -- acaaa
     and acaa.fl_tipo_classificacao = acaaa.fl_tipo_classificacao
     -- join ab -- abb
     and ab.cd_procedimento = abb.cd_procedimento
     -- join abb -- abba
     and abb.cd_param_grupo_proc = abba.cd_param_grupo_proc
   group by a.id_kit,
            a.cd_atendimento,
            aa.cd_unidade_atendimento,
            aaa.nm_unidade_atendimento,
            abba.cd_param_grupo_proc,
            abba.nm_param_grupo_proc,
            abba.cd_tipo_grupo_proc,
            ab.cd_procedimento,
            aba.nm_procedimento,
            ab.dt_transacao,
            acaaa.fl_tipo_classificacao,
            acaaa.ds_fl_tipo_classificacao,
            acaaa.cd_tipo_produto_servico,
            acaa.cd_tipo_classificacao,
            acaa.ds_tipo_classificacao,
            aca.cd_classificacao,
            aca.nm_classificacao,
            ac.cd_material,
            ac.nm_material,
            a.cd_pessoa_func_recebeu_extra
/

