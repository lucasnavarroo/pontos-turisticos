create view VW_MEDICO_REPASSE as
select rm.cd_pessoa,
       pf.nm_pessoa_razao_social,
       rm.cd_associado,
       pf.nu_cgc_cpf,
       rm.vl_pago,
       (rm.vl_pago - (round((rm.vl_pago * nvl(p.pc_desconto,0) ) / 100, 2))) vl_liquido,
       rm.cd_convenio,
       pcon.nm_pessoa_razao_social nm_convenio,
       rm.nu_remessa,
       rm.dt_remessa,
       rm.dt_obrigacao
  from tm_convenio       c,
       tb_profissional   p,
       tb_pessoa         pcon,
       tb_pessoa         pf,
       tb_repasse_medico rm
 where nvl(p.cd_cooperativa, 'N') <> 'S'
   and rm.cd_unidade_atendimento = FN_UNIDADE_OPERADOR
   and rm.cd_pessoa = pf.cd_pessoa
   and rm.cd_pessoa = p.cd_profissional
   and rm.cd_convenio = c.cd_convenio
   and c.cd_pessoa = pcon.cd_pessoa
/

