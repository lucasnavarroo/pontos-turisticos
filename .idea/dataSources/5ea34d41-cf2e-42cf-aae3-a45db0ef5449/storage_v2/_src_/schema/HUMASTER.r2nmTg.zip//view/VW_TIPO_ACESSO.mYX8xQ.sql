create view VW_TIPO_ACESSO as
select CD_TIPO_ACESSO, NM_TIPO_ACESSO from tb_tipo_acesso
/

