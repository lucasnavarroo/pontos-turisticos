create view VW_CARENCIA_MODULO_HV as
select "NU_USUARIO","CD_MODULO","DT_REFERENCIA_CARENCIA","PERCENTUAL_COMPRA" from tb_carencia_modulo@hapvida
/

