create view VW_CEDENTE_SACADO_S as
select "CD_PESSOA","CD_TIPO_CEDENTE_SACADO","DT_ULTIMA_TRANSACAO" from tb_cedente_sacado@hapvida
/

