create view VW_SAM_ITENS_HV as
select distinct p.nu_produto,
                p.nm_produto,
                m.cd_apresentacao,
                m.cd_unidade_usual,
                p.nu_ordem_apresentacao,
                nvl(p.fl_possui_glicose, 'N') fl_possui_glicose,
                nvl(p.fl_soro, 'N') fl_soro,
                nvl(p.fl_eletrolito, 'N') fl_eletrolito,
                nvl(p.fl_pode_diluente_inf_lenta, 'N') fl_pode_diluente_inf_lenta
  from tb_material m, tb_produto_mat_med mp, tb_produto p
 where p.nu_produto = mp.nu_produto
   and mp.cd_mat_med = m.cd_material
   and (p.fl_compoe_hv = 'S' or p.fl_eletrolito = 'S')
   and p.nu_produto not in (1047,
                            1531,
                            1550,
                            1905,
                            3499,
                            4282,
                            4378,
                            4379,
                            4380,
                            4393,
                            4483,
                            1052,
                            4369,
                            65,
                            1537,
                            1061,
                            566,
                            2245)
 order by nvl(nu_ordem_apresentacao, 999)
/

