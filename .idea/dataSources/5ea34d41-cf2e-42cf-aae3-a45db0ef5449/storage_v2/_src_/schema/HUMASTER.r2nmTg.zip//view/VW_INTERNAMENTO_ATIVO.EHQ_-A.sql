create view VW_INTERNAMENTO_ATIVO as
select u.cd_unidade_atendimento,
       u.nm_unidade_atendimento,
       p.cd_paciente cd_prontuario,
       a.cd_atendimento,
       p.nm_paciente,
       to_char(p.dt_nascimento, 'ddmmyyyy') dt_nascimento,
       a.cd_medico_atendente,
       pma.nm_pessoa_razao_social nm_medico_atendente,
       a.cd_medico_acompanha,
       pmc.nm_pessoa_razao_social nm_medico_acompanha,
       prof.cd_conselho,
       prof.cd_crm_profissional,
       prof.cd_uf_conselho,
       a.cd_tipo_atendimento,
       tp.nm_tipo_atendimento,
       a.cd_motivo_atendimento,
       decode(a.cd_motivo_atendimento,1,'URGENCIA','ELETIVO') nm_motivo_atendimento,
       to_char(a.dt_atendimento, 'ddmmyyyy') dt_atendimento,
       fn_hora(a.hr_atendimento) hr_atendimento,
       a.cd_clinica,
       c.nm_clinica,
       o.cd_posto,
       o.cd_acomodacao,
       o.cd_classe_acomodacao,
       o.nu_leito,
       sp.nm_setor nm_posto,
       to_char(o.dt_ocupacao, 'ddmmyyyy') dt_ocupacao,
       fn_hora(o.hr_ocupacao) hr_ocup,
       to_char(o.dt_prevista_liberacao, 'ddmmyyyy') dt_prevista_liberacao,
       fn_hora(o.hr_prevista_liberacao) hr_prev_lib
  from tb_profissional prof,
       tb_pessoa pmc,
       tb_pessoa pma,
       tb_tipo_atendimento tp,
       tm_setor sp,
       tb_clinica c,
       tb_unidade_atendimento u,
       tb_paciente p,
       tm_atendimento a,
       tb_ocupacao_acomodacao o
 where o.fl_ocupacao            = 'S'
   and a.cd_atendimento         = o.cd_atendimento
   and p.cd_paciente            = a.cd_paciente
   and u.cd_unidade_atendimento = a.cd_unidade_atendimento
   and c.cd_clinica             = a.cd_clinica
   and sp.cd_setor              = o.cd_posto
   and tp.cd_tipo_atendimento   = a.cd_tipo_atendimento
   and a.dt_fim_atendimento||'' is null
   and a.dt_atendimento         > to_date('01/01/2017','dd/mm/yyyy')
   and pma.cd_pessoa            = a.cd_medico_atendente
   and pmc.cd_pessoa(+)         = a.cd_medico_acompanha
   and prof.cd_profissional     = a.cd_medico_atendente
/

