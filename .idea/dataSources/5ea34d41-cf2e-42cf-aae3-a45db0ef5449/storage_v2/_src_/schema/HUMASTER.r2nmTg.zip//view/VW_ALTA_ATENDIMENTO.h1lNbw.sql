create view VW_ALTA_ATENDIMENTO as
select  tb_convenio_pagador.cd_convenio_base,
	  tb_atendimento.cd_atendimento,
	  tb_atendimento.dt_atendimento,
	  tb_atendimento.cd_clinica,
	  tb_paciente.dt_nascimento,
	  tb_alta_atendimento.cd_alta,
	  tb_alta_atendimento.dt_alta
   from tb_convenio_pagador,tb_atendimento,tb_alta_atendimento,
	tb_tipo_alta,tb_paciente
   where tb_paciente.cd_paciente = tb_atendimento.cd_paciente
    and  tb_convenio_pagador.cd_atendimento = tb_atendimento.cd_atendimento
    and  tb_convenio_pagador.cd_convenio_pagador = 1
    and  tb_atendimento.cd_atendimento = tb_alta_atendimento.cd_atendimento
    and  tb_alta_atendimento.cd_alta = tb_tipo_alta.cd_tipo_alta
/

