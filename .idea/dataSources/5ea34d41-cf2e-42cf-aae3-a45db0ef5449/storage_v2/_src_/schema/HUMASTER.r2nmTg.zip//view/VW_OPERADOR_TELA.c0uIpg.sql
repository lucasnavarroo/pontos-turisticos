create view VW_OPERADOR_TELA as
select initcap(substr(nm_tela, 1, 44)) nm_tela,
       cd_menu,
       cd_tela,
       nm_bloco_entrada
  from tb_tela
connect by prior cd_tela = cd_menu
 start with cd_menu =
            (select b.cd_menu from tb_operador b where nm_operador = fn_user)
/

