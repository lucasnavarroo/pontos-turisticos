create view VW_LISTA_EXAME as
select pro.cd_procedimento cd_exame,
       pro.nr_procedimento nr_exame,
       pro.nm_procedimento nm_exame,
       pro.fl_cirurgia classe_proc,
       decode(pro.fl_cirurgia,0,'outros',
                              1,'cirurgico',
                              2,'exames',
                              3,'parenteral','outros') ds_classe_procedimento,
       tp.cd_tipo_procedimento cd_tp_exame,
       tp.nm_tipo_procedimento nm_tp_exame,
       fl_cirurgia fl_classe_exame,
       fl_membros_pares,
       fl_parto,
       fl_permite_atestado,
       fl_procedimento_ficticio,
       fl_procedimento_vida_imagem,
       fl_protocolo_sepse,
       fl_solic_inter_na_emergencia,
       fl_somente_emergencia,
       fl_somente_internacao ,
       fl_tipo_exame,
       fl_urgencia,
       qt_dias,
       qt_dias_terceirizados,
       qt_hr_padrao_exame_eme,
       qt_idade_final,
       qt_idade_inicial
  from tb_tipo_procedimento tp,
       tb_procedimento pro
 where pro.fl_cirurgia = 2
   and pro.fl_tipo_exame in (0,1,2)
   and tp.cd_tipo_procedimento   = pro.fl_tipo_exame
/

