create view VW_ATEND_UNIPAR_ABERTO999 as
    SELECT /*+ no_expand use_nl(a) */
       DISTINCT A.CD_ATENDIMENTO, -- ATENDIMENTOS EM ABERTO                                         
       A.CD_PACIENTE,                                                                               
       P.NM_PACIENTE,                                                                               
       A.DT_ATENDIMENTO,                                                                            
       A.DT_FIM_ATENDIMENTO,                                                                        
       CP.CD_COBRANCA,                                                                              
       CP.DT_COBRANCA,                                                                              
       TA.NM_TIPO_ATENDIMENTO,                                                                      
       O.CD_OBRIGACAO,                                                                              
       O.VL_OBRIGACAO,                                                                              
       O.VL_OBRIGACAO - NVL(FN_CUSTO_HAP(A.CD_ATENDIMENTO),0) VL_SALDO,                             
       NVL(FN_CUSTO_HAP(A.CD_ATENDIMENTO),0) VL_HAP,                                                
       CP.CD_PESSOA CD_PESSOA_COBRA,                                                                
       O.CD_NEGOCIACAO_OBRIGACAO,                                                                   
       A.CD_USUARIO_DIGITADOR,                                                                      
       'COBRANCA EM ABERTO - NAO PAGA' SITUACAO                                                     
  FROM TB_TIPO_ATENDIMENTO TA,                                                                      
       TB_PACIENTE P,                                                                               
       TB_OBRIGACAO O,                                                                              
       TB_COBRANCA_PACIENTE CP,                                                                     
       TB_ATENDIMENTO A                                                                             
 WHERE A.DT_FIM_ATENDIMENTO BETWEEN   TO_DATE('01/01/1900','DD/MM/YYYY')                            
   AND                                TO_DATE('01/01/2999','DD/MM/YYYY')                            
   AND CP.CD_ATENDIMENTO          =   A.CD_ATENDIMENTO                                              
   AND CP.CD_CONVENIO             IN  (FN_CONVENIO_PARTICULAR)                                      
   AND CP.DT_COBRANCA             IS  NOT NULL                                                      
   AND CP.VL_SALDO                <   0                                                             
   AND O.CD_DOCUMENTO_GERADOR     =   TO_CHAR(CP.CD_ATENDIMENTO)                                    
   AND O.CD_DOCUMENTO_CONTROLE    =   TO_CHAR(CP.CD_COBRANCA)                                       
   AND O.CD_ESPECIE_TITULO        =   30                                                            
   AND O.CD_STATUS                IN  (1,10,13)                                                     
   AND O.VL_OBRIGACAO             NOT IN  0                                                         
   AND P.CD_PACIENTE              =   A.CD_PACIENTE                                                 
   AND TA.CD_TIPO_ATENDIMENTO     =   A.CD_TIPO_ATENDIMENTO                                         
UNION ALL -- OBRIGACOES PAGAS PARCIALMENTE                                                          
SELECT /*+ driving_site(A) use_nl(a) */
       DISTINCT A.CD_ATENDIMENTO,                                                                   
       A.CD_PACIENTE,                                                                               
       P.NM_PACIENTE,                                                                               
       A.DT_ATENDIMENTO,                                                                            
       A.DT_FIM_ATENDIMENTO,                                                                        
       CP.CD_COBRANCA,                                                                              
       CP.DT_COBRANCA,                                                                              
       TA.NM_TIPO_ATENDIMENTO,                                                                      
       O.CD_OBRIGACAO,                                                                              
       O.VL_OBRIGACAO,                                                                              
       O.VL_SALDO_OBRIGACAO - nvl(fn_custo_hap(cp.cd_atendimento),0) VL_SALDO,                      
       nvl(fn_custo_hap(cp.cd_atendimento),0) vl_hap,                                               
       CP.CD_PESSOA CD_PESSOA_COBRA,                                                                
       O.CD_NEGOCIACAO_OBRIGACAO,                                                                   
       A.CD_USUARIO_DIGITADOR,                                                                      
       'COBRANCA PAGA PARCIALMENTE'                                                                 
  FROM TB_TIPO_ATENDIMENTO TA,                                                                      
       TB_PACIENTE P,                                                                               
       TB_MOVIMENTO_OBRIGACAO MO,                                                                   
       TB_OBRIGACAO O,                                                                              
       TB_COBRANCA_PACIENTE CP,                                                                     
       TB_ATENDIMENTO A                                                                             
 WHERE A.DT_FIM_ATENDIMENTO BETWEEN   TO_DATE('01/01/1900','DD/MM/YYYY')                            
   AND                                TO_DATE('01/01/2999','DD/MM/YYYY')                            
   AND CP.CD_ATENDIMENTO          =   A.CD_ATENDIMENTO                                              
   AND CP.CD_CONVENIO             IN (FN_CONVENIO_PARTICULAR)                                       
   AND CP.DT_COBRANCA             IS  NOT NULL                                                      
   AND CP.VL_SALDO                <   0                                                             
   AND O.CD_DOCUMENTO_GERADOR     =   TO_CHAR(CP.CD_ATENDIMENTO)                                    
   AND O.CD_DOCUMENTO_CONTROLE    =   TO_CHAR(CP.CD_COBRANCA)                                       
   AND O.CD_ESPECIE_TITULO        =   30                                                            
   AND O.CD_STATUS                =   2                                                             
   AND O.VL_OBRIGACAO             NOT IN  0                                                         
   AND MO.CD_OBRIGACAO            =   O.CD_OBRIGACAO                                                
   AND P.CD_PACIENTE              =   A.CD_PACIENTE                                                 
   AND TA.CD_TIPO_ATENDIMENTO     =   A.CD_TIPO_ATENDIMENTO                                         
UNION ALL -- Atendimento exames que nao foram gerado cobranca (UNIPAR)                              
SELECT /*+ push_subq rule driving_site(A) use_nl(a) */
       DISTINCT A.CD_ATENDIMENTO,                                                                   
       A.CD_PACIENTE,                                                                               
       P.NM_PACIENTE,                                                                               
       A.DT_ATENDIMENTO,                                                                            
       A.DT_ATENDIMENTO,                                                                            
       NULL,                                                                                        
       SYSDATE,                                                                                     
       TA.NM_TIPO_ATENDIMENTO,                                                                      
       0,                                                                                           
       0,                                                                                           
       0,                                                                                           
       0,                                                                                           
       GU.CD_PESSOA_REALIZA,                                                                        
       0,                                                                                           
       A.CD_USUARIO_DIGITADOR,                                                                      
       'COBRANCA NAO GERADA - EXAMES'                                                               
  FROM TB_TIPO_ATENDIMENTO TA,                                                                      
       TB_PACIENTE P,                                                                               
       TB_PROCEDIMENTO_REALIZADO PR,                                                                
       TB_CONVENIO_PAGADOR CP,                                                                      
       TB_GUIA GU,                                                                                  
       TB_PEDIDO_EXAME PE,                                                                          
       TB_ATENDIMENTO A                                                                             
 WHERE A.DT_ATENDIMENTO BETWEEN       TO_DATE('01/01/1900','DD/MM/YYYY')                            
   AND                                TO_DATE('01/01/2999','DD/MM/YYYY')                            
   AND PE.CD_ATENDIMENTO          =   A.CD_ATENDIMENTO                                              
   AND PE.CD_OCORRENCIA           BETWEEN 1 AND 999                                                 
   AND GU.CD_ATENDIMENTO          =   PE.CD_ATENDIMENTO                                             
   AND GU.CD_OCORRENCIA_PEDIDO    =   PE.CD_OCORRENCIA                                              
   and gu.cd_cobranca             is  null                                                          
   AND CP.CD_ATENDIMENTO          =   GU.CD_ATENDIMENTO                                             
   AND CP.CD_CONVENIO_PAGADOR     =   GU.CD_CONVENIO_PAGADOR                                        
   AND CP.CD_CONVENIO_BASE        IN (FN_CONVENIO_PARTICULAR)                                       
   AND PR.CD_ATENDIMENTO          =   GU.CD_ATENDIMENTO                                             
   AND PR.CD_OCORRENCIA           =   GU.CD_OCORRENCIA                                              
   AND PR.CD_ORDEM                BETWEEN 1 AND 99                                                  
   AND NOT EXISTS (SELECT 'X'                                                                       
		     FROM TB_COBRANCA_PACIENTE CBP                                                                
		     WHERE CBP.CD_ATENDIMENTO =  PE.CD_ATENDIMENTO                                                
		     AND NVL(CBP.NU_GUIA,PE.CD_OCORRENCIA) =  PE.CD_OCORRENCIA                                    
                     AND CBP.CD_CONVENIO    IN (FN_CONVENIO_PARTICULAR)                             
                     AND CBP.nu_remessa     IS NOT NULL                                             
                     AND CBP.DT_COBRANCA    IS NOT NULL)                                            
   AND P.CD_PACIENTE              =   A.CD_PACIENTE                                                 
   AND TA.CD_TIPO_ATENDIMENTO     =   A.CD_TIPO_ATENDIMENTO                                         
UNION ALL -- Atendimento hospitalar que nao foram gerado cobranca (UNIPAR)                          
SELECT /*+ push_subq rule driving_site(A) use_nl(a) */
       DISTINCT A.CD_ATENDIMENTO,                                                                   
       A.CD_PACIENTE,                                                                               
       P.NM_PACIENTE,                                                                               
       A.DT_ATENDIMENTO,                                                                            
       A.DT_FIM_ATENDIMENTO,                                                                        
       NULL,                                                                                        
       SYSDATE,                                                                                     
       TA.NM_TIPO_ATENDIMENTO,                                                                      
       0,                                                                                           
       0,                                                                                           
       0,                                                                                           
       NVL(FN_CUSTO_HAP(A.CD_ATENDIMENTO),0) VL_HAP,                                                
       0,                                                                                           
       0,                                                                                           
       A.CD_USUARIO_DIGITADOR,                                                                      
       'COBRANCA NAO GERADA - HOSPITAL' SITUACAO                                                    
  FROM TB_TIPO_ATENDIMENTO TA,                                                                      
       TB_PACIENTE P,                                                                               
       TB_CONVENIO_PAGADOR CPG,                                                                     
       TB_ATENDIMENTO A                                                                             
 WHERE A.DT_FIM_ATENDIMENTO BETWEEN   TO_DATE('01/01/1900','DD/MM/YYYY')                            
   AND                                TO_DATE('01/01/2999','DD/MM/YYYY')                            
   AND CPG.CD_ATENDIMENTO         =   A.CD_ATENDIMENTO                                              
   AND CPG.CD_CONVENIO_BASE       IN  (FN_CONVENIO_PARTICULAR)                                      
   AND NOT EXISTS (SELECT 'X'                                                                       
                     FROM TB_COBRANCA_PACIENTE CP                                                   
	            WHERE CP.CD_ATENDIMENTO          =   A.CD_ATENDIMENTO                                  
                      AND CP.CD_CONVENIO             IN  (FN_CONVENIO_PARTICULAR                    
)                                                                                                   
                      AND CP.NU_REMESSA              IS NOT NULL                                    
                      AND CP.DT_COBRANCA             IS NOT NULL )                                  
   AND P.CD_PACIENTE              =   A.CD_PACIENTE                                                 
   AND TA.CD_TIPO_ATENDIMENTO     =   A.CD_TIPO_ATENDIMENTO
/

