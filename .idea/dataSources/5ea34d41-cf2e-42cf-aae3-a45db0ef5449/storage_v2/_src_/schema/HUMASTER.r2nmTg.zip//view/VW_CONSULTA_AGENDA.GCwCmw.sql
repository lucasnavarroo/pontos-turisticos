create view VW_CONSULTA_AGENDA as
select x.cd_posto,
       x.nm_posto,
       x.cd_acomodacao,
       x.nm_acomodacao,
       x.dt_agenda,
       sum(hora_01) hora_01,sum(hora_02) hora_02,sum(hora_03) hora_03,
       sum(hora_04) hora_04,sum(hora_05) hora_05,sum(hora_06) hora_06,
       sum(hora_07) hora_07,sum(hora_08) hora_08,sum(hora_09) hora_09,
       sum(hora_10) hora_10,sum(hora_11) hora_11,sum(hora_12) hora_12,
       sum(hora_13) hora_13,sum(hora_14) hora_14,sum(hora_15) hora_15,
       sum(hora_16) hora_16,sum(hora_17) hora_17,sum(hora_18) hora_18,
       sum(hora_19) hora_19,sum(hora_20) hora_20,sum(hora_21) hora_21,
       sum(hora_22) hora_22,sum(hora_23) hora_23,sum(hora_00) hora_00,
       sum(prev_01) prev_01,sum(prev_02) prev_02,sum(prev_03) prev_03,
       sum(prev_04) prev_04,sum(prev_05) prev_05,sum(prev_06) prev_06,
       sum(prev_07) prev_07,sum(prev_08) prev_08,sum(prev_09) prev_09,
       sum(prev_10) prev_10,sum(prev_11) prev_11,sum(prev_12) prev_12,
       sum(prev_13) prev_13,sum(prev_14) prev_14,sum(prev_15) prev_15,
       sum(prev_16) prev_16,sum(prev_17) prev_17,sum(prev_18) prev_18,
       sum(prev_19) prev_19,sum(prev_20) prev_20,sum(prev_21) prev_21,
       sum(prev_22) prev_22,sum(prev_23) prev_23,sum(prev_00) prev_00
  from
      (select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              1 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_01,
              0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,0 prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 1 and 1.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,1 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_02,
              0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,0 prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 2 and 2.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,1 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_03,
              0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,0 prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 3 and 3.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,1 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_04,
              0 prev_05,0 prev_06,0 prev_07,0 prev_08,0 prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 4 and 4.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,1 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_05,
              0 prev_06,0 prev_07,0 prev_08,0 prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 5 and 5.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,1 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_06,
              0 prev_07,0 prev_08,0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,
              0 prev_15,0 prev_16,0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,
              0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 6 and 6.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,1 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_07,
              0 prev_08,0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,
              0 prev_15,0 prev_16,0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,
              0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 7 and 7.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,1 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,
              0 prev_15,0 prev_16,0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,
              0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 8 and 8.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              1 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_09,
              0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 9 and 9.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,1 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_10,
              0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 10 and 10.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,1 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_11,
              0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 11 and 11.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,1 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_12,
              0 prev_13,0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 12 and 12.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,1 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_13,
              0 prev_14,0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 13 and 13.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,1 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_14,
              0 prev_15,0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 14 and 14.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,1 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_15,
              0 prev_16,0 prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 15 and 15.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,1 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_16,
              0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 16 and 16.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              1 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_17,
              0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 17 and 17.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,1 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_18,
              0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 18 and 18.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,1 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_19,
              0 prev_20,0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 19 and 19.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,1 hora_20,0 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,0 prev_19,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_20,
              0 prev_21,0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 20 and 20.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,1 hora_21,0 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,0 prev_19,0 prev_20,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_21,
              0 prev_22,0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 21 and 21.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,1 hora_22,0 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_22,
              0 prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 22 and 22.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,1 hora_23,0 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_23,0 prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 23 and 23.9999
       union all
       select a.cd_posto,
              b.nm_setor nm_posto,
              a.cd_acomodacao,
              c.nm_setor nm_acomodacao,
              a.dt_agenda dt_agenda,
              0 hora_01,0 hora_02,0 hora_03,0 hora_04,0 hora_05,0 hora_06,0 hora_07,0 hora_08,
              0 hora_09,0 hora_10,0 hora_11,0 hora_12,0 hora_13,0 hora_14,0 hora_15,0 hora_16,
              0 hora_17,0 hora_18,0 hora_19,0 hora_20,0 hora_21,0 hora_22,0 hora_23,1 hora_00,
              0 prev_01,0 prev_02,0 prev_03,0 prev_04,0 prev_05,0 prev_06,0 prev_07,0 prev_08,
              0 prev_09,0 prev_10,0 prev_11,0 prev_12,0 prev_13,0 prev_14,0 prev_15,0 prev_16,
              0 prev_17,0 prev_18,0 prev_19,0 prev_20,0 prev_21,0 prev_22,0 prev_23,
              trunc(((a.hr_prevista_liberacao / 60) / 60)) prev_00
         from tb_setor c,
              tb_setor b,
              tb_agenda_internacao a
        where a.cd_posto = b.cd_setor
          and a.cd_acomodacao = c.cd_setor
          and (b.fl_centro_cirurgico = 'S' or
               b.fl_centro_obstetrico = 'S')
          and ((a.hr_agenda / 60) / 60) between 00 and 00.9999) x
group by cd_posto,
         nm_posto,
         cd_acomodacao,
         nm_acomodacao,
         dt_agenda
/

