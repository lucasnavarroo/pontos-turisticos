create view VW_NOTAS_INCOMPLETAS as
    select "CD_NOTA","FL_NIVEL_ATUALIZACAO","DT_SAIDA","DT_ENTRADA","CD_FILIAL","CD_FORNECEDOR","CD_NOTA_FORNECEDOR","NM_SERIE","CD_ESPECIE_NOTA","CD_UM","VL_TOTAL_NOTA","VL_TOTAL_MATERIAL","VL_BASE_ICMS","PC_ICMS","VL_ICMS","PC_ALIQUOTA_ESTADO","VL_IPI","VL_DESPESAS_ACESSORIAS","VL_ICMS_RETIDO","VL_DIFERENCA_ICMS","CD_SETOR_ENTRADA","CD_FATURA","DS_OBSERVACAO","CD_HISTORICO_PADRAO","NM_HISTORICO","CD_OPERACAO","VL_UM","FL_ESTOQUE","DT_TRANSACAO","CD_UNIDADE_ATENDIMENTO","CD_USUARIO","FL_OBRIGACAO","CD_CEDENTE_SACADO_HAP","FL_EMPRESTIMO","FL_DESCONTO","VL_IRRF","VL_ISS","VL_INSS","FL_COM_AUTORIZACAO","VL_PIS","VL_COFINS","VL_CSSL","NU_SEQ_NOTA_FOR","CD_ATENDIMENTO","FL_HEMODINAMICA","FL_CC"
 from tb_nota nt
 where not exists(select cd_nota from tb_obrigacao ob where ob.cd_nota is not null and ob.cd_nota = nt.cd_nota)  
   and nt.cd_especie_nota <> 'OC'
union all
select nt."CD_NOTA",nt."FL_NIVEL_ATUALIZACAO",nt."DT_SAIDA",nt."DT_ENTRADA",nt."CD_FILIAL",nt."CD_FORNECEDOR",nt."CD_NOTA_FORNECEDOR",nt."NM_SERIE",nt."CD_ESPECIE_NOTA",nt."CD_UM",nt."VL_TOTAL_NOTA",nt."VL_TOTAL_MATERIAL",nt."VL_BASE_ICMS",nt."PC_ICMS",nt."VL_ICMS",nt."PC_ALIQUOTA_ESTADO",nt."VL_IPI",nt."VL_DESPESAS_ACESSORIAS",nt."VL_ICMS_RETIDO",nt."VL_DIFERENCA_ICMS",nt."CD_SETOR_ENTRADA",nt."CD_FATURA",nt."DS_OBSERVACAO",nt."CD_HISTORICO_PADRAO",nt."NM_HISTORICO",nt."CD_OPERACAO",nt."VL_UM",nt."FL_ESTOQUE",nt."DT_TRANSACAO",nt."CD_UNIDADE_ATENDIMENTO",nt."CD_USUARIO",nt."FL_OBRIGACAO",nt."CD_CEDENTE_SACADO_HAP",nt."FL_EMPRESTIMO",nt."FL_DESCONTO",nt."VL_IRRF",nt."VL_ISS",nt."VL_INSS",nt."FL_COM_AUTORIZACAO",nt."VL_PIS",nt."VL_COFINS",nt."VL_CSSL",nt."NU_SEQ_NOTA_FOR",nt."CD_ATENDIMENTO",nt."FL_HEMODINAMICA",nt."FL_CC"
 from tb_nota nt,
      tb_obrigacao ob
 where nt.CD_NOTA = ob.CD_NOTA
 and nt.cd_especie_nota <> 'OC'
 and exists(select cd_nota from tb_obrigacao ob where ob.cd_nota is not null and ob.cd_nota = nt.cd_nota)  
 and not exists(Select oo.cd_obrigacao from tb_operacao_obrigacao oo where oo.cd_obrigacao = ob.CD_OBRIGACAO)
 
--create public synonym vw_notas_incompletas for humaster.vw_notas_incompletas;

--grant select on humaster.vw_notas_incompletas to RL_ADMINISTRACAO4
/

