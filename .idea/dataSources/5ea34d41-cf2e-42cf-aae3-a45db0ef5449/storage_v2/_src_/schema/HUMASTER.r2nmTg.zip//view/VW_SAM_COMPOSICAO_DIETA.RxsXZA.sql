create view VW_SAM_COMPOSICAO_DIETA as
    select cd.cd_dieta,
       cd.cd_ordem_dieta,
       cd.cd_mat_med,
       cd.cd_unidade,
       cd.qt_conteudo,
       cd.nm_composicao_dieta,
       'N' fl_somente_leite_itens_np
  from tb_composicao_dieta cd, tb_material m
 where cd.cd_mat_med = m.cd_material
   --and m.cd_classificacao in (732)
union all
select cd.cd_dieta,
       cd.cd_ordem_dieta,
       cd.cd_mat_med,
       cd.cd_unidade,
       cd.qt_conteudo,
       cd.nm_composicao_dieta,
       'S' fl_somente_leite_itens_np
  from tb_composicao_dieta cd, tb_material m
 where cd.cd_mat_med = m.cd_material
   and m.cd_classificacao in (407, 631, 732, 728)
/

