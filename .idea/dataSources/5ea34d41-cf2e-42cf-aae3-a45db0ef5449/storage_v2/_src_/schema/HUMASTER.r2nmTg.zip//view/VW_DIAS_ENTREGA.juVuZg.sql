create view VW_DIAS_ENTREGA as
    select b.cd_filial,
       b.id_filial_finpac,
       a.cd_filial cd_filial_hosp,
       a.cd_grupo_compra,
       a.qt_dias_entrega
  from tb_filial b,
       tb_filial_dias_entrega a
 where a.cd_filial=b.cd_filial
union all
select b.cd_filial,
       b.id_filial_finpac,
       a.cd_filial cd_filial_hosp,
       a.cd_grupo_compra,
       a.qt_dias_entrega
  from tb_filial@schosp b,
       tb_filial_dias_entrega@schosp a
 where a.cd_filial=b.cd_filial
/

