create view FN_LIQDC_FINANC as
select "ID_LIQDC_FINANC","COD_TIPO_LIQDC_FINANC"
     from fn_liqdc_financ@matera
/

