create view VWTESTE as
    select 2 cd_tipo,
  'REQ' cd_doc,
  nm_setor,
  tm_requisicao.cd_requisicao cd_nota,
  '' nr_fornecedor,
  cd_setor_controle,
  cd_setor_destino,
  tm_setor.cd_setor_emp cd_setor_emp,
  dt_emissao,
  cd_material,
  nvl(qt_material_c+qt_material_n,0) qt_material,
  nvl(vl_material_c,0) vl_material,
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  cd_lote,
  dt_validade_lote,
  0 nu_seq_nota
 from tm_setor,tm_requisicao,tb_item_requisicao
 where tm_requisicao.cd_requisicao=tb_item_requisicao.cd_requisicao
   and tb_item_requisicao.fl_status_item in (1,2,3)
   and tm_setor.fl_controla='S'
   and tm_setor.fl_estoque_proprio='S'
   and tm_setor.cd_setor = tm_requisicao.cd_setor_controle
   and tm_setor.cd_setor   = tm_requisicao.cd_setor_destino
union all
 select 3 cd_tipo,
  'DEV' cd_doc,
  nm_setor,
  tm_devolucao.cd_devolucao cd_nota,
  '' nm_fornecedor,
  cd_setor_controle,
  cd_setor_destino,
  tm_setor.cd_setor_emp cd_setor_emp,
  dt_emissao,
  cd_material,
  nvl(qt_material,0) qt_material,
  nvl(vl_material,0) vl_material,
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  cd_lote,
  dt_validade_lote,
  0 nu_seq_nota
 from tm_setor,tm_devolucao,tb_item_devolucao
where
  tm_devolucao.cd_setor_controle=tm_setor.cd_setor
  and tm_setor.fl_controla='S'
  and tm_setor.fl_estoque_proprio='S'
  and tm_setor.cd_setor   = tm_devolucao.cd_setor_destino
  and tb_item_devolucao.cd_devolucao = tm_devolucao.cd_devolucao
  and tb_item_devolucao.fl_status_item in (1,2,3)
/

