create view VW_ESPECIE_TITULO_HV as
select "CD_ESPECIE_TITULO","NM_ESPECIE_TITULO" from tb_especie_titulo@hapvida
/

