create view VW_EXAMES_CANCELADOS_EMG as
SELECT
   /*+ index */
    DISTINCT A.CD_UNIDADE_ATENDIMENTO ,
    p.CD_ATENDIMENTO,
    PA.NM_PACIENTE,
    to_date(TO_CHAR( p.DT_ATENDIMENTO,'dd/mm/yyyy hh24:mi') ,
    'dd/mm/yyyy hh24:mi')dt_atendimento,
    TRUNC (to_date(TO_CHAR( p.DT_ATENDIMENTO,'dd/mm/yyyy hh24:mi') ,
    'dd/mm/yyyy hh24:mi'))DT_AUX,
    P.CD_PROCEDIMENTO,
    PR.NM_PROCEDIMENTO,
    p.DS_JUSTIFICATICA_CANCELAMENTO
  FROM
    tb_exame_solicitado_sa p ,
    tm_atendimento a,
    tb_procedimento pr,
    tb_paciente pa
  WHERE
    a.cd_atendimento                                                 = p.cd_atendimento
  AND pr.cd_procedimento                                             = p.cd_procedimento
  AND a.cd_paciente                                                  = pa.cd_paciente
  AND NVL(p.DT_COLETA_CANCELADA,to_date('01/01/1700','dd/mm/yyyy')) <>to_date('01/01/1700','dd/mm/yyyy')
  AND a.DT_ATENDIMENTO         > TRUNC(SYSDATE -30)
  AND A.CD_UNIDADE_ATENDIMENTO = HUMASTER.FN_UNIDADE
  AND PR.FL_TIPO_EXAME        IN (0,1)
/

