create view VW_ACE_GRUPOS_OPERADOR as
SELECT   COD_GRUPO, NM_GRUPO, COD_USUARIO cd_operador
FROM (
SELECT /*+ LEADING(@"SEL$2" "UM"@"SEL$2" "GM"@"SEL$2" "O"@"SEL$2" "S"@"SEL$2")    */
GM.COD_GRUPO,
       GM.NM_GRUPO,
       UM.COD_USUARIO,
       O.DS_OPERADOR,
       FN_NM_SETOR_TRABALHO(UM.COD_USUARIO) SETOR,
       DECODE(O.FL_STATUS,0,'Habilitado',
                                                1,'Desab.Temp.',
                                                2,'Desabilitado',
                                                3,'Hab.Terc.',
                                                4,'Bloqueado','          ')                       FL_STATUS,
      DECODE(O.FL_AUTORIZA_DIGITAL,'S','SIM','NÃO')   AUT_DIGITAL,
      DECODE(O.FL_MULTIEMPRESA,'S','SIM','NÃO')         USU_MULTEMPRESA,
      --TRUNC(FR.DT_AUDIT)                                                        ULT_ACESSO,
      DECODE(O.CD_NIVEL_TELA,null,' ',
                              0,' ',
                              1,'Leitura',
                              2,'Leitura,inclusao',
                              3,'Leitura,inclusao,alteracao','Leitura,inclusao,alteracao,exclusao') NIVEL_ACESSO
FROM  TM_SETOR S,
            TB_OPERADOR O,
            TB_USUARIOS_MENU UM,
            TB_GRUPOS_MENU GM
WHERE   1=1
  and UM.COD_GRUPO         =     GM.COD_GRUPO
  AND O.NM_OPERADOR       =     UM.COD_USUARIO
 -- AND O.NM_OPERADOR||''    LIKE 'CBNETO'
  AND S.CD_SETOR                 =    O.CD_SETOR
union all
select distinct  /* LEADING(@"SEL$2" "O"@"SEL$2" "S"@"SEL$2" "UM"@"SEL$2" "GM"@"SEL$2") */ 0,
       'ACESSO INDIVIDUAL',
       au.cod_usuario,
       o.ds_operador,
       FN_NM_SETOR_TRABALHO(O.CD_FUNCIONARIO) nm_setor,
       DECODE(O.FL_STATUS,0,'Habilitado',
                                                1,'Desab.Temp.',
                                                2,'Desabilitado',
                                                3,'Hab.Terc.',
                                                4,'Bloqueado','          ')  FL_STATUS,
       DECODE(O.FL_AUTORIZA_DIGITAL, 'S', 'SIM', 'NÃO') AUT_DIGITAL,
       DECODE(O.FL_MULTIEMPRESA, 'S', 'SIM', 'NÃO') USU_MULTEMPRESA,
       --TRUNC(FR.DT_AUDIT) ULT_ACESSO,
       DECODE(O.CD_NIVEL_TELA,null,' ',
                              0,' ',
                              1,'Leitura',
                              2,'Leitura,inclusao',
                              3,'Leitura,inclusao,alteracao','Leitura,inclusao,alteracao,exclusao') NIVEL_ACESSO
  from tb_operador o, tm_setor s, tb_acesso_usuario au
 where 1=1
  and au.cod_usuario = o.nm_operador
   and o.cd_setor = s.cd_setor
  -- AND O.NM_OPERADOR||''    LIKE 'CBNETO'
 )
/

