create view VW_SAM_AEROSSOL_COMPL as
select ppu.cd_atendimento,
       ppu.cd_ocorrencia_plano,
       ppu.cd_ordem_prescricao,
       ppu.cd_ordem_proc_plano_uso,
       ppu.cd_proc_plano_pai,
       ppu.cd_procedimento,
       ppu.nm_procedimento,
       ppu.qt_procedimento,
       ppu.cd_unidade_usual
  from tb_procedimento_plano_uso ppu
 where ppu.cd_proc_plano_pai is not null
 and ppu.cd_unidade_usual is not null
/

