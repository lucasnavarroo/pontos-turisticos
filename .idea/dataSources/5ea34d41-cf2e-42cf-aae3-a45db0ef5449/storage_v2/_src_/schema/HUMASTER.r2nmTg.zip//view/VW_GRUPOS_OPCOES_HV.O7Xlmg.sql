create view VW_GRUPOS_OPCOES_HV as
select "COD_GRUPO","COD_OP","CD_TELA","FL_MOSTRA_MENU" from tb_grupos_opcoes@hapvida
/

