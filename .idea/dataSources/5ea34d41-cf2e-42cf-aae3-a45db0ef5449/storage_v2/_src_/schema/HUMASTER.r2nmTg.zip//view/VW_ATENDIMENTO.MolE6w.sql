create view VW_ATENDIMENTO as
select a.cd_atendimento,
       a.cd_paciente,
       p.nm_paciente,
       p.dt_nascimento,
       a.cd_tipo_atendimento,
       a.cd_motivo_atendimento,
       a.dt_atendimento,
       a.hr_atendimento,
       a.dt_fim_atendimento,
       a.hr_fim_atendimento,
       a.cd_medico_atendente,
       decode(a.cd_tipo_atendimento,5,'S',a.fl_internacao) fl_internacao,
       p.nu_cgc_cpf,
       a.cd_setor,
       p.nm_mae,
       a.rowid ri_atendimento,
       p.rowid ri_paciente,
       a.dt_canc_atend,
       p.nu_carteira_convenio,
       p.cd_sexo,
       a.dt_ent_controladoria,
       a.dt_ent_faturamento,
       p.nu_rg,
       a.cd_natureza_consulta,
       a.fl_material_exame
from tb_paciente p,
     tm_atendimento a
where p.cd_paciente = a.cd_paciente and
      a.cd_unidade_atendimento like fn_unidade
/

