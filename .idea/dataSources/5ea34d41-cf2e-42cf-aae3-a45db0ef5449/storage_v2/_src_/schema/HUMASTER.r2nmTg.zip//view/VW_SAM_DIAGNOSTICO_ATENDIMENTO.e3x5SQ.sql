create view VW_SAM_DIAGNOSTICO_ATENDIMENTO as
select da.cd_cid10,
       da.cd_atendimento,
       da.cd_ocorrencia_plano,
       da.cd_ordem_diagnostico,
       to_char(da.dt_diagnostico, 'dd/mm/yyyy') dt_diagnostico,
       fn_hora(da.hr_diagnostico) hr_diagnostico,
       td.nm_tipo_diagnostico,
       da.fl_validado,
       da.fl_confirmado
  from tb_diagnostico_atendimento da, tb_tipo_diagnostico td
 where da.cd_tipo_diagnostico = td.cd_tipo_diagnostico
order by da.DT_DIAGNOSTICO desc, da.HR_DIAGNOSTICO desc
/

