create view VW_DOCUMENTO_PRONTUARIO as
select dp.NU_DOCUMENTO_ID,
       dp.NU_DOCUMENTO_PAI,
       dp.CD_PACIENTE,
       dp.CD_TIPO_DOCUMENTO_PRONTUARIO,
       dp.CD_ORGANIZACAO_PRONTUARIO,
       dp.DT_DOCUMENTO,
       dp.LB_DOCUMENTO,
       dp.ID_GED,
       dp.DS_MIME_TYPES,
       dp.DS_STATUS ds_status_documento,
       dp.DS_OBSERVACAO,
       dp.CD_ATENDIMENTO,
       rowidtochar(dp.rowid) rowid_documento_prontuario,
       rowidtochar(pa.rowid) rowid_pendencia_assinatura,
       pa.nu_pendencia_assinatura,
       pa.nm_operador,
       pa.ds_operador,
       pa.ds_motivo_assinatura,
       pa.ds_local_assinatura,
       pa.cd_nivel,
       pa.ds_status ds_status_assinatura,
       oc.user_id,
       sk.ds_alias user_id_a1,
       p.nm_paciente
  from tb_paciente             p,
       vw_operador_certificado oc,
       tb_pendencia_assinatura pa,
       tb_documento_prontuario dp,
       tb_sign_key             sk
 where dp.nu_documento_id = pa.nu_documento_id
   and p.cd_paciente = dp.cd_paciente
   and pa.nm_operador = oc.NM_OPERADOR(+)
   and pa.nm_operador = sk.nm_operador(+)
   and nvl(sk.fl_ativo, 'S') = 'S'
   and nvl(sk.fl_tipo_profissional, 'D') = 'D'
/

