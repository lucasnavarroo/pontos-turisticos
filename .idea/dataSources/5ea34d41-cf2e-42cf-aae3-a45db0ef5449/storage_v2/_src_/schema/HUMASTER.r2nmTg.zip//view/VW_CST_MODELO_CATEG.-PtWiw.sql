create view VW_CST_MODELO_CATEG as
select a.cd_modelo                  cd_modelo,
       a.nm_modelo                  nm_modelo,
       a.cd_ocorrencia_procedimento cd_ocorrencia_procedimento,
       a.cd_procedimento            cd_procedimento,
       sum(decode(a.cd_tipo_item, 11, a.qtd_item, 0)) qtd_kit,
       sum(decode(a.cd_tipo_item, 11, a.total, 0))    vl_kit,
       sum(decode(a.cd_tipo_item, 10, a.qtd_item, 0)) qtd_opme,
       sum(decode(a.cd_tipo_item, 10, a.total, 0))    vl_opme,
       sum(decode(a.cd_tipo_item, 12, a.qtd_item, 0)) qtd_prescr,
       sum(decode(a.cd_tipo_item, 12, a.total, 0))    vl_prescr,
       sum(decode(a.cd_tipo_item, 13, a.qtd_item, 0)) qtd_lab,
       sum(decode(a.cd_tipo_item, 13, a.total, 0))    vl_lab,
       sum(decode(a.cd_tipo_item, 14, a.qtd_item, 0)) qtd_imag,
       sum(decode(a.cd_tipo_item, 14, a.total, 0))    vl_imag,
       sum(decode(a.cd_tipo_item, 10, a.total, 0)) +
       sum(decode(a.cd_tipo_item, 11, a.total, 0)) +
       sum(decode(a.cd_tipo_item, 12, a.total, 0)) +
       sum(decode(a.cd_tipo_item, 13, a.total, 0)) +
       sum(decode(a.cd_tipo_item, 14, a.total, 0))    vl_total
  from vw_itens_modelo a
 where 1 = 1
 group by a.cd_modelo,
          a.nm_modelo,
          a.cd_ocorrencia_procedimento,
          a.cd_procedimento
/

