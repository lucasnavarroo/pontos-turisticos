create view VW_DATA_CHECK_RESULTADO as
select dcr.cd_atendimento,
                 dcr.cd_ocorrencia,
                 dcr.cd_ordem,
                 dcr.cd_ref,
                 pr.ds_parametro_referencia,
                 dcr.ds_resultado_procedimento,
                 dcr.dt_check,
                 (case when ppr.cd_sexo = 'A'
                  then 'AMBOS'
             when ppr.cd_sexo = 'M'
                  then 'MASCULINO'
             when ppr.cd_sexo = 'F'
                  then 'FEMININO'
             else '' end) cd_sexo,
       (case when ppr.fl_unidade_tempo = 'D'
                  then ppr.qt_idade_inicial
             when ppr.fl_unidade_tempo = 'M'
                  then trunc(ppr.qt_idade_inicial/30)
             when ppr.fl_unidade_tempo = 'A'
                  then trunc(ppr.qt_idade_inicial/365)
             else null end) qt_idade_inicial,
       (case when ppr.fl_unidade_tempo = 'D'
                  then ppr.qt_idade_final
             when ppr.fl_unidade_tempo = 'M'
                  then trunc(ppr.qt_idade_final/30)
             when ppr.fl_unidade_tempo = 'A'
                  then trunc(ppr.qt_idade_final/365)
             else null end) qt_idade_final,
                  decode(ppr.fl_tipo_valor,'T',(select ptr.ds_texto_resultado
                                                      from tb_proc_texto_resultado ptr
                                                     where ptr.cd_procedimento =
                                                           ppr.cd_procedimento
                                                       and ptr.cd_metodo_realizado =
                                                           ppr.cd_metodo_realizado
                                                       and ptr.cd_ordem =
                                                           ppr.cd_ordem
                                                       and ptr.cd_parametro_referencia =
                                                           ppr.cd_parametro_referencia
                                                       and ptr.cd_ref =
                                                           ppr.cd_ref
                                                       and ptr.fl_referencia = 'S'
                                                       and rownum = 1),decode(ppr.vl_parametro_normal,null,ppr.vl_parametro_minimo,ppr.vl_parametro_normal)) vl_parametro_normal,
                 ppr.vl_parametro_maximo,
                 decode(ppr.cd_referencia,'I','=','D','<>','M','>=','W','<=','E','INTERVALO') cd_referencia
          from tb_data_check_resultado dcr,
               tb_parametro_referencia pr,
               tb_proced_param_referencia ppr
         where dcr.cd_ref = ppr.cd_ref
            and dcr.cd_proced_param_referencia = ppr.cd_proced_param_referencia
            and pr.cd_parametro_referencia = ppr.cd_parametro_referencia
/

