create view VW_STATUS_OBRIGACAO_HV as
select "CD_STATUS_OBRIGACAO","DS_STATUS" from tb_status_obrigacao@hapvida
/

