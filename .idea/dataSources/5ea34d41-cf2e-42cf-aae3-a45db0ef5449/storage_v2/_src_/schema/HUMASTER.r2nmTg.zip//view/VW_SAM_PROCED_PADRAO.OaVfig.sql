create view VW_SAM_PROCED_PADRAO as
select cd_modelo, cd_ordem_proc_plano_uso, cd_procedimento, ds_observacao
  from TB_PROCED_PLANO_USO_MODELO
/

