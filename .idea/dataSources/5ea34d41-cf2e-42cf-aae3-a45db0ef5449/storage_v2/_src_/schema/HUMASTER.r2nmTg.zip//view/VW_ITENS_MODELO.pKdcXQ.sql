create view VW_ITENS_MODELO as
    select a.cd_modelo                  cd_modelo,
       ac.ds_modelo                 nm_modelo,
       a.cd_ocorrencia_procedimento cd_ocorrencia_procedimento,
       a.cd_procedimento            cd_procedimento,
       ab.nm_procedimento           nm_procedimento,
       aab.cd_grupo_prod_proc       cd_tipo_item,
       aab.nm_grupo_prod_proc       nm_tipo_item,
       to_char(aa.cd_material)      cd_item,
       aaa.nm_material              nm_item,
       aaa.cd_unidade_usual         cd_um,
       aa.qt_item                   qtd_item,
       humaster.fn_custo_unit_item(aa.cd_material) prc_unit,
       humaster.fn_custo_unit_item(aa.cd_material) * aa.qt_item total,
       aa.dt_ini_vigencia,
       aa.dt_fin_vigencia
  from          tb_modelo_plano_tratamento  ac,
                tb_procedimento             ab,
                   tb_grupo_prod_proc       aab,
                   tb_material              aaa,
                tb_procedimento_modelo_item aa,
             tb_procedimento_modelo         a
 where 1 = 1
    -- filtros
   and a.fl_status = 1
   and ac.fl_tipo_modelo = 1
   and aa.cd_tipo_item in (10, 11, 12)
    -- join a -< aa
   and a.cd_modelo = aa.cd_modelo
   and a.cd_ocorrencia_procedimento = aa.cd_ocorrencia_procedimento
    -- join aa -- aaa
   and aa.cd_material = aaa.cd_material
    -- join aa -- aab
   and aa.cd_tipo_item = aab.cd_grupo_prod_proc
    -- join a -- ab
   and a.cd_procedimento = ab.cd_procedimento
    -- join a -- ac
   and a.cd_modelo = ac.cd_modelo
union all
/* Exames do modelo */
select a.cd_modelo                  cd_modelo,
       ac.ds_modelo                 nm_modelo,
       a.cd_ocorrencia_procedimento cd_ocorrencia_procedimento,
       a.cd_procedimento            cd_procedimento,
       ab.nm_procedimento           nm_procedimento,
       aab.cd_grupo_prod_proc       cd_tipo_item,
       aab.nm_grupo_prod_proc       nm_tipo_item,
       to_char(aa.cd_exame)         cd_item,
       aaa.nm_procedimento          nm_item,
       ' '                          cd_um,
       aa.qt_item                   qtd_item,
       humaster.fn_custo_unit_procedimento(aa.cd_exame) prc_unit,
       aa.qt_item * humaster.fn_custo_unit_procedimento(aa.cd_exame) total,
       aa.dt_ini_vigencia,
       aa.dt_fin_vigencia
  from          tb_modelo_plano_tratamento  ac,
                tb_procedimento             ab,
                   tb_grupo_prod_proc       aab,
                   tb_procedimento          aaa,
                tb_procedimento_modelo_item aa,
             tb_procedimento_modelo         a
 where 1 = 1
    -- filtros
   and a.fl_status = 1
   and aa.cd_tipo_item in (13, 14)
   and aaa.fl_tipo_exame in (0, 1, 2)
   and ac.fl_tipo_modelo = 1
    -- join a -< aa
   and a.cd_modelo = aa.cd_modelo
   and a.cd_ocorrencia_procedimento = aa.cd_ocorrencia_procedimento
    -- join aa -- aaa
   and aa.cd_exame = aaa.cd_procedimento
    -- join aa -- aab
   and aa.cd_tipo_item = aab.cd_grupo_prod_proc
    -- join a -- ab
   and a.cd_procedimento = ab.cd_procedimento
    -- join a -- ac
   and a.cd_modelo = ac.cd_modelo
/

