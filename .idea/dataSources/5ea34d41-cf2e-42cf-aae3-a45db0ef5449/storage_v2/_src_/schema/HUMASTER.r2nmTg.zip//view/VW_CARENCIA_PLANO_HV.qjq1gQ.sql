create view VW_CARENCIA_PLANO_HV as
select "CD_PLANO","CD_CARENCIA","QT_DIAS","QT_DIAS_ATRASO","QT_DIAS_ACRESCIMO","FL_COMPRA_CARENCIA" from tb_carencia_plano@hapvida
/

