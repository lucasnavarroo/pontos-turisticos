create view VW_SAM_ARQUETIPO as
select er.ds_texto,
       er.ds_texto_livre,
       er.ds_data,
       er.ds_numero,
       er.ds_lista,
       er.ds_check,
       er.fl_tipo_atributo,
       er.fl_tipo_valor,
       er.id_componente,
       e.nu_evolucao,
       e.cd_atendimento
  from tb_evolucao           e,
       tb_evolucao_resultado er
 where er.cd_atendimento = e.cd_atendimento
   and er.cd_ocorrencia_plano = e.cd_ocorrencia_plano
   and er.cd_ordem = e.cd_ordem
/

