create view VW_AMOSTRA_RASTREAMENTO as
select lr.cd_lote,
       sa.nm_setor          setor_saida,
       ar.dt_amostra_coleta data_saida,
       ar.cd_amostra_coleta,
       ar.cd_tubo_coleta,
       se.nm_setor          setor_chegada,
       ar.dt_amostra_lab    data_chegada,
       ar.cd_amostra_lab,
       ar.fl_status,
       ae.nu_pedido,
       ae.dt_pedido,
       ae.cd_atendimento,
       p.nm_paciente,
       lr.cd_empresa_rast,
       er.nm_empresa,
       lr.cd_funcionario,
       lr.nm_funcionario,
       lr.cd_oper_entrega,
       o.ds_operador
  from tb_empresa_rast  er,
       tb_operador      o,
       tm_setor         se,
       tm_setor         sa,
       tb_paciente      p,
       tm_atendimento   a,
       tb_amostra_exame ae,
       tb_amostra_rast  ar,
       tb_lote_rast     lr
 where lr.cd_setor_coleta = sa.cd_setor
   and lr.cd_lote = ar.cd_lote
   and lr.cd_setor_recebe = se.cd_setor(+)
   and ar.cd_amostra_coleta = ae.cd_amostra
   and ae.cd_atendimento = a.cd_atendimento
   and a.cd_paciente = p.cd_paciente
   and lr.cd_empresa_rast = er.cd_empresa_rast(+)
   and lr.cd_oper_entrega = o.nm_operador
/

