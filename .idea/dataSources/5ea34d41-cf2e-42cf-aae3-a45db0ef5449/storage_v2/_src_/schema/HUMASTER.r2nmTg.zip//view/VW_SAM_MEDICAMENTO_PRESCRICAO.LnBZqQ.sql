create view VW_SAM_MEDICAMENTO_PRESCRICAO as
SELECT DISTINCT d.nu_produto,
                a.cd_material,
                A.NM_MATERIAL,
                A.CD_APRESENTACAO,
                A.QT_DOSAGEM,
                A.CD_UNIDADE_DOSAGEM,
                DECODE(A.CD_UNIDADE_CONTEUDO_DOSE,
                       NULL,
                       '',
                       '/' || TO_CHAR(A.QT_CONTEUDO_DOSAGEM) ||
                       A.CD_UNIDADE_CONTEUDO_DOSE) DOSE,
                case
                  when A.CD_APRESENTACAO = '-' then
                   null
                  else
                   A.QT_CONTEUDO
                end as QT_CONTEUDO,
                DECODE(A.CD_UNIDADE_CONTEUDO_DOSE,
                       NULL,
                       NVL(A.QT_DOSAGEM, 1) /
                       decode(trunc(nvl(a.qt_conteudo, 1)),
                              0,
                              1,
                              NVL(A.QT_CONTEUDO, 1)),
                       NVL(A.QT_DOSAGEM, 1) / A.QT_CONTEUDO_DOSAGEM) QT_DOSAGEM_MED,
                --A.CD_UNIDADE_USUAL,
                DECODE(A.CD_APRESENTACAO,
                       '-',
                       DECODE(A.CD_UNIDADE_USUAL,
                              'GR',
                              NULL,
                              A.CD_UNIDADE_USUAL),
                       DECODE(A.CD_APRESENTACAO,
                              'TUBO',
                              'ML',
                              DECODE(A.CD_UNIDADE_DOSAGEM,
                                     '%',
                                     A.CD_UNIDADE_USUAL,
                                     DECODE(NVL(A.CD_UNIDADE_DOSAGEM, 'X'),
                                            'X',
                                            A.CD_UNIDADE_USUAL,
                                            A.CD_UNIDADE_DOSAGEM)))) CD_UNIDADE_USUAL /*,
                MP.CD_FILIAL,
                MP.FL_PADRONIZADO*/
  FROM TB_MATERIAL A, TB_PRODUTO_MAT_MED C, TB_PRODUTO D /*,
       tb_material_padronizado mp*/
 WHERE D.NU_PRODUTO = C.NU_PRODUTO
   AND C.CD_MAT_MED = A.CD_MATERIAL
      /*AND A.CD_MATERIAL = MP.CD_MATERIAL(+)*/
   AND PK_PRESCRICAO.FN_CHECK_MATERIAL(A.CD_MATERIAL) = 'S'
/

