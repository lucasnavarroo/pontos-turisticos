create view VW_SAM_HIST_EXAMES as
select p.nm_procedimento,
           g.cd_atendimento,
           g.cd_ocorrencia cd_ocorrencia_guia,
           g.nu_guia,
           p.cd_procedimento || ';' || g.cd_atendimento || ';' ||
           g.cd_ocorrencia_pedido || ';' cd_chave,
           pk_pepsam_util.fn_encrypt(p.cd_procedimento || ';' || g.cd_atendimento || ';' ||
           g.cd_ocorrencia_pedido || ';') cd_chave_url,
           p.cd_procedimento
      from tb_procedimento_realizado pr, tb_guia g, tb_procedimento p
     where p.cd_procedimento = pr.cd_procedimento
       and g.cd_atendimento = pr.cd_atendimento
       and g.cd_ocorrencia = pr.cd_ocorrencia
       and g.cd_ocorrencia_pedido is not null
/

