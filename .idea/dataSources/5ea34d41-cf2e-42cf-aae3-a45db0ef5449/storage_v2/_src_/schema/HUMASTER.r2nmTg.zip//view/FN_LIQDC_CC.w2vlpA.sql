create view FN_LIQDC_CC as
select "ID_LIQDC_CC","ID_CC","ID_LOTE_INTEGRACAO","ID_LANC_INTEGRACAO"
     from fn_liqdc_cc@matera
/

