create view VW_PROCEDIMENTO_NR as
select nr_procedimento,
	rpad(nr_procedimento,46,' ')||cd_procedimento ds_procedimento
from tb_procedimento
/

