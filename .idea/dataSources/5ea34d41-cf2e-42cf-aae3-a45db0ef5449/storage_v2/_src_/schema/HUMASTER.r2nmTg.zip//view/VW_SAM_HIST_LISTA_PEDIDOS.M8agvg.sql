create view VW_SAM_HIST_LISTA_PEDIDOS as
select
 ta.nm_tipo_atendimento,
 to_char(pe.dt_pedido, 'dd/mm/yyyy') dt_mov,
 pe.cd_atendimento,
 pe.cd_ocorrencia,
 g.cd_ocorrencia cd_ocorrencia_guia,
 g.nu_guia,
 to_char(pe.nu_pedido) cd_doc,
 pe.nm_operador,
 pe.cd_ocorrencia_ocupacao,
 pe.cd_tipo_exame,
 pe.cd_tipo_entrega,
 pa.cd_paciente,
 pa.nm_paciente,
 cp.cd_convenio_base cd_convenio,
 a.cd_setor,
 to_char(a.dt_fim_atendimento, 'dd/mm/yyyy') dt_fim_atendimento,
 pes.nm_fantasia nm_pessoa
  from tb_tipo_atendimento ta,
       tb_paciente         pa,
       tb_convenio_pagador cp,
       tb_guia             g,
       tm_atendimento      a,
       tb_pedido_exame     pe,
       tb_pessoa           pes
 where pe.cd_atendimento = a.cd_atendimento
   and g.cd_atendimento = a.cd_atendimento
   and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and cp.cd_atendimento = a.cd_atendimento
   and g.cd_pessoa_realiza = pes.cd_pessoa(+)
   and cp.cd_convenio_pagador = 1
   and pa.cd_paciente = a.cd_paciente
   and ta.cd_tipo_atendimento = a.cd_tipo_atendimento
 order by pe.dt_pedido desc
/

