create view VW_ESPERA_ATENDIMENTO as
SELECT A.CD_SETOR,TS.NM_SETOR,A.CD_ATENDIMENTO,TO_CHAR(A.DT_ATENDIMENTO,'dd/mm/yyyy' )||' '||
           FN_HORA( A.HR_ATENDIMENTO) DATA_ATENDIMENTO, PA.NU_CARTEIRA_CONVENIO,
           PA.NM_PACIENTE,
           SA.CD_SENHA_ATENDIMENTO,
           TO_DATE(TO_CHAR(SA.DT_FIM_CADASTRO, 'dd/mm/yyyy hh24:mi'),
                   'dd/mm/yyyy hh24:mi') DT_FIM_CADASTRO,
           (TRUNC((SYSDATE - SA.DT_FIM_CADASTRO) * 24) * 60 +
           ROUND((((SYSDATE - SA.DT_FIM_CADASTRO) * 24) -
                  (TRUNC((SYSDATE - SA.DT_FIM_CADASTRO) * 24))) * 60)) TOTAL_MINUTOS,
                  sa.dt_geracao_senha
      FROM TB_EMPRESA_ORGANIZACAO  E,
           TB_UNIDADE_ATENDIMENTO  U,
           TM_ATENDIMENTO          A,
           TB_SENHA_ATENDIMENTO_SA SA,
           TB_PACIENTE               PA,
           TM_SETOR                  TS
     WHERE A.CD_ATENDIMENTO = SA.CD_ATENDIMENTO
       AND A.CD_TIPO_ATENDIMENTO NOT IN (0, 5, 7, 8, 10)
       AND SA.FL_STATUS IN (2)
       and dt_geracao_senha >= trunc(sysdate) - 1
       AND U.CD_UNIDADE_ATENDIMENTO = A.CD_UNIDADE_ATENDIMENTO
       AND E.CD_PESSOA = U.CD_PESSOA_COBRA
       AND A.DT_CANC_ATEND IS NULL
       AND E.FL_TIPO_EMPRESA = 'H'
       AND A.CD_PACIENTE = PA.CD_PACIENTE
       AND A.CD_SETOR = TS.CD_SETOR
/

