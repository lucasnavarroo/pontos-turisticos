create view VW_AGENCIA_BANCARIA as
select  tb_pessoa.cd_pessoa,
   tb_pessoa.nu_cgc_cpf,
   tb_pessoa.nm_pessoa_razao_social,
   tb_pessoa.nm_fantasia,
   tb_endereco_pessoa.nu_endereco,
   tb_endereco_pessoa.cd_cep_endereco,
   tb_endereco_pessoa.nm_cidade_endereco,
   tb_endereco_pessoa.cd_uf_endereco,
   tb_endereco_pessoa.cd_tipo_logradouro,
   tb_endereco_pessoa.nm_rua_endereco,
   tb_endereco_pessoa.nm_bairro_endereco,
   tb_endereco_pessoa.ds_compl_enderero,
   tb_agencia_bancaria.cd_banco,
   tb_agencia_bancaria.cd_agencia,
   tb_agencia_bancaria.nu_dv_agencia,
   tb_agencia_bancaria.nm_agencia
from tb_agencia_bancaria,tb_endereco_pessoa,tb_pessoa
where   tb_pessoa.fl_tipo_pessoa=2 and
   tb_endereco_pessoa.cd_pessoa=tb_pessoa.cd_pessoa and
   tb_endereco_pessoa.fl_tipo_endereco=2 and
   tb_agencia_bancaria.cd_pessoa=tb_pessoa.cd_pessoa
/

