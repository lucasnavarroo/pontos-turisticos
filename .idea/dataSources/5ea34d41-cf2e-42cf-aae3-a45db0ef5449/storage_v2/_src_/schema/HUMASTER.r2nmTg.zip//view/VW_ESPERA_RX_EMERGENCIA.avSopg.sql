create view VW_ESPERA_RX_EMERGENCIA as
SELECT     A.CD_ATENDIMENTO,
                 PA.NU_CARTEIRA_CONVENIO,
                 PA.NM_PACIENTE,
                 to_date (to_char (A.DT_ATENDIMENTO,'dd/mm/yyyy') || ' ' || FN_HORA(A.HR_ATENDIMENTO),'dd/mm/yyyy hh24:mi:ss') DT_ATENDIMENTO,
                 PE.NU_PEDIDO,
                 to_date (to_char ( PE.DT_PEDIDO,'dd/mm/yyyy') || ' ' || FN_HORA(PE.HR_PEDIDO),'dd/mm/yyyy hh24:mi:ss')  DT_PEDIDO,
                 P.CD_PROCEDIMENTO,
                 P.NM_PROCEDIMENTO,
                 PR.CD_SETOR,
                 TO_DATE(TO_CHAR(PR.DT_PROCEDIMENTO_REALIZADO, 'ddmmyyyy') || ' ' ||
                         SUBSTR(FN_HORA(PR.HR_PROCEDIMENTO_REALIZADO), 1, 2) ||
                         SUBSTR(FN_HORA(PR.HR_PROCEDIMENTO_REALIZADO), 4, 2),
                         'dd/mm/yyyy hh24:mi:ss') DT_PROC_REALIZADO,
               ROUND((SYSDATE -
                 TO_DATE(TO_CHAR(PR.DT_PROCEDIMENTO_REALIZADO, 'ddmmyyyy') || ' ' ||
                          SUBSTR(FN_HORA(PR.HR_PROCEDIMENTO_REALIZADO), 1, 2) ||
                          SUBSTR(FN_HORA(PR.HR_PROCEDIMENTO_REALIZADO), 4, 2),
                          'dd/mm/yyyy hh24:mi:ss')) * 1440,1) TOTAL_MINUTOS,
                          to_date (to_char ( PR.DT_PROCEDIMENTO_REALIZADO,'dd/mm/yyyy') ) DT_PROCEDIMENTO_REALIZADO
      FROM TB_PESSOA                 PRE,
           TB_ITEM_GRUPO_PRODUTO     IGP,
           TB_PROCEDIMENTO           P,
           TB_PROCEDIMENTO_REALIZADO PR,
           TM_ATENDIMENTO            A,
           TB_GUIA                   G,
           TB_PEDIDO_EXAME           PE,
           TB_PACIENTE               PA
     WHERE P.FL_TIPO_EXAME = '2' -- exames de imagem
       AND PR.DT_LIBERA_LAUDO IS NULL
       AND NVL(PR.FL_STATUS_LAUDO, '0') != '3' -- laudos liberados
       AND A.CD_MOTIVO_ATENDIMENTO = '1' -- urgencia
       AND IGP.CD_GRUPO_PRODUTO = '503'
       AND G.CD_ATENDIMENTO = PE.CD_ATENDIMENTO
       AND G.CD_OCORRENCIA_PEDIDO = PE.CD_OCORRENCIA
       AND PR.CD_ATENDIMENTO = G.CD_ATENDIMENTO
       AND PR.CD_OCORRENCIA = G.CD_OCORRENCIA
       AND P.CD_PROCEDIMENTO = PR.CD_PROCEDIMENTO
       AND P.CD_PROCEDIMENTO = IGP.CD_PRODUTO
       AND G.CD_PESSOA_REALIZA = PRE.CD_PESSOA
       AND A.CD_ATENDIMENTO = PR.CD_ATENDIMENTO
       AND A.CD_PACIENTE = PA.CD_PACIENTE
/

