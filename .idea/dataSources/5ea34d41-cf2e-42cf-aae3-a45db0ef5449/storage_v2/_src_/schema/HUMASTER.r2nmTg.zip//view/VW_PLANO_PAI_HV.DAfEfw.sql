create view VW_PLANO_PAI_HV as
select "CD_PLANO_PAI","NM_PLANO_PAI","CD_TIPO_REDE_ATENDIMENTO" from tb_plano_pai@hapvida
/

