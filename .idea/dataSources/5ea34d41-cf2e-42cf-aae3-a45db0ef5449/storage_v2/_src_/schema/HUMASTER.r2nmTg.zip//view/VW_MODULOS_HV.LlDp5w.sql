create view VW_MODULOS_HV as
select "CD_MODULO","DS_MODULO" from tb_modulos@hapvida
/

