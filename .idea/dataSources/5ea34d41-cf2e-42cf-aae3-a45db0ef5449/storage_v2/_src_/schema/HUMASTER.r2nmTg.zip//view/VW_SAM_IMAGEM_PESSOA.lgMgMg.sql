create view VW_SAM_IMAGEM_PESSOA as
select ip.im_pessoa, ip.cd_paciente
    from tb_imagem_pessoa ip
   where ip.cd_tipo_imagem_pessoa = 2
/

