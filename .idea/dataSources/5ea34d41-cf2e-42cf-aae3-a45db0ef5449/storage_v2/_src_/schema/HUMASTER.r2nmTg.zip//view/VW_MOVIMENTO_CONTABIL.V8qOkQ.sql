create view VW_MOVIMENTO_CONTABIL as
select f.cd_filial                 ,
        f.cd_empresa_organizacao    ,
        ot.cd_operacao              ,                    -- cta.do financeira(classificacao)
        ot.dt_lancamento            ,                    -- date da transacao/movimento
        cc.cd_tipo_conta_corrente   ,                    -- 1-caixa, 2-bco.mov, 3-bco.aplic, 4-bco.poupe
        c.cd_classe_tipo_operacao   ,                    -- 11-recebimento 12-pagamento 13-tranferencia
        decode(sign(mt.vl_transacao),
               -1,cc.cd_contra_partida_ctb,
               o.cd_conta_contabil) cd_conta_contabil,   -- conta para o sist. de contabilidade
        decode(sign(mt.vl_transacao),
               -1,o.cd_conta_contabil,
               nvl(cc.cd_contra_partida_ctb,'52')) contra_partida,
        c.fl_natureza               ,                    -- R-receita D-despesa T-tranferencia
        mc.cd_movimento_conta       ,                    -- numero documento
        mc.cd_conta_corrente_debito,
        mc.cd_conta_corrente_credito,
        mt.fl_financeiro            ,                    -- C-contabilizar
        mt.fl_lancamento            ,                    -- D-debito C-credito
        mc.vl_movimento             ,
	abs(ot.vl_transacao*
            ot.vl_rateio/100) vl_rateio,                 -- o valor rateio e percentual
	abs(ot.vl_transacao) vl_transacao,
	nvl(mt.cd_historico_padrao,
            000) cd_historico_padrao,
	mt.nm_historico
   from tb_historico_padrao h,
        tb_filial f,
	tb_classe_tipo_operacao c,
	tb_tipo_operacao t,
	tb_nivel_operacao n,
	tb_operacao o,
	tb_conta_corrente cc,
	tb_movimento_conta mc,
	tb_movimento_transacao mt,
	tb_operacao_transacao ot
   where mt.cd_movimento_conta = ot.cd_movimento_conta
     and mt.cd_ordem_transacao = ot.cd_ordem_transacao
     and mc.cd_movimento_conta = mt.cd_movimento_conta
     and trunc(mc.dt_estorno) is null
     and cc.cd_conta_bancaria  =
	 nvl(mc.cd_conta_corrente_debito,mc.cd_conta_corrente_credito)
     and o.cd_operacao = trunc(ot.cd_operacao)
     and o.cd_conta_contabil is not null
     and n.cd_nivel_operacao = o.cd_nivel_operacao
     and n.cd_tipo_operacao = o.cd_tipo_operacao
     and t.cd_tipo_operacao = n.cd_tipo_operacao
     and c.cd_classe_tipo_operacao = trunc(t.cd_classe_tipo_operacao)
     and f.cd_filial = cc.cd_filial
     and h.cd_historico_padrao(+)  = trunc(mt.cd_historico_padrao)
/

