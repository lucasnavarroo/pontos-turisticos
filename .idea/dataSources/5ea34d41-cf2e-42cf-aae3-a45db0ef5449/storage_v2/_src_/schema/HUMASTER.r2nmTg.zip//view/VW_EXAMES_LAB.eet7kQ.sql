create view VW_EXAMES_LAB as
select PR.CD_ATENDIMENTO, PR.CD_OCORRENCIA, PR.CD_ORDEM, PR.DT_PROCEDIMENTO_REALIZADO, PR.HR_PROCEDIMENTO_REALIZADO,
       (to_char(pr.dt_procedimento_realizado,'dd/mm/yy') || ' ' || fn_hora(pr.hr_procedimento_realizado)) DT_EXAME, P.NM_PROCEDIMENTO,
       pr.cd_procedimento,1 cd_ordem_apresentacao
from humaster.tb_procedimento_realizado pr,
     humaster.tb_procedimento p
where pr.dt_libera_laudo is not null
  and p.fl_tipo_exame       in (0,1)
  and p.fl_cirurgia          = 2
  and p.cd_procedimento      = pr.cd_procedimento
/

