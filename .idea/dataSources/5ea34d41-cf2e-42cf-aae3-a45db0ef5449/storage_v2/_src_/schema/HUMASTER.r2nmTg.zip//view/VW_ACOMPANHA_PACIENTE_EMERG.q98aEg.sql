create view VW_ACOMPANHA_PACIENTE_EMERG as
select distinct
       aaa.nu_pedido,
       aaa.dt_pedido,
       aba.nm_paciente,
       ab.cd_unidade_atendimento,
       a.dt_procedimento_realizado,
       decode(ac.cd_ordem, null, 'N',
                                 'S') fl_recoleta,
       decode(count(*) - count(ada.cd_amostra_coleta), 0, 'C',
                                                          'I') FL_ENTREGA,
       --FASE 1
       fn_hora_m(nvl((nvl(max(ada.dt_amostra_coleta), sysdate) -
                     (CASE WHEN max(af.dt_atendimento) = TRUNC(max(af.dt_atendimento)) THEN to_date(to_char(max(a.dt_procedimento_realizado), 'DD/MM/YYYY') || ' ' || fn_hora(max(a.hr_procedimento_realizado)), 'DD/MM/YYYY HH24:MI')
                                                                                       ELSE max(af.dt_atendimento) END)
                     ) * 24 * 60 * 60, 0)) fase_1,
       --FASE 1 EM SEGUNDOS
       nvl((nvl(max(ada.dt_amostra_coleta), sysdate) -
                     (CASE WHEN max(af.dt_atendimento) = TRUNC(max(af.dt_atendimento)) THEN to_date(to_char(max(a.dt_procedimento_realizado), 'DD/MM/YYYY') || ' ' || fn_hora(max(a.hr_procedimento_realizado)), 'DD/MM/YYYY HH24:MI')
                                                                                       ELSE max(af.dt_atendimento) END)
                     ) * 24 * 60 * 60, 0) atraso_fase_1,
       --FASE 2
       fn_hora_m(nvl((nvl(max(ada.dt_amostra_lab), sysdate) - max(ada.dt_amostra_coleta)) * 24 * 60 * 60, 0)) fase_2,
       --FASE 2 EM SEGUNDOS
       nvl((nvl(max(ada.dt_amostra_lab), sysdate) - max(ada.dt_amostra_coleta)) * 24 * 60 * 60, 0) atraso_fase_2,
       --FASE 3
       fn_hora_m(nvl((nvl(max(a.dt_libera_laudo), sysdate) - max(ada.dt_amostra_lab)) * 24 * 60 * 60, 0)) fase_3,
       --FASE 3 EM SEGUNDOS
       nvl((nvl(max(a.dt_libera_laudo), sysdate) - max(ada.dt_amostra_lab)) * 24 * 60 * 60, 0) atraso_fase_3,
       --FASE TOTAL
       fn_hora_m(nvl(nvl((nvl(max(ada.dt_amostra_coleta), sysdate) -
                     (CASE WHEN max(af.dt_atendimento) = TRUNC(max(af.dt_atendimento)) THEN to_date(to_char(max(a.dt_procedimento_realizado), 'DD/MM/YYYY') || ' ' || fn_hora(max(a.hr_procedimento_realizado)), 'DD/MM/YYYY HH24:MI')
                                                                                       ELSE max(af.dt_atendimento) END)
                     ) * 24 * 60 * 60, 0) +
                     nvl((nvl(max(ada.dt_amostra_lab), sysdate) - max(ada.dt_amostra_coleta)) * 24 * 60 * 60, 0) +
                     nvl((nvl(max(a.dt_libera_laudo), sysdate) - max(ada.dt_amostra_lab)) * 24 * 60 * 60, 0)
                     , 0)
                ) fase_total,
       --FASE TOTAL EM SEGUNDOS
       (nvl((nvl(max(ada.dt_amostra_coleta), sysdate) -
                     (CASE WHEN max(af.dt_atendimento) = TRUNC(max(af.dt_atendimento)) THEN to_date(to_char(max(a.dt_procedimento_realizado), 'DD/MM/YYYY') || ' ' || fn_hora(max(a.hr_procedimento_realizado)), 'DD/MM/YYYY HH24:MI')
                                                                                       ELSE max(af.dt_atendimento) END)
                     ) * 24 * 60 * 60, 0) +
        nvl((nvl(max(ada.dt_amostra_lab), sysdate) - max(ada.dt_amostra_coleta)) * 24 * 60 * 60, 0) +
        nvl((nvl(max(a.dt_libera_laudo), sysdate) - max(ada.dt_amostra_lab)) * 24 * 60 * 60, 0)
       ) fase_total_qtd
  from    tb_exame_solicitado_sa    af,
          tb_procedimento           ae,
             tb_amostra_rast        ada,
          tb_amostra_exame          ad,
          tb_procedimento_repeticao ac,
             tb_paciente            aba,
          tm_atendimento            ab,
             tb_pedido_exame        aaa,
          tb_guia                   aa,
       tb_procedimento_realizado    a
 where 1 = 1
   --- Filtros
   and a.dt_procedimento_realizado between trunc(sysdate) - 0
                                   and trunc(sysdate) - 0
   and a.dt_libera_laudo is null
   and ab.cd_motivo_atendimento = 1
   and ab.cd_tipo_atendimento + 0 in (2, 3, 4, 6, 9)
   and ab.fl_internacao || '' = 'N'
   and ae.fl_tipo_exame in (0, 1)
   and ae.fl_cirurgia + 0 = 2
   and nvl(af.fl_exame_cancelado, 'N') = 'N'
   --- Joins
   --- aa -- a
   and aa.cd_atendimento = a.cd_atendimento
   and aa.cd_ocorrencia = a.cd_ocorrencia
   --- aaa -- aa
   and aaa.cd_atendimento = aa.cd_atendimento
   and aaa.cd_ocorrencia = aa.cd_ocorrencia_pedido
   --- ab -- a
   and ab.cd_atendimento = a.cd_atendimento
   --- aba -- ab
   and aba.cd_paciente = ab.cd_paciente
   --- ac -- a
   and ac.cd_atendimento(+) = a.cd_atendimento
   and ac.cd_ocorrencia(+) = a.cd_ocorrencia
   and ac.cd_ordem(+) = a.cd_ordem
   --- ad -- a
   and ad.cd_amostra(+) = a.cd_amostra
   --- ada -- ad
   and ada.cd_amostra_coleta(+) = ad.cd_amostra
   --- ae -- a
   and ae.cd_procedimento = a.cd_procedimento
   --- af -- aaa
   and af.cd_atendimento = aaa.cd_atendimento
   and af.nu_pedido = aaa.nu_pedido
   and af.dt_pedido = aaa.dt_pedido
 group by aaa.nu_pedido,
          aaa.dt_pedido,
          aba.nm_paciente,
          ab.cd_unidade_atendimento,
          a.dt_procedimento_realizado,
          decode(ac.cd_ordem, null, 'N',
                                    'S')
 order by 15 desc
/

