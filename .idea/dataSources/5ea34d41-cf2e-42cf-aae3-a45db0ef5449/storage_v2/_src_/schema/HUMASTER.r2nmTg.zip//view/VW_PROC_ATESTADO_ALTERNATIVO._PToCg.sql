create view VW_PROC_ATESTADO_ALTERNATIVO as
select pr.cd_atendimento
       ,pr.cd_procedimento
       ,p.nr_procedimento
       ,pr.dt_procedimento_realizado
       ,fn_hora(pr.hr_procedimento_realizado) hr_procedimento_realizado
from  tb_procedimento p,
      tb_procedimento_realizado pr
where p.cd_procedimento = pr.cd_procedimento
and p.fl_atestado_alternativo = 'S'
/

