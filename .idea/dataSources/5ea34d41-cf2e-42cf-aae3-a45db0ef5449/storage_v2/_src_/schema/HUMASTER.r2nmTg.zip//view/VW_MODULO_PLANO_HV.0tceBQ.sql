create view VW_MODULO_PLANO_HV as
select "CD_PLANO","CD_MODULO" from tb_modulo_plano@hapvida
/

