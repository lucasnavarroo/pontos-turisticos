create view VW_USUARIOS_S as
select
-- tb_pessoa u (retorna dados em tb_pessoa p/usuario/dependente)
	u.cd_pessoa,
	u.dt_nascimento_fundacao dt_nascimento_fundacao_u,
	u.nm_pessoa_razao_social nm_pessoa_razao_social_u,
	u.fl_sexo fl_sexo_u,
	u.fl_tipo_pessoa fl_tipo_pessoa_u,
-- tb_pessoa t (retorna dados em tb_pessoa do titular)
	t.cd_pessoa cd_pessoa_t,
	t.dt_nascimento_fundacao dt_nascimento_fundacao_t,
	t.nm_pessoa_razao_social nm_pessoa_razao_social_t,
	t.fl_sexo fl_sexo_t,
	t.nu_cgc_cpf nu_cgc_cpf_t,
	t.nu_ident_insc_est nu_ident_insc_est_t,
	t.nm_orgao_expedidor_ident nm_orgao_expedidor_ident_t,
	t.cd_uf_orgao_expedidor_ident cd_uf_orgao_expedidor_ident_t,
-- tb_usuario
	x.nu_usuario,
	x.nu_titular,
	x.cd_usuario,
	x.fl_status_usuario,
	x.cd_plano,
	x.cd_tipo_acomodacao,
	x.dt_cadastramento,
	x.nu_ordem_usuario,
	x.dt_referencia_carencia,
	x.dt_processamento,
	x.dt_cancelamento,
	x.pc_bonificacao,
	x.cd_tipo_dependente_usuario,
	x.vl_mensalidade vl_mensalidade,
	x.vl_taxa_adesao vl_taxa_adesao,
	x.vl_mensalidade_odonto vl_mensalidade_odonto,
	x.dt_opcao_odonto,
	x.dt_carencia_odonto,
	x.cd_um_odonto,
	x.cd_empresa_odonto,
	x.vl_adicional_idade,
	x.vl_outros_adicionais,
	x.vl_desconto,
	x.cd_tabela cd_tabela_u,
	x.dt_tabela dt_tabela_u,
	x.qt_dias_por_atraso,
	x.cd_tabela_faixa,
	x.ds_observacao,
	x.fl_carteira_ident,
	x.vl_taxa_bloqueto,
-- tb_usuario_titular
	y.cd_tabela,
	y.dt_tabela,
	y.vl_taxa_adesao vl_taxa_adesao_t,
	y.cd_um_adesao,
	y.vl_mensalidade vl_mensalidade_t,
	y.cd_um_mensalidade,
	y.fl_pagamento_inicial,
	y.dt_dia_pagamento,
	y.cd_vendedor_plano,
	y.fl_endereco_correspondencia,
	y.cd_empresa_conveniada,
	y.nu_matricula,
	y.cd_filial,
	y.vl_contrato,
-- tb_caracteristica_fisica
	w.cd_estado_civil,
-- tb_endereco_pessoa a (retorna endereco residencial do titular)
	a.nu_endereco nu_endereco_a,
	a.cd_cep_endereco cd_cep_endereco_a,
	a.nm_cidade_endereco nm_cidade_endereco_a,
	a.cd_uf_endereco cd_uf_endereco_a,
	a.cd_tipo_logradouro cd_tipo_logradouro_a,
	a.nm_rua_endereco nm_rua_endereco_a,
	a.nm_bairro_endereco nm_bairro_endereco_a,
	a.ds_compl_enderero ds_compl_enderero_a,
	a.fl_tipo_endereco fl_tipo_endereco_a,
	--a.fl_ender_cobranca fl_ender_cobranca_a,
-- tb_endereco_pessoa b (retorna o endereco comercial do titular)
	b.nu_endereco nu_endereco_b,
	b.cd_cep_endereco cd_cep_endereco_b,
	b.nm_cidade_endereco nm_cidade_endereco_b,
	b.cd_uf_endereco cd_uf_endereco_b,
	b.cd_tipo_logradouro cd_tipo_logradouro_b,
	b.nm_rua_endereco nm_rua_endereco_b,
	b.nm_bairro_endereco nm_bairro_endereco_b,
	b.ds_compl_enderero ds_compl_enderero_b,
	b.fl_tipo_endereco fl_tipo_endereco_b,
-- tb_meio_comunicacao_pessoa (retorna o telefone do titular)
	c.nu_meio_comunicacao nu_meio_comunicacao_c,
-- tb_pessoa empresa conveniada
	pe.nm_pessoa_razao_social nm_empresa,
-- tb_empresa_conveniada
	v.nm_complemento nm_complemento,
	v.fl_utilizacao,
	v.cd_forma_pagamento,
	v.cd_pessoa cd_pessoa_e,
	v.cd_empresa_controle_utilizacao cd_empresa_utilizacao,
	v.fl_tipo_empresa,
	v.pc_taxa_administracao,
	v.nu_empregado_convenio,
	v.nu_total_empregado,
	v.fl_tipo_faixa,
	v.dt_cadastramento dt_cadastramento_e,
	v.dt_dia_pagamento dt_dia_pagamento_e
from tb_pessoa@hapvida pe,
     tb_empresa_conveniada@hapvida v,
     tb_meio_comunicacao_pessoa@hapvida c,
     tb_caracteristica_fisica@hapvida w,
     tb_endereco_pessoa@hapvida a,
     tb_endereco_pessoa@hapvida b,
     tb_pessoa@hapvida t,
     vw_pessoa_titular_s z,
     tb_usuario_titular@hapvida y,
     tb_usuario@hapvida x,
     tb_pessoa@hapvida u
where x.cd_pessoa = u.cd_pessoa and
	z.nu_usuario = x.nu_usuario and
	y.nu_titular = x.nu_titular and
	t.cd_pessoa = z.cd_pessoa_titular and
	a.cd_pessoa(+) = t.cd_pessoa and
	a.fl_tipo_endereco(+) = 1 and
	b.cd_pessoa(+) = t.cd_pessoa and
	b.fl_tipo_endereco(+) = 2 and
	w.cd_pessoa(+) = t.cd_pessoa and
	c.cd_pessoa(+) = t.cd_pessoa and
	c.cd_ordem_meio_comunicacao(+) = 1 and
	v.cd_empresa_conveniada(+) = y.cd_empresa_conveniada and
	pe.cd_pessoa(+) = v.cd_pessoa
/

