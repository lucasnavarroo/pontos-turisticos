create view VW_SAM_MEDICAMENTOS_RECEITA as
    select nu_produto, nm_produto, fl_uso, fl_padronizado, subgrupo, 'F' grupo
  from (select a.nu_produto,
               a.nm_produto,
               a.fl_uso,
               a.fl_padronizado,
               d.cd_grupo_farmacologico subgrupo
          from tb_grupo_farmacologico         d,
               tb_produto_grupo_farmacologico c,
               tb_produto                     a
         where a.nu_produto = c.nu_produto
           and c.cd_grupo_farmacologico = d.cd_grupo_farmacologico
              --and d.cd_grupo_farmacologico like nvl(p_subgrupo,'%')
           and nvl(a.fl_uso, 'N') = 'S'
           and d.cd_grupo_farmacologico is not null
         group by a.nu_produto,
                  a.nm_produto,
                  a.fl_uso,
                  a.fl_padronizado,
                  d.cd_grupo_farmacologico
        union all
        select cd_grupo_farmacologico nu_produto,
               nm_grupo_farmacologico nm_produto,
               'S' fl_uso,
               'S' fl_padronizado,
               null subgrupo
          from tb_grupo_farmacologico)
union all
select nu_produto, nm_produto, fl_uso, fl_padronizado, subgrupo, 'I' grupo
  from (select a.nu_produto,
               a.nm_produto,
               a.fl_uso,
               a.fl_padronizado,
               d.cd_indicacao_terapeutica subgrupo
          from tb_indicacao_terapeutica d,
               tb_produto_indicacao     c,
               tb_produto               a
         where a.nu_produto = c.nu_produto
           and c.cd_indicacao_terapeutica = d.cd_indicacao_terapeutica
              --and d.cd_indicacao_terapeutica like nvl(p_subgrupo,'%')
           and nvl(a.fl_uso, 'N') = 'S'
           and d.cd_indicacao_terapeutica is not null
         group by a.nu_produto,
                  a.nm_produto,
                  a.fl_uso,
                  a.fl_padronizado,
                  d.cd_indicacao_terapeutica
        union all
        select cd_indicacao_terapeutica nu_produto,
               nm_indicacao_terapeutica nm_produto,
               'S' fl_uso,
               'S' fl_padronizado,
               null subgrupo
          from tb_indicacao_terapeutica)
union all
select nu_produto, nm_produto, fl_uso, fl_padronizado, subgrupo, 'P' grupo
  from (select a.nu_produto,
               a.nm_produto,
               a.fl_uso,
               a.fl_padronizado,
               d.cd_principio_ativo subgrupo
          from tb_principio_ativo         d,
               tb_produto_principio_ativo c,
               tb_produto                 a
         where a.nu_produto = c.nu_produto
           and c.cd_principio_ativo = d.cd_principio_ativo
              -- and d.cd_principio_ativo like nvl(p_subgrupo, '%')
           and nvl(a.fl_uso, 'N') = 'S'
           and d.cd_principio_ativo is not null
         group by a.nu_produto,
                  a.nm_produto,
                  a.fl_uso,
                  a.fl_padronizado,
                  d.cd_principio_ativo
        union all
        select cd_principio_ativo nu_produto,
               nm_principio_ativo nm_produto,
               'S' fl_uso,
               'S' fl_padronizado,
               null subgrupo
          from tb_principio_ativo)
union all
select a.nu_produto,
       a.nm_produto,
       a.fl_uso,
       a.fl_padronizado,
       d.cd_generico subgrupo,
       'G' grupo
  from tb_medicamento_generico d,
       tb_material_brasindice  c,
       tb_produto_mat_med      b,
       tb_produto              a
 where a.nu_produto = b.nu_produto
   and b.cd_mat_med = c.cd_material
   and c.cd_generico = d.cd_generico
      --and d.cd_generico like nvl(p_subgrupo, '%')
   and nvl(a.fl_uso, 'N') = 'S'
 group by a.nu_produto,
          a.nm_produto,
          a.fl_uso,
          a.fl_padronizado,
          d.cd_generico
union all
select nu_produto,
       nm_produto,
       fl_uso,
       fl_padronizado,
       null subgrupo,
       'B' grupo
  from (select a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado
          from tb_material_brasindice c, tb_produto_mat_med b, tb_produto a
         where a.nu_produto = b.nu_produto
           and b.cd_mat_med = c.cd_material
           and nvl(a.fl_uso, 'N') = 'S'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado)
union all
select nu_produto, nm_produto, fl_uso, fl_padronizado, subgrupo, 'C' grupo
  from (select a.nu_produto,
               a.nm_produto,
               a.fl_uso,
               a.fl_padronizado,
               d.cd_classificacao subgrupo
          from tb_classificacao   cl,
               tb_material        d,
               tb_produto_mat_med b,
               tb_produto         a
         where a.nu_produto = b.nu_produto
           and b.cd_mat_med = d.cd_material
           and d.cd_classificacao = cl.cd_classificacao
           and cl.cd_tipo_classificacao in
               (select cd_tipo_classificacao
                  from tb_tipo_classificacao
                 where fl_tipo_classificacao in (1, 2))
           and d.cd_classificacao is not null
           and nvl(a.fl_uso, 'N') = 'S'
         group by a.nu_produto,
                  a.nm_produto,
                  a.fl_uso,
                  a.fl_padronizado,
                  d.cd_classificacao)
union all
select nu_produto,
       nm_produto,
       fl_uso,
       fl_padronizado,
       null subgrupo,
       'H' grupo
  from (select a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado
          from tb_produto a
         where nvl(a.fl_uso, 'N') = 'S'
           and nvl(a.fl_hemoderivado, 'N') = 'S'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado)
union all
select nu_produto,
       nm_produto,
       fl_uso,
       fl_padronizado,
       null subgrupo,
       'V' grupo
  from (select a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado
          from tb_produto a
         where nvl(a.fl_uso, 'N') = 'S'
           and nvl(a.fl_compoe_hv, 'N') = 'S'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado)
union all
select nu_produto,
       nm_produto,
       fl_uso,
       fl_padronizado,
       null subgrupo,
       'VR' grupo
  from (select a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado
          from tb_produto a
         where nvl(a.fl_uso, 'N') = 'S'
           and nvl(a.fl_compoe_hv_r, 'N') = 'S'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado)
union all
select nu_produto, nm_produto, fl_uso, fl_padronizado, subgrupo, 'L' grupo
  from (select a.nu_produto,
               a.nm_produto,
               a.fl_uso,
               a.fl_padronizado,
               d.cd_laboratorio subgrupo
          from tb_laboratorio d, tb_produto_laboratorio c, tb_produto a
         where d.cd_laboratorio is not null
           and a.nu_produto = c.nu_produto
           and c.cd_laboratorio = d.cd_laboratorio
           and nvl(a.fl_uso, 'N') = 'S'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado, d.cd_laboratorio
        union all
        select cd_laboratorio nu_produto,
               nm_laboratorio nm_produto,
               'S' fl_uso,
               'S' fl_padronizado,
               null subgrupo
          from tb_laboratorio)
union all
select nu_produto,
       nm_produto,
       fl_uso,
       fl_padronizado,
       null subgrupo,
       'T' grupo
  from (select a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado
          from tb_produto a
         where nvl(a.fl_uso, 'N') = 'S'
           and nvl(a.fl_hemoderivado, 'N') = 'N'
         group by a.nu_produto, a.nm_produto, a.fl_uso, a.fl_padronizado)
 order by 2
/

