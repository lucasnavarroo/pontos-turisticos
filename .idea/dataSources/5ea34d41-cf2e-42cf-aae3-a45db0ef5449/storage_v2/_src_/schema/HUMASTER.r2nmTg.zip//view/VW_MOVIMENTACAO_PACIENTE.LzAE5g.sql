create view VW_MOVIMENTACAO_PACIENTE as
    select ta.nm_tipo_atendimento,
       pe.dt_pedido              dt_mov,
       pe.cd_atendimento,
       pe.cd_ocorrencia,
       to_char(pe.nu_pedido)     cd_doc,
       pe.nm_operador,
       pe.cd_ocorrencia_ocupacao,
       pe.cd_tipo_exame,
       pe.cd_tipo_entrega,
       pa.cd_paciente,
       pa.nm_paciente,
       cp.cd_convenio_base       cd_convenio,
       a.cd_setor,
       a.dt_fim_atendimento
from tb_tipo_atendimento ta,
     tb_paciente pa,
     tb_convenio_pagador cp,
     tm_atendimento a,
     tb_pedido_exame pe
where a.cd_atendimento = pe.cd_atendimento and
      cp.cd_atendimento= a.cd_atendimento and
      cp.cd_convenio_pagador=1 and
      pa.cd_paciente   = a.cd_paciente and
      ta.cd_tipo_atendimento=a.cd_tipo_atendimento
union all
select 'MEDICACOES/'||ta.nm_tipo_atendimento,
       c.dt_comanda           dt_mov,
       c.cd_atendimento,
       0,
       c.nu_comanda           cd_doc,
       null,
       1,
       1,
       1,
       pa.cd_paciente,
       pa.nm_paciente,
       cp.cd_convenio_base,
       nvl(c.cd_setor_destino,a.cd_setor) cd_setor,
       a.dt_fim_atendimento
from tb_tipo_atendimento ta,
     tb_paciente pa,
     tb_convenio_pagador cp,
     tm_atendimento a,
     tb_comanda c
where c.cd_atendimento=a.cd_atendimento and
      cp.cd_atendimento=a.cd_atendimento and
      cp.cd_convenio_pagador=1 and
      pa.cd_paciente=a.cd_paciente and
      exists (select 'X'
              from tb_classificacao cl,
                   tb_tipo_classificacao tc,
                   tb_material m,
                   tb_comanda_mat_med ic
              where ic.cd_atendimento=c.cd_atendimento and
                    ic.cd_ocorrencia=c.cd_ocorrencia and
                    ic.cd_ordem=c.cd_ordem and
                    ic.cd_ordem_cmd=c.cd_ordem_cmd and
                    m.cd_material=ic.cd_mat_med and
                    cl.cd_classificacao=m.cd_classificacao and
                    tc.cd_tipo_classificacao=cl.cd_tipo_classificacao and
                    tc.fl_tipo_classificacao=1) and
      ta.cd_tipo_atendimento=a.cd_tipo_atendimento
/

