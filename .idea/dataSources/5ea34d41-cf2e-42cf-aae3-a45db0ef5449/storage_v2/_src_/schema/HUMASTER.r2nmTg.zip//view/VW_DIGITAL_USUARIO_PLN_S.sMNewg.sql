create view VW_DIGITAL_USUARIO_PLN_S as
select "CD_PESSOA","CD_DEDO","TEMPLATE_DIGITAL","DT_INCLUSAO",
          "DS_TERMINAL","NM_USUARIO"
     from tb_digital_usuario_pln_s@hapvida
/

