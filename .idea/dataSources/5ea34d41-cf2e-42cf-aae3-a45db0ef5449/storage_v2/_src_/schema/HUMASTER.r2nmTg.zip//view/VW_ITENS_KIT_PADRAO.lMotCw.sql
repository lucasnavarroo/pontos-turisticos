create view VW_ITENS_KIT_PADRAO as
    SELECT a.id_kit,
       a.cd_atendimento,
       ab.cd_unidade_atendimento,
       aba.nm_unidade_atendimento,
       aaa.cd_param_grupo_proc,
       aaa.nm_param_grupo_proc,
       aaa.cd_tipo_grupo_proc,
       a.cd_procedimento,
       ac.nm_procedimento,
       a.dt_transacao,
       aaaaaaaa.fl_tipo_classificacao,
       aaaaaaaa.ds_fl_tipo_classificacao,
       aaaaaaaa.cd_tipo_produto_servico,
       aaaaaaa.cd_tipo_classificacao,
       aaaaaaa.ds_tipo_classificacao,
       aaaaaa.cd_classificacao,
       aaaaaa.nm_classificacao,
       aaaa.cd_mat_med cd_material_padrao,
       aaaaa.nm_material nm_material_padrao,
       DECODE(a.fl_kit_reduzido, 'S', aaaa.qt_kit_reduzido, aaaa.qt_produto) qtd,
       a.cd_pessoa_func_montou cd_pessoa,
       'M' tipo,
       a.fl_kit_reduzido fl_kit_reduzido,
       a.cd_faixa,
       aaaa.qt_kit_reduzido
  FROM tm_setor                     ad, -- setor que montou o kit
       tb_procedimento              ac, -- procedimento do kit
       tb_unidade_atendimento       aba, -- unidade de atendimento
       tm_atendimento               ab, -- atendimento do kit
       tb_classe_tipo_classificacao aaaaaaaa, -- tipo classe da classificacao
       tb_tipo_classificacao        aaaaaaa, -- tipo de classificacao do material
       tb_classificacao             aaaaaa, -- classificacao do material
       tb_material                  aaaaa, -- material do kit
       tb_prod_grupo_proc           aaaa, -- materiais x grupo de procedimento
       tb_param_grupo_proc          aaa, -- grupo de procedimento
       tb_proc_grupo_proc           aa, -- procedimento x grupo de procedimento
       tm_kit_cirurgia_lote         a -- kit
 WHERE 1 = 1
   AND nvl(aaa.fl_ativo, 'S') = 'S'
   AND aaaa.cd_grupo_prod_proc = 2
   AND a.dt_transacao BETWEEN nvl(aaaa.dt_ini_vigencia, a.dt_transacao) AND
       nvl(aaaa.dt_fin_vigencia, SYSDATE + 1)
      -- tem validade
   AND nvl(aaaaa.fl_validade, 'N') = 'S'
      -- nao e fragmentado
   AND nvl(aaaaa.fl_fragmenta, 'N') = 'N'
      -- controla lote
   AND nvl(ad.fl_controla_lote, 'N') = 'S'
      -- join a -- aa
   AND a.cd_procedimento = aa.cd_procedimento
      -- join aa -- aaa
   AND aa.cd_param_grupo_proc = aaa.cd_param_grupo_proc
      -- join aaa -- aaaa
   AND aaa.cd_param_grupo_proc = aaaa.cd_param_grupo_proc
      -- join aaaa -- aaaaa
   AND aaaa.cd_mat_med = aaaaa.cd_material
      -- join aaaaa -- aaaaaa
   AND aaaaa.cd_classificacao = aaaaaa.cd_classificacao
      -- join aaaaaa -- aaaaaaa
   AND aaaaaa.cd_tipo_classificacao = aaaaaaa.cd_tipo_classificacao
      -- join aaaaaaa -- aaaaaaaa
   AND aaaaaaa.fl_tipo_classificacao = aaaaaaaa.fl_tipo_classificacao
      -- join a -- ab
   AND a.cd_atendimento = ab.cd_atendimento(+)
      -- join ab -- aba
   AND ab.cd_unidade_atendimento = aba.cd_unidade_atendimento(+)
      -- join a -- ac
   AND a.cd_procedimento = ac.cd_procedimento
      -- join a -- ad
   AND a.cd_setor_controle = ad.cd_setor
   AND DECODE(nvl(a.fl_kit_reduzido, 'N'),
              'S',
              aaaa.qt_kit_reduzido,
              aaaa.qt_produto) > 0
   AND a.cd_faixa IS NULL

    UNION ALL
    SELECT a.id_kit,
       a.cd_atendimento,
       ab.cd_unidade_atendimento,
       aba.nm_unidade_atendimento,
       aaa.cd_param_grupo_proc,
       aaa.nm_param_grupo_proc,
       aaa.cd_tipo_grupo_proc,
       a.cd_procedimento,
       ac.nm_procedimento,
       a.dt_transacao,
       aaaaaaaa.fl_tipo_classificacao,
       aaaaaaaa.ds_fl_tipo_classificacao,
       aaaaaaaa.cd_tipo_produto_servico,
       aaaaaaa.cd_tipo_classificacao,
       aaaaaaa.ds_tipo_classificacao,
       aaaaaa.cd_classificacao,
       aaaaaa.nm_classificacao,
       ap.cd_material cd_material_padrao,
       aaaaa.nm_material nm_material_padrao,
       DECODE(nvl(a.fl_kit_reduzido, 'N'),
              'S',
              ap.qt_kit_reduzido,
              ap.qt_material) qtd,
       a.cd_pessoa_func_montou cd_pessoa,
       'M' tipo,
       a.fl_kit_reduzido fl_kit_reduzido,
       a.cd_faixa,
       ap.qt_kit_reduzido
  FROM tm_setor                     ad, -- setor que montou o kit
       tb_procedimento              ac, -- procedimento do kit
       tb_unidade_atendimento       aba, -- unidade de atendimento
       tm_atendimento               ab, -- atendimento do kit
       tb_classe_tipo_classificacao aaaaaaaa, -- tipo classe da classificacao
       tb_tipo_classificacao        aaaaaaa, -- tipo de classificacao do material
       tb_classificacao             aaaaaa, -- classificacao do material
       tb_material                  aaaaa, -- material do kit
       --   tb_prod_grupo_proc                       aaaa,   -- materiais x grupo de procedimento
       tb_param_grupo_proc       aaa, -- grupo de procedimento
       tb_proc_grupo_proc        aa, -- procedimento x grupo de procedimento
       tb_item_kit_cirurgia_lote ipa,
       tb_material_pediatria     ap,
       tm_kit_cirurgia_lote      a -- kit
 WHERE 1 = 1
      -- filtros
   AND nvl(aaa.fl_ativo, 'S') = 'S'
      --  and aaaa.cd_grupo_prod_proc = 2
   AND a.dt_transacao BETWEEN nvl(ap.dt_ini_vigencia, a.dt_transacao) AND
       nvl(ap.dt_fin_vigencia, SYSDATE + 1)
      -- tem validade
   AND nvl(aaaaa.fl_validade, 'N') = 'S'
      -- nao e fragmentado
   AND nvl(aaaaa.fl_fragmenta, 'N') = 'N'
      -- controla lote
   AND nvl(ad.fl_controla_lote, 'N') = 'S'
      -- join a -- aa
   AND a.cd_procedimento = aa.cd_procedimento
      -- join aa -- aaa
   AND aa.cd_param_grupo_proc = aaa.cd_param_grupo_proc
      -- join aaa -- aaaa
      --  and aaa.cd_param_grupo_proc = aaaa.cd_param_grupo_proc
      -- join aaaa -- aaaaa
   AND ap.cd_material = aaaaa.cd_material
      -- join aaaaa -- aaaaaa
   AND aaaaa.cd_classificacao = aaaaaa.cd_classificacao
      -- join aaaaaa -- aaaaaaa
   AND aaaaaa.cd_tipo_classificacao = aaaaaaa.cd_tipo_classificacao
      -- join aaaaaaa -- aaaaaaaa
   AND aaaaaaa.fl_tipo_classificacao = aaaaaaaa.fl_tipo_classificacao
      -- join a -- ab
   AND a.cd_atendimento = ab.cd_atendimento(+)
      -- join ab -- aba
   AND ab.cd_unidade_atendimento = aba.cd_unidade_atendimento(+)
      -- join a -- ac
   AND a.cd_procedimento = ac.cd_procedimento
      -- join a -- ad
   AND a.cd_setor_controle = ad.cd_setor
   AND a.cd_procedimento = ap.cd_procedimento
   AND a.cd_faixa = ap.cd_faixa
   AND ipa.id_kit = a.id_kit
   AND ap.cd_material = ipa.cd_material
   AND a.cd_faixa IS NOT NULL
   AND DECODE(nvl(a.fl_kit_reduzido, 'N'),
              'S',
              ap.qt_kit_reduzido,
              ap.qt_material) > 0
/

