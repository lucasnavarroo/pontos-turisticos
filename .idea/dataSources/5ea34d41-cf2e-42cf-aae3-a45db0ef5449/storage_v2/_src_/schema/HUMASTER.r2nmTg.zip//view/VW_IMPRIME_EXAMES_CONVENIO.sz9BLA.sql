create view VW_IMPRIME_EXAMES_CONVENIO as
select /*+ FIRST_ROW */ distinct
   pe.dt_pedido,
   pe.nu_pedido,
   pe.cd_atendimento,
   pe.cd_ocorrencia,
   gu.cd_pessoa_realiza,
   gu.cd_setor_origem,
          cp.cd_convenio,
   a.cd_motivo_atendimento,
   a.fl_internacao,
   pa.nm_paciente
    from  tb_paciente pa,
   tb_guia gu,
          tb_convenio_pagador cp,
   tb_atendimento a,
   tb_pedido_exame pe
    where pe.dt_pedido >= sysdate-90
      and fu_vw_imprime_exames_convenio(pe.cd_atendimento, pe.cd_ocorrencia) = 0
      and gu.cd_atendimento       = pe.cd_atendimento
      and gu.cd_ocorrencia_pedido = pe.cd_ocorrencia
      and a.cd_atendimento        = pe.cd_atendimento
      and cp.cd_atendimento       = a.cd_atendimento
      and pa.cd_paciente          = a.cd_paciente
/

