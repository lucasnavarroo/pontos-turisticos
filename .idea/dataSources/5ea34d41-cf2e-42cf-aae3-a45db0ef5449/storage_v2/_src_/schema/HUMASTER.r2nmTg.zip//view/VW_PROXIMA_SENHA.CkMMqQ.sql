create view VW_PROXIMA_SENHA as
    select /*+ ordered index(s ix_senha_atendimento3)*/ dt_geracao_senha,
       cd_grupo_atendimento,
       cd_local_atendimento,
       cd_ponto_atendimento_ate,
       cd_ponto_atendimento_cad,
       cd_senha_atendimento,
       nm_paciente,
       cd_atendimento,
       cd_senha_master,
       fl_status,
       fl_status_anterior,
       fl_toca_som,
       fl_prioridade,
       dt_ordem,
       'HOS' flag_banco
  from tb_senha_atendimento_sa s
 where  fl_status = 9
   and dt_geracao_senha between (trunc(sysdate) - 6/24) and trunc(sysdate)+1
UNION ALL
select /*+ ordered index(sa ix_senha_atendimento3)*/ sa.dt_geracao_senha,
       sa.cd_grupo_atendimento,
       sa.cd_local_atendimento,
       cd_ponto_atendimento_ate,
       sa.cd_ponto_atendimento cd_ponto_atendimento_cad,
       sa.cd_senha_atendimento,
       p.nm_pessoa_razao_social nm_paciente,
       sa.nu_atendimento cd_atendimento,
       sa.cd_senha_master,
       sa.fl_status,
       sa.fl_status_anterior,
       fl_toca_som,
       fl_prioridade,
       dt_ordem,
       'HAP' flag_banco
  from tb_senha_atendimento@hapvida sa,
       tb_usuario@hapvida u,
       tb_pessoa@hapvida p
 where sa.cd_usuario = u.cd_usuario(+)
   and u.cd_pessoa = p.cd_pessoa(+)
   and sa.fl_status = 1
   and sa.dt_geracao_senha between trunc(sysdate) and trunc(sysdate)+1
Union All
select Sysdate dt_geracao_senha,
       Null cd_grupo_atendimento,
       sa.cd_local_atendimento,
       sa.cd_ponto_atendimento cd_ponto_atendimento_ate,
       sa.cd_ponto_atendimento cd_ponto_atendimento_cad,
       Null cd_senha_atendimento,
       'Auxiliar/Atendente' nm_paciente,
       null cd_atendimento,
       1 cd_senha_master,
       Null fl_status,
       Null fl_status_anterior,
       0 fl_toca_som,
       0 fl_prioridade,
       sysdate dt_ordem,
       'HAP' flag_banco
  from Tb_Ponto_Operador_Atend@hapvida sa
  where Fl_Atendente = 'S'
order by 1
/

