create view VW_POSTOS_API_SSVV as
select a.nm_setor, a.cd_setor, a.cd_setor_emp cd_filial, b.fl_obriga_biometria, b.fl_reconhecimento_facial
 from tb_modelo_plano_tratamento c, tb_modelo_plano_trat_filial b, tm_setor a
  where a.fl_posto = 'S'
  and a.cd_mapa is not null
  and b.cd_filial = a.cd_setor_emp
  and b.cd_setor = a.cd_setor
  and b.fl_visita_obrigatoria = 'S'
  and c.cd_modelo = b.cd_modelo
  and c.fl_tipo_modelo = '2'
  order by a.nm_setor, a.cd_setor
/

