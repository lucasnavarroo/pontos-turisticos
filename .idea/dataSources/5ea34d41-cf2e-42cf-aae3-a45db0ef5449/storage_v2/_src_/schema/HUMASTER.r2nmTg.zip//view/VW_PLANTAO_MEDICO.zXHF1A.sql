create view VW_PLANTAO_MEDICO as
select "CD_MEDICO","DT_AGENDA","SS_AGENDA","HR_AGENDA" from tt_plantao_medico
/

