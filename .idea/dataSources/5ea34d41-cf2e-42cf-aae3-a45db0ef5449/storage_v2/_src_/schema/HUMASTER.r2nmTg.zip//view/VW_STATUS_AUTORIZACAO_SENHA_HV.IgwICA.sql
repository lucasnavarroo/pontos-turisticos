create view VW_STATUS_AUTORIZACAO_SENHA_HV as
select "CD_STATUS","DS_STATUS","FL_STATUS" from tb_status_autorizacao_senha@hapvida
/

