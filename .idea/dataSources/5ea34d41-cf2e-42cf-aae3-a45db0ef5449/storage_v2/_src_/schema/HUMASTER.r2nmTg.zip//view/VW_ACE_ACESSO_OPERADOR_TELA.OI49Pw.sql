create view VW_ACE_ACESSO_OPERADOR_TELA as
select ta.cod_usuario cd_operador ,ta.cd_tela, upper (top.descricao)descricao
from tb_acesso_usuario ta , tb_opcoes_menu top
where ta.cd_tela = top.cd_tela
/

