create view VW_SAM_SENHA_ATENDENDO as
select sa.CD_SENHA_MASTER,
       sa.CD_GRUPO_ATENDIMENTO,
       sa.CD_LOCAL_ATENDIMENTO,
       sa.CD_SENHA_ATENDIMENTO,
       sa.CD_PONTO_ATENDIMENTO_ATE,
       sa.CD_ATENDIMENTO,
       sa.CD_PACIENTE,
       sa.CD_USUARIO,
       sa.DT_INICIO_ATENDIMENTO,
       sa.DT_GERACAO_SENHA,
       sa.NM_PACIENTE,
       sa.VL_IDADE,
       sa.fl_prioridade,
       sa.fl_triagem
  from tb_senha_atendimento_sa sa, tb_local_atendimento_sa loc
 where sa.fl_status = 3
   and loc.cd_local_atendimento = sa.cd_local_atendimento
   and sa.dt_geracao_senha >= trunc(sysdate) - 3
   and sa.dt_geracao_senha >= trunc(sysdate) - nvl(loc.qt_dias_coleta, 1)
/

