create view VW_GRUPOS_ATENDIMENTO as
    Select /*+ ordered index(g CP_Grupo_Atendimento_Sa)*/ Distinct
       g.cd_grupo_atendimento,
       g.cd_local_Atendimento,
       g.ds_grupo_atendimento,
       g.cd_cor_atendimento,
       'HOS' Fl_Banco
  From Tb_Grupo_Ponto_Atend_Sa p,
       Tb_grupo_atendimento_sa g

Where g.cd_local_atendimento = p.Cd_Local_Atendimento
  And g.cd_grupo_atendimento = p.cd_grupo_atendimento
  And (
       Exists (
              Select /*+ ordered index(IX_CE_GRUPO_LOCAL_ATEND)*/ 1 from tb_senha_atendimento_sa s
              Where s.Cd_Local_Atendimento = g.cd_local_atendimento and s.cd_grupo_atendimento = g.cd_grupo_atendimento
                And s.Dt_Geracao_Senha Between Trunc(Sysdate) And Sysdate + 1
             )
        or
             (
             Select /*+ ordered index(IX_CE_GRUPO_LOCAL_ATEND)*/ Count(*) from tb_senha_atendimento_sa s
              Where s.Cd_Local_Atendimento = g.cd_local_atendimento
                And s.Dt_Geracao_Senha Between Trunc(Sysdate) And Sysdate + 1
             ) = 0
       )

Union all

Select Distinct g.cd_grupo_atendimento,
       g.cd_local_Atendimento,
       g.ds_grupo_atendimento,
       g.cd_cor_atendimento,
       'HAP' Fl_Banco
  From tb_grupo_atendimento@hapvida g,
       Tb_Grupo_Ponto_Atend@hapvida p
Where g.cd_local_atendimento = p.Cd_Local_Atendimento
  And g.cd_grupo_atendimento = p.cd_grupo_atendimento
  And (
       Exists (
              Select 1 from tb_senha_atendimento@hapvida s
              Where s.Cd_Local_Atendimento = g.cd_local_atendimento and s.cd_grupo_atendimento = g.cd_grupo_atendimento
                And s.Dt_Geracao_Senha Between Trunc(Sysdate) And Sysdate + 1
             )
       or
        (
             Select Count(*) from tb_senha_atendimento@hapvida s
              Where s.Cd_Local_Atendimento = g.cd_local_atendimento
                And s.Dt_Geracao_Senha Between Trunc(Sysdate) And Sysdate + 1
        ) = 0
      )
/

