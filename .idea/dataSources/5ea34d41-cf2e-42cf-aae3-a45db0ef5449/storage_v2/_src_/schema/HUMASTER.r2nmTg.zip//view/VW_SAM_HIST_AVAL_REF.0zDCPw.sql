create view VW_SAM_HIST_AVAL_REF as
Select /*+first_rows(100)*/
 T."CD_ATENDIMENTO",T."CD_AVALIACAO",T."NM_AVALIACAO",T."DT_EVOLUCAO",T."HR_EVOLUCAO",T."CD_PROFISSIONAL",T."NU_EVOLUCAO",T."CD_ORDEM",T."CD_OCORRENCIA_PLANO",T."FL_TIPO_GRUPO",T."NU_PRESCRICAO",T."CD_CHAVE",T."FL_TIPO_ATEND", pk_pepsam_util.fn_encrypt(t.cd_chave) cd_chave_url
  From (select a.cd_atendimento,
               c.cd_avaliacao,
               c.nm_avaliacao,
               to_char(b.dt_evolucao_avaliacao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(b.hr_evolucao_avaliacao) hr_evolucao,
               a.cd_profissional,
               a.nu_evolucao,
               a.cd_ordem,
               a.cd_ocorrencia_plano,
               'AA' fl_tipo_grupo,
               0 nu_prescricao,
               c.cd_tipo_documento_prontuario || ';' || a.cd_atendimento || ';' ||
               a.cd_ocorrencia_plano || ';' || a.cd_ordem || ';' ||
               a.nu_evolucao || ';' ||
               to_char(b.dt_evolucao_avaliacao, 'dd/mm/yyyy') || ';' ||
               fn_hora(b.hr_evolucao_avaliacao) || ';' || a.nu_documento_id cd_chave,
               1 fl_tipo_atend
          from tb_avaliacao c, tb_evolucao_avaliacao b, tb_evolucao a
         where b.cd_atendimento = a.cd_atendimento
           and b.cd_ocorrencia_plano = a.cd_ocorrencia_plano
           and b.cd_ordem = a.cd_ordem
           and b.cd_avaliacao = c.cd_avaliacao
        union all
        select am.cd_atendimento,
               null cd_avaliacao,
               'ATESTADO MEDICO',
               to_char(am.dt_emissao, 'dd/mm/yyyy') dt_atestado,
               fn_hora(am.hr_emissao) hr_atestado,
               am.cd_medico_atendente cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               am.cid10 cid10,
               am.nu_documento_id nu_documento_id,
               10 || ';' || am.cd_atendimento || ';' || am.cid10 || ';' ||
               to_char(am.dt_emissao, 'dd/mm/yyyy') || ';' || am.hr_emissao || ';' ||
               p.nm_paciente || ';' || am.qt_dias || ';' ||
               am.cd_medico_atendente || ';' || am.nu_documento_id,
               1 fl_tipo_atend
          from TB_ATESTADO_MEDICO am, tm_atendimento a, tb_paciente p
         where a.cd_atendimento = am.cd_atendimento
           and p.cd_paciente = a.cd_paciente
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               b.nm_avaliacao,
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               b.cd_tipo_documento_prontuario || ';' || a.cd_atendimento || ';' ||
               a.cd_ocorrencia_plano || ';' || a.cd_ordem_prescricao || ';' ||
               a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' ||
               decode(b.cd_tipo_documento_prontuario,
                      24,
                      a.NU_DOCUMENTO_ID_APRAZAMENTO,
                      a.NU_DOCUMENTO_ID) cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao    d,
               tb_subgrupo_avaliacao c,
               tb_avaliacao          b,
               tb_prescricao_medica  a
         where a.cd_avaliacao = b.cd_avaliacao
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao
           and fl_prescricao_medica = 'E'
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               'PRESCRIÇÃO MÉDICA',
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               1 || ';' || a.cd_atendimento || ';' || a.cd_ocorrencia_plano || ';' ||
               a.cd_ordem_prescricao || ';' || a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' ||
               decode(b.cd_tipo_documento_prontuario,
                      24,
                      a.NU_DOCUMENTO_ID_APRAZAMENTO,
                      a.NU_DOCUMENTO_ID) cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao    d,
               tb_subgrupo_avaliacao c,
               tb_avaliacao          b,
               tb_prescricao_medica  a
         where a.cd_avaliacao = b.cd_avaliacao(+)
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao(+)
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao(+)
           and fl_prescricao_medica = 'M'
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               'PRESCRIÇÃO MÉDICA(DOCUMENTOS ASSINADOS)',
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               999 || ';' || a.cd_atendimento || ';' ||
               a.cd_ocorrencia_plano || ';' || a.cd_ordem_prescricao || ';' ||
               a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' ||
               decode(b.cd_tipo_documento_prontuario,
                      24,
                      a.NU_DOCUMENTO_ID_APRAZAMENTO,
                      a.NU_DOCUMENTO_ID) cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao    d,
               tb_subgrupo_avaliacao c,
               tb_avaliacao          b,
               tb_prescricao_medica  a
         where a.cd_avaliacao = b.cd_avaliacao(+)
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao(+)
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao(+)
           and fl_prescricao_medica = 'M'
           and a.nu_documento_id is not null
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               'PRESCRIÇÃO MÉDICA(DOCUMENTOS ASSINADOS)',
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               999 || ';' || a.cd_atendimento || ';' ||
               a.cd_ocorrencia_plano || ';' || a.cd_ordem_prescricao || ';' ||
               a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' || dp.nu_documento_id cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao      d,
               tb_subgrupo_avaliacao   c,
               tb_avaliacao            b,
               tb_prescricao_medica    a,
               tb_documento_prontuario dp
         where a.cd_avaliacao = b.cd_avaliacao(+)
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao(+)
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao(+)
           and dp.nu_documento_pai = a.nu_documento_id
           and fl_prescricao_medica = 'M'
           and nvl(b.cd_tipo_documento_prontuario, 0) <> 24
           and a.nu_documento_id is not null
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               'PRESCRIÇÃO MÉDICA(DOCUMENTOS ASSINADOS)',
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               999 || ';' || a.cd_atendimento || ';' ||
               a.cd_ocorrencia_plano || ';' || a.cd_ordem_prescricao || ';' ||
               a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' || dp.nu_documento_id cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao      d,
               tb_subgrupo_avaliacao   c,
               tb_avaliacao            b,
               tb_prescricao_medica    a,
               tb_documento_prontuario dp
         where a.cd_avaliacao = b.cd_avaliacao(+)
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao(+)
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao(+)
           and dp.nu_documento_pai = a.nu_documento_id_aprazamento
           and fl_prescricao_medica = 'M'
           and nvl(b.cd_tipo_documento_prontuario, 0) = 24
           and a.nu_documento_id is not null
        union all
        select a.cd_atendimento,
               b.cd_avaliacao,
               'APRAZAMENTO/PRESCRIÇÃO',
               to_char(a.dt_prescricao, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_prescricao) hr_evolucao,
               a.cd_profissional,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               d.fl_tipo_grupo,
               a.nu_prescricao_medica nu_prescricao,
               24 || ';' || a.cd_atendimento || ';' || a.cd_ocorrencia_plano || ';' ||
               a.cd_ordem_prescricao || ';' || a.nu_prescricao_medica || ';' ||
               to_char(a.dt_prescricao, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_prescricao) || ';' ||
               a.NU_DOCUMENTO_ID_APRAZAMENTO cd_chave,
               1 fl_tipo_atend
          from tb_grupo_avaliacao    d,
               tb_subgrupo_avaliacao c,
               tb_avaliacao          b,
               tb_prescricao_medica  a
         where a.cd_avaliacao = b.cd_avaliacao(+)
           and b.cd_subgrupo_avaliacao = c.cd_subgrupo_avaliacao(+)
           and c.cd_grupo_avaliacao = d.cd_grupo_avaliacao(+)
           and fl_prescricao_medica = 'M'
        union all
        select a.cd_atendimento,
               null,
               'RECEITA MÉDICA',
               to_char(a.dt_receita, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_receita) hr_evolucao,
               a.cd_profissional_valida,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               null,
               null,
               9 || ';' || a.cd_atendimento || ';' || a.cd_ocorrencia_plano || ';' ||
               a.cd_ordem_receita || ';' || p.nm_paciente || ';' ||
               a.cd_profissional_valida || ';' ||
               to_char(a.dt_receita, 'dd/mm/yyyy') || ';' ||
               fn_hora(a.hr_receita) || ';' || a.NU_DOCUMENTO_ID cd_chave,
               1 fl_tipo_atend
          from tb_paciente p, tm_atendimento ate, tb_receita_atendimento a
         where a.fl_validado = 'S'
           and a.cd_profissional_cancela is null
           and length(a.ds_receita) > 0
           and ate.cd_atendimento = a.cd_atendimento
           and p.cd_paciente = ate.cd_paciente
        union all
        select a.cd_atendimento,
               null,
               'RECEITA MÉDICA ESPECIAL',
               to_char(a.dt_receita, 'dd/mm/yyyy') dt_evolucao,
               fn_hora(a.hr_receita) hr_evolucao,
               a.cd_profissional_valida,
               0 nu_evolucao,
               0 cd_ordem,
               0 cd_ocorrencia_plano,
               null,
               null,
               22 || ';' || a.cd_atendimento || ';' || a.cd_ocorrencia_plano || ';' ||
               a.cd_ordem_receita || ';' || a.NU_DOCUMENTO_ID cd_chave,
               1 fl_tipo_atend
          from tb_receita_atendimento a
         where a.fl_validado = 'S'
           and a.cd_profissional_cancela is null
           and length(a.ds_receita_especial) > 0
        Union All
        select a.cd_atendimento,
               null,
               'CONSULTA AMBULATORIAL',
               to_char(a.dt_atendimento, 'dd/mm/yyyy') dt_atendimento,
               fn_hora(to_number(to_char(a.dt_atendimento, 'sssss'))),
               null,
               a.cd_senha_master,
               0,
               0,
               null,
               null,
               1009900 || ';' || a.cd_atendimento || ';' ||
               a.cd_senha_master || ';' ||
               to_char(a.dt_atendimento, 'dd/mm/yyyy hh24:mi:ss') || ';' ||
               a.cd_medico cd_chave,
               1 fl_tipo_atend
          from tb_historico_paciente_sa a
         where cd_atendimento in
               (Select cd_atendimento
                  from tm_atendimento
                 where fl_internacao = 'N')
           and cid10 is not null
           and nvl(fn_verifica_documento(cd_atendimento, 12), 'A') != '12'
        union all
        Select /*+DRIVING_SITE(pf,pm,pl,ac,pu)*/
         ac.NU_ATENDIMENTO cd_atendimento,
         null,
         '(Consulta)',
         to_char(TRUNC(ac.DT_ATENDIMENTO), 'dd/mm/yyyy') DT_ATENDIMENTO,
         fn_hora(to_number(to_char(aC.dt_atendimento, 'sssss'))) hr_atendimento,
         null,
         0,
         0,
         0,
         null,
         null,
         '99' || ';' || ac.NU_ATENDIMENTO || ';' || pu.cd_pessoa || ';' ||
         to_char(TRUNC(ac.DT_ATENDIMENTO), 'dd/mm/yyyy') || ';' ||
         'CONSULTA CLINICA ELETIVA' || ';' cd_chave,
         2 fl_tipo_atend
          From tb_prestador_fisico@hapvida     pf,
               tb_pessoa@hapvida               pm,
               tb_pessoa@hapvida               pl,
               TB_ATENDIMENTO_CONSULTA@hapvida ac,
               tb_pessoa@hapvida               pu
         where ac.cd_pessoa = pu.cd_pessoa
           and pl.cd_pessoa = ac.cd_prestador_juridico
           and pm.cd_pessoa = ac.cd_prestador
           and pf.cd_pessoa = pm.cd_pessoa) T
 Order By Dt_Evolucao Desc, Hr_Evolucao Desc
/

