create view VW_OPERACAO_CCUSTO_DET as
    select m.dt_emissao_documento dt_emissao,
   v.dt_transacao            ,
   m.cd_filial               ,
   x.cd_centro_custo         ,
   c.cd_classe_tipo_operacao ,
   c.nm_classe_tipo_operacao ,
   t.cd_tipo_operacao        ,
   t.nm_tipo_operacao        ,
   ot.cd_operacao            ,
   o.nm_operacao             ,
   m.vl_transacao*x.vl_rateio/100*ot.vl_rateio/100 vl_centro_custo
   from tb_classe_tipo_operacao c,
   tb_tipo_operacao t,
   tb_operacao o,
   tb_centro_custo_transacao x,
   tb_operacao_transacao ot,
   tm_movimento_transacao m,
   tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta
  and   ot.cd_movimento_conta = m.cd_movimento_conta
  and   ot.cd_ordem_transacao = m.cd_ordem_transacao
  and   x.cd_movimento_conta = m.cd_movimento_conta
  and   x.cd_ordem_transacao = m.cd_ordem_transacao
  and   o.cd_operacao = ot.cd_operacao
  and   t.cd_tipo_operacao = o.cd_tipo_operacao
  and   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao
  and   v.dt_estorno is null
  and   v.fl_movimento_conta = 2
union all
 select m.dt_emissao,
   m.dt_status,
   m.cd_filial               ,
   ot.cd_setor               ,
   c.cd_classe_tipo_operacao ,
   c.nm_classe_tipo_operacao ,
   t.cd_tipo_operacao        ,
   t.nm_tipo_operacao        ,
   ot.cd_operacao            ,
   o.nm_operacao             ,
   decode(nvl(m.VL_SALDO_OBRIGACAO,0),0,m.vl_obrigacao,
      m.vl_saldo_obrigacao)*ot.vl_rateio/100 vl_centro_custo
   from tb_classe_tipo_operacao c,
   tb_tipo_operacao t,
   tb_operacao o,
   tb_operacao_obrigacao ot,
   tm_obrigacao m
where   ot.cd_obrigacao = m.cd_obrigacao
  and   o.cd_operacao = ot.cd_operacao
  and   t.cd_tipo_operacao = o.cd_tipo_operacao
  and   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao
  and   m.cd_status = 3
/

