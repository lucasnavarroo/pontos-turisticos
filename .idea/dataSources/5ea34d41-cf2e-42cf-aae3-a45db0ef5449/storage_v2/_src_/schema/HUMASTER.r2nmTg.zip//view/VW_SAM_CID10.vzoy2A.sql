create view VW_SAM_CID10 as
select "CID10","OPC","CAT","SUBCAT","DESCR","RESTRSEXO","CD_GRUPO_CID10","CD_SUBGRUPO_CID10","CD_CATEGORIA_CID10","NM_CID10","FL_USO","OBS"
    from tb_cid10
   where fl_uso = 'S'
/

