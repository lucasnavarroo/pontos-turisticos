create view VW_SAM_EXAME_SOLICITADO as
select e.cd_senha_master,
       e.cd_exame,
       e.cd_atendimento,
       e.cd_procedimento,
       p.nr_procedimento nm_procedimento,
       e.qt_exames,
       e.fl_lado_membro,
       to_char(e.dt_importacao, 'dd/mm/yyyy hh24:mi') dt_importacao,
       to_char(e.dt_atendimento, 'dd/mm/yyyy hh24:mi') dt_solicitacao,
       e.ds_justificativa,
       e.ds_indicacao_clinica,
       e.nu_guia,
       case
         when nvl(cd_tp_atend_dest, 1) = 0 then
          'INTERNAÇÃO'
         else
          'SADT'
       end ds_guia,
       p.fl_tipo_exame,
       tp.nm_tipo_procedimento,
       DECODE(e.fl_lado_membro,
              1,
              'DIREITO',
              2,
              'ESQUERDO',
              3,
              'AMBOS',
              NULL) ds_lado_membro_display,
       to_char(e.dt_coleta_cancelada, 'dd/mm/yyyy') dt_coleta_cancelada,
       p.fl_membros_pares,
       e.fl_exame_impresso,
       e.cd_ocorrencia,
       e.cd_ordem,
       e.CD_LOCAL_ATEND_DEST,
       e.CD_GRUPO_DEST,
       e.CD_PROCEDIMENTO_DEST,
       e.CD_CLINICA_DEST,
       e.CD_TP_ATEND_DEST,
       e.FL_EXAME_CANCELADO
  from TB_EXAME_SOLICITADO_SA e, TB_PROCEDIMENTO p, TB_TIPO_PROCEDIMENTO tp
 where e.cd_procedimento = p.cd_procedimento
   and p.fl_tipo_exame = tp.cd_tipo_procedimento
/

