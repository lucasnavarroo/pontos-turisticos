create view VW_SAM_SENHA_PAINEL as
select CD_SENHA_MASTER,
       CD_GRUPO_ATENDIMENTO,
       CD_LOCAL_ATENDIMENTO,
       CD_SENHA_ATENDIMENTO,
       CD_PONTO_ATENDIMENTO_ATE,
       CD_ATENDIMENTO,
       CD_PACIENTE,
       CD_USUARIO,
       DT_INICIO_ATENDIMENTO,
       DT_GERACAO_SENHA,
       NM_PACIENTE,
       VL_IDADE,
       fl_prioridade,
       fl_triagem
from   tb_senha_atendimento_sa
where  fl_status = 9
and    dt_geracao_senha >= trunc(sysdate)-1
/

