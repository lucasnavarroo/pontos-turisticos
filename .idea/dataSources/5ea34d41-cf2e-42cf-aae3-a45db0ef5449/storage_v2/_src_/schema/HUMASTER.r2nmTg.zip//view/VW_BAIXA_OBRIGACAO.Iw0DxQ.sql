create view VW_BAIXA_OBRIGACAO as
select
  o.dt_emissao,
  o.dt_vencimento,
  o.dt_prevista_liquidacao,
  o.cd_filial,
  o.cd_obrigacao,
  o.cd_status,
  o.cd_especie_titulo,
  o.cd_documento_gerador,
  o.cd_documento_controle,
  o.cd_cedente_sacado,
  o.vl_saldo_obrigacao,
  o.vl_obrigacao,
  decode(sign(o.dt_vencimento-o.dt_prevista_liquidacao),-1,
    o.vl_obrigacao*o.pc_multa_atrazo/100*
    decode(o.cd_status,2,0,7,0,1),0) vl_multa,
  decode(sign(o.dt_vencimento-o.dt_prevista_liquidacao),-1,
    (o.dt_prevista_liquidacao-o.dt_vencimento)*o.vl_juro_dia,0) vl_juros,
  o.cd_um,
  o.cd_tipo_obrigacao,
  p.nm_pessoa_razao_social,
  p.cd_pessoa
from tb_pessoa p,
     tm_obrigacao o
where o.cd_status in (1,2,5,10,11,13,12,14)
  and p.cd_pessoa = o.cd_cedente_sacado
/

