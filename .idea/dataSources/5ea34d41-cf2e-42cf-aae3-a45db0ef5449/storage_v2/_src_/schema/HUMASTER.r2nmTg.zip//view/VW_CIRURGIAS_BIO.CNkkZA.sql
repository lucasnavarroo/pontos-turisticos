create view VW_CIRURGIAS_BIO as
select pc.cd_atendimento,
         pc.cd_ocorrencia,
         pc.id_kit,
         pc.cd_sala_cirurgia,
         pc.dt_transacao,
         pc.fl_status,
         a.cd_paciente,
         pa.nm_paciente,
         sc.nm_setor as nm_sala_cirurgia,
         sc.cd_setor_sup,
         sc.cd_setor_emp
  from tb_ponto_cirurgia pc,
       tm_kit_cirurgia_lote cl,
       tm_atendimento a,
       tb_paciente pa,
       tm_setor sc,
       tb_param_setor ps
  where cl.id_kit = pc.id_kit
  and a.cd_atendimento = pc.cd_atendimento + 0
  and pa.cd_paciente = a.cd_paciente
  and sc.cd_setor = pc.cd_sala_cirurgia
  and ps.cd_setor = sc.cd_setor
  and nvl(ps.fl_gerar_cirurgia, 'N') = 'S'
  and pc.fl_status = 0
/

