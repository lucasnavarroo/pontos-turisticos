create view VW_PRODUTOS_TMP as
    select   cd_taxas cd_item,
         nm_taxas nm_item,
	 'T' Tipo
from tb_taxas
where cd_taxas > '0'
union all
select   to_char(cd_mat_med) cd_item,
	 nm_mat_med||' '||cd_apresentacao||' '||
	 to_char(qt_conteudo)||'/'||cd_unidade nm_item,
	 'M' Tipo
from tb_mat_med
where cd_mat_med > 1
union all
select   cd_procedimento cd_item,
	 nr_procedimento nm_item,
	 'P' Tipo
from tb_procedimento
where cd_procedimento > '0'
/

