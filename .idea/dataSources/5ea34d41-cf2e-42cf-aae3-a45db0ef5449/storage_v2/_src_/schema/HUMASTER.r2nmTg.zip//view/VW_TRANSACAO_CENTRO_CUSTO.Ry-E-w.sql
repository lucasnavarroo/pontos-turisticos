create view VW_TRANSACAO_CENTRO_CUSTO as
select
 v.CD_MOVIMENTO_CONTA      ,
 v.cd_conta_corrente_credito,
 v.cd_conta_corrente_debito,
 v.cd_tipo_transacao_db    ,
 v.cd_tipo_transacao_cr    ,
 v.dt_transacao            ,
 M.CD_FILIAL               ,
 x.cd_centro_custo         ,
 m.DT_EMISSAO_DOCUMENTO    ,
 m.CD_HISTORICO_PADRAO     ,
 LTRIM(h.DS_HISTORICO_PADRAO||' '||m.NM_HISTORICO,' ') NM_HISTORICO,
 abs(m.VL_TRANSACAO*x.vl_rateio/100) vl_transacao,
 m.CD_UM_TRANSACAO         ,
 decode(sign(m.vl_transacao),-1,decode(m.fl_lancamento,'C','D','D','C'),m.FL_LANCAMENTO) fl_lancamento,
 m.DT_ESTORNO
from tb_historico_padrao h,
     tb_centro_custo_transacao x,
     tm_movimento_transacao m,
     tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta and
   x.cd_movimento_conta = m.cd_movimento_conta and
   x.cd_ordem_transacao = m.cd_ordem_transacao and
   h.cd_historico_padrao(+)=m.cd_historico_padrao and
   (v.cd_conta_corrente_credito is null or
    v.cd_conta_corrente_debito is null)
/

