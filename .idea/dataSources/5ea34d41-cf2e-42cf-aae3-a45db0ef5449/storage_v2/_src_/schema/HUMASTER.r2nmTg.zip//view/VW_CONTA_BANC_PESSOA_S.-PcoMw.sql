create view VW_CONTA_BANC_PESSOA_S as
select "CD_PESSOA","CD_BANCO","CD_AGENCIA","CD_TIPO_CONTA_BANCARIA","NU_CONTA_BANCARIA","CD_DV_CONTA" from tb_conta_bancaria_pessoa@hapvida
/

