create view VW_SAM_AEROSSOL_HEADER as
select ppu.cd_atendimento,
       ppu.cd_ocorrencia_plano,
       ppu.cd_ordem_prescricao,
       ppu.cd_ordem_proc_plano_uso,
       ppu.cd_procedimento,
       ppu.nm_procedimento,
       ppu.qt_frequencia_uso,
       ppu.fl_validado,
       ppu.fl_status_uso,
       ppu.ds_observacao,
       presc.nm_fantasia           prof_prescritor,
       val.nm_fantasia             prof_validador,
       canc.nm_fantasia            prof_cancelador
  from TB_PROCEDIMENTO_PLANO_USO ppu,
       TB_PESSOA                 PRESC,
       TB_PESSOA                 VAL,
       TB_PESSOA                 CANC
 where ppu.cd_profissional_prescreve = presc.cd_pessoa(+)
   and ppu.cd_profissional_valida = val.cd_pessoa(+)
   and ppu.cd_profissional_cancela = canc.cd_pessoa(+)
   and FN_AEROSOL(ppu.CD_PROCEDIMENTO) = 1
   AND cd_proc_plano_pai is null
/

