create view VW_AUDITORIA_PEP as
SELECT DT_ACAO, CD_OPERADOR, CD_ACAO, DS_ACAO, ID_SESSION, NU_OPERACOES, CD_ATENDIMENTO, NU_PRESCRICAO_MEDICA, CD_TIPO_ACAO, NM_PACIENTE
FROM (SELECT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO,
             AC.CD_ACAO,
             AC.ID_SESSION,
             AC.CD_OPERADOR2 CD_OPERADOR,
             NULL CD_ATENDIMENTO,
             NULL NU_PRESCRICAO_MEDICA,
             AA.DS_ACAO,
             1 NU_OPERACOES,
             AA.CD_TIPO_ACAO,
             '' NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA
      WHERE AC.CD_ACAO      IN (1,2,3,4,5,6) AND
            AC.CD_ACAO      = AA.CD_ACAO
      UNION
      SELECT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO,
             AC.CD_ACAO,
             AC.ID_SESSION,
             AC.CD_OPERADOR2 CD_OPERADOR,
             PM.CD_ATENDIMENTO,
             PM.NU_PRESCRICAO_MEDICA,
             AA.DS_ACAO,
             1 NU_OPERACOES,
             AA.CD_TIPO_ACAO, P.NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO      IN (11,12,13) AND
            AC.CD_ACAO       = PM.CD_ACAO AND
            AC.CD_OPERADOR2  = PM.CD_OPERADOR AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PM.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            AC.ID_SESSION    = PM.ID_SESSION AND
            AA.CD_ACAO       = PM.CD_ACAO AND
            A.CD_ATENDIMENTO = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE    = A.CD_PACIENTE
      UNION
      SELECT DISTINCT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO,
             AC.CD_ACAO,
             AC.ID_SESSION,
             AC.CD_OPERADOR2 CD_OPERADOR,
             PP.CD_ATENDIMENTO,
             PM.NU_PRESCRICAO_MEDICA,
             AA.DS_ACAO,
             (SELECT COUNT(PP2.CD_MAT_MED)
                FROM AU_PRESCRICAO_PLANO PP2
               WHERE PP2.CD_ACAO      = PP.CD_ACAO AND
                     PP2.CD_OPERADOR  = PP.CD_OPERADOR AND
                     PP2.ID_SESSION   = PP.ID_SESSION AND
                     ((to_char(PP2.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(PP2.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(PP2.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) )  ) NU_OPERACOES,
--                     to_char(PP2.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') ) NU_OPERACOES,
             AA.CD_TIPO_ACAO, P.NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_PLANO PP, TB_ACOES_AUDITORIA AA, TB_PRESCRICAO_MEDICA PM, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO      IN (14,15,26,27,28,29) AND
            AC.CD_ACAO      = PP.CD_ACAO AND
            AC.CD_OPERADOR2 = PP.CD_OPERADOR AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            AC.ID_SESSION   = PP.ID_SESSION AND
            AA.CD_ACAO      = PP.CD_ACAO AND
            PM.CD_ATENDIMENTO = PP.CD_ATENDIMENTO AND
            PM.CD_OCORRENCIA_PLANO = PP.CD_OCORRENCIA_PLANO AND
            PM.CD_ORDEM_PRESCRICAO = PP.CD_ORDEM_PRESCRICAO AND
            A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE          = A.CD_PACIENTE
      UNION
      SELECT DISTINCT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO, AC.CD_ACAO, AC.ID_SESSION, AC.CD_OPERADOR2, PPU.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, AA.DS_ACAO,
             (SELECT COUNT(PPU2.CD_PROCEDIMENTO)
                FROM AU_PROCEDIMENTO_PLANO_USO PPU2
               WHERE PPU2.CD_ACAO      = PPU.CD_ACAO AND
                     PPU2.CD_OPERADOR  = PPU.CD_OPERADOR AND
                     PPU2.ID_SESSION   = PPU.ID_SESSION AND
                     ((to_char(PPU2.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(PPU2.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(PPU2.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) )  ) NU_OPERACOES,
--                     to_char(PPU2.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') ) NU_OPERACOES,
             AA.CD_TIPO_ACAO, P.NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, AU_PROCEDIMENTO_PLANO_USO PPU, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO             IN (16,17) AND
            AC.CD_ACAO             = PPU.CD_ACAO AND
            AC.CD_OPERADOR2        = PPU.CD_OPERADOR AND
            AC.ID_SESSION          = PPU.ID_SESSION AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PPU.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            PM.CD_ATENDIMENTO      = PPU.CD_ATENDIMENTO AND
            PM.CD_OCORRENCIA_PLANO = PPU.CD_OCORRENCIA_PLANO AND
            PM.CD_ORDEM_PRESCRICAO = PPU.CD_ORDEM_PRESCRICAO AND
            AA.CD_ACAO             = PPU.CD_ACAO AND
            A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE          = A.CD_PACIENTE
      UNION
      SELECT DISTINCT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO, AC.CD_ACAO, AC.ID_SESSION, AC.CD_OPERADOR2, DP.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, AA.DS_ACAO,
            (SELECT COUNT(CDP.CD_MAT_MED)
              FROM AU_DIETA_PACIENTE DP2, tb_composicao_dieta_paciente CDP
             WHERE DP2.CD_ACAO      = DP.CD_ACAO AND
                   DP2.CD_OPERADOR  = DP.CD_OPERADOR AND
                   DP2.ID_SESSION   = DP.ID_SESSION AND
                   ((to_char(DP2.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(DP2.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(DP2.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
                   CDP.CD_ATENDIMENTO = DP2.CD_ATENDIMENTO AND
                   CDP.CD_OCORRENCIA_PLANO = DP2.CD_OCORRENCIA_PLANO AND
                   CDP.CD_ORDEM_PRESCRICAO = DP2.CD_ORDEM_PRESCRICAO AND
                   CDP.CD_ORDEM_DIETA      = DP2.CD_ORDEM_DIETA) NU_OPERACOES,
             AA.CD_TIPO_ACAO, P.NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, AU_DIETA_PACIENTE DP, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO             IN (18,19) AND
            AC.CD_ACAO             = DP.CD_ACAO AND
            AC.CD_OPERADOR2        = DP.CD_OPERADOR AND
            AC.ID_SESSION          = DP.ID_SESSION AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(DP.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            PM.CD_ATENDIMENTO      = DP.CD_ATENDIMENTO AND
            PM.CD_OCORRENCIA_PLANO = DP.CD_OCORRENCIA_PLANO AND
            PM.CD_ORDEM_PRESCRICAO = DP.CD_ORDEM_PRESCRICAO AND
            AA.CD_ACAO             = DP.CD_ACAO AND
            A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE          = A.CD_PACIENTE
      UNION
      SELECT DISTINCT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO, AC.CD_ACAO, AC.ID_SESSION, AC.CD_OPERADOR2, PA.CD_ATENDIMENTO, PM.NU_PRESCRICAO_MEDICA, AA.DS_ACAO, 1 NU_OPERACOES, AA.CD_TIPO_ACAO, P.NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, AU_PRESCRICAO_ALTA PA, TB_PRESCRICAO_MEDICA PM, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO             IN (24,25) AND
            AC.CD_ACAO             = PA.CD_ACAO AND
            AC.CD_OPERADOR2        = PA.CD_OPERADOR AND
            AC.ID_SESSION          = PA.ID_SESSION AND
            ((to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PA.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO-0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PA.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'))or(to_char(AC.DT_ACAO+0.00001,'dd-mm-yyyy hh24:mi:ss') = to_char(PA.DT_ACAO,'dd-mm-yyyy hh24:mi:ss')) ) AND
--            to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') = to_char(PA.DT_ACAO,'dd-mm-yyyy hh24:mi:ss') AND
            PM.CD_ATENDIMENTO      = PA.CD_ATENDIMENTO AND
            PM.CD_OCORRENCIA_PLANO = PA.CD_OCORRENCIA_PLANO AND
            PM.CD_ORDEM_PRESCRICAO = PA.CD_ORDEM_PRESCRICAO AND
            AA.CD_ACAO             = PA.CD_ACAO AND
            A.CD_ATENDIMENTO       = PM.CD_ATENDIMENTO AND
            P.CD_PACIENTE          = A.CD_PACIENTE
      UNION
     SELECT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO,
            AC.CD_ACAO,
            AC.ID_SESSION,
            AC.CD_OPERADOR2 CD_OPERADOR,
            AC.CD_ATIVIDADE CD_ATENDIMENTO,
            NULL NU_PRESCRICAO_MEDICA,
            AA.DS_ACAO,
            1 NU_OPERACOES,
            AA.CD_TIPO_ACAO,
            P.NM_PACIENTE NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA, TB_PACIENTE P, TB_ATENDIMENTO A
      WHERE AC.CD_ACAO      IN (31,32) AND
            AC.CD_ACAO      = AA.CD_ACAO AND
            A.CD_ATENDIMENTO       = AC.CD_ATIVIDADE AND
            P.CD_PACIENTE          = A.CD_PACIENTE
      UNION
     SELECT TO_DATE(to_char(AC.DT_ACAO,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') DT_ACAO,
            AC.CD_ACAO,
            AC.ID_SESSION,
            AC.CD_OPERADOR2 CD_OPERADOR,
            NULL CD_ATENDIMENTO,
            NULL NU_PRESCRICAO_MEDICA,
            AA.DS_ACAO,
            1 NU_OPERACOES,
            AA.CD_TIPO_ACAO,
            '' NM_PACIENTE
      FROM TB_AUDIT_ACOES AC, TB_ACOES_AUDITORIA AA
      WHERE AC.CD_ACAO =30 AND
            AC.CD_ACAO      = AA.CD_ACAO
      ORDER BY 1)
/

