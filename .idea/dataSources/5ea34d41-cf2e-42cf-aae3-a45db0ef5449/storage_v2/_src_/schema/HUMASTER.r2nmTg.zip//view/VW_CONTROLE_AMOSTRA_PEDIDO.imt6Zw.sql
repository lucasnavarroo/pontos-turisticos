create view VW_CONTROLE_AMOSTRA_PEDIDO as
select pe.nu_pedido,
       pz.cd_atendimento,
       pz.cd_ocorrencia,
       pz.cd_ordem,
       p.nm_paciente,
       proc.cd_procedimento,
       nvl(ela.ds_exame,proc.nr_procedimento) nm_procedimento,
       pz.dt_inicio dt_solicitacao,
       pzp.dt_prazo_50 dt_prazo_50,
       pzp.dt_prazo_75 dt_prazo_75,
       pz.dt_prazo,
       a.cd_motivo_atendimento,
       a.cd_tipo_atendimento,
       nvl(a.fl_internacao, 'N') fl_internacao,
       (case when a.fl_internacao = 'S' then
            1
        else
          a.cd_motivo_atendimento end) cd_motivo_internacao,
       a.cd_unidade_atendimento,
       ua.nm_unidade_atendimento,
       poe.fl_ocultar_urgencia,
        nvl((select /*+ FIRST_ROWS(1) */
            1 fl_protocolo
             from tb_protocolo_exame_sa  aa,
                  tb_exame_solicitado_sa a
            where 1 = 1
                 --- Filtros
              and a.nu_pedido = pe.nu_pedido
              and a.dt_pedido = pe.dt_pedido
                 --- Joins
                 --- aa -- a
              and aa.cd_senha_master = a.cd_senha_master
              and aa.cd_atendimento = a.cd_atendimento
              and aa.cd_procedimento = a.cd_procedimento
              and aa.cd_exame = a.cd_exame
              and rownum = 1),
           0) fl_protocolo
  from tb_procedimento_oculto_emg  poe,
       tb_unidade_atendimento       ua,
       tb_procedimento            proc,
       tb_paciente                   p,
       tb_prazo_exame_percentual   pzp,
       tb_prazo_exame               pz,
       tm_atendimento                a,
       tb_pedido_exame              pe,
       tb_guia                       g,
       tb_exame_lab_apoio          ela,
       tb_procedimento_terceirizado pt,
       tb_procedimento_realizado    pr
 where 1 = 1
   and pr.cd_atendimento = pt.cd_atendimento(+)
   and pr.cd_ocorrencia = pt.cd_ocorrencia(+)
   and pr.cd_ordem = pt.cd_ordem(+)
   and pt.cd_laboratorio_apoio = ela.cd_laboratorio_apoio(+)
   and pt.cd_procedimento      = ela.cd_procedimento(+)
   and pt.cd_mnemonico_exame = ela.cd_mnemonico_exame(+)
   and pr.cd_atendimento = g.cd_atendimento
   and pr.cd_ocorrencia = g.cd_ocorrencia
   and g.cd_atendimento = pe.cd_atendimento
   and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = a.cd_atendimento
   and pr.cd_atendimento = pz.cd_atendimento
   and pr.cd_ocorrencia = pz.cd_ocorrencia
   and pr.cd_ordem = pz.cd_ordem
   and pz.cd_atendimento = pzp.cd_atendimento
   and pz.cd_ocorrencia = pzp.cd_ocorrencia
   and pz.cd_ordem = pzp.cd_ordem
   and a.cd_paciente = p.cd_paciente
   and pr.cd_procedimento = proc.cd_procedimento
   and a.cd_unidade_atendimento = ua.cd_unidade_atendimento
   and pr.cd_procedimento = poe.cd_procedimento
   and pr.dt_libera_laudo is null
   and proc.fl_tipo_exame||'' in (0,1)
/

