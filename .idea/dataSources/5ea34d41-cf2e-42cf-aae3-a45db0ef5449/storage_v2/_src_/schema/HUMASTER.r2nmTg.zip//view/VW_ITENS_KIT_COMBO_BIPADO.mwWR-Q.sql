create view VW_ITENS_KIT_COMBO_BIPADO as
select /*
          Fred Monteiro - IVIA - 18/06/2018
          View que contem os itens que foram bipados nos combos cirurgicos
       */
       a.cd_agenda,
       a.dt_agenda,
       a.dt_nascimento,
       a.cd_paciente,
       a.idade_meses,
       a.cd_material,
       sum(aa.qt_material) qt_produto,
       a.cd_ato_cirurgico,
       a.id_kit,
       a.cd_setor_controle
  from    tb_item_kit_cirurgia_lote aa,
       vw_itens_kit_combo_padrao    a
 where 1 = 1
   and aa.cd_codigo_barra is not null
   -- join a -- aa
   and a.id_kit      = aa.id_kit
   and a.cd_material = aa.cd_material_original
 group by a.cd_agenda,
          a.dt_agenda,
          a.dt_nascimento,
          a.cd_paciente,
          a.idade_meses,
          a.cd_material,
          a.cd_ato_cirurgico,
          a.id_kit,
          a.cd_setor_controle
/

