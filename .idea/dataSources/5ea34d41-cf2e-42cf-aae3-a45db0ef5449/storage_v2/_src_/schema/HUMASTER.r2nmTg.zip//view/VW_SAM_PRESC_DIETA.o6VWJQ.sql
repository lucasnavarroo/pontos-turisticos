create view VW_SAM_PRESC_DIETA as
select d.cd_atendimento,
       d.cd_ocorrencia_plano,
       d.cd_ordem_prescricao,
       d.CD_ORDEM_DIETA,
       d.CD_DIETA,
       d.NU_FREQUENCIA,
       d.FL_BOMBA_INFUSAO,
       d.FL_ROTINA_RG,
       d.FL_ENTEROFIX,
       d.FL_EQUIPO_BOMBA,
       d.QT_GOTEJAMENTO,
       d.CD_GOTEJAMENTO,
       d.QT_TEMPO_GOTEJ,
       d.CD_UNIDADE_GOTEJ,
       d.DS_OBSERVACAO,
       d.FL_VALIDADO,
       d.FL_STATUS_USO,
       die.nm_dieta,
       d.cd_tipo_acesso,
       presc.nm_fantasia   prof_prescritor,
       val.nm_fantasia     prof_validador,
       canc.nm_fantasia    prof_cancelador
  from tb_dieta_paciente d, tb_dieta die, tb_pessoa presc, tb_pessoa val, tb_pessoa canc
 where d.cd_dieta = die.cd_dieta and d.cd_profissional_prescreve = presc.cd_pessoa(+)
   and d.cd_profissional_valida = val.cd_pessoa(+)
   and d.cd_profissional_cancela = canc.cd_pessoa(+)
/

