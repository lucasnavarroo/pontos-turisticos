create view VW_FILA_COLETA as
    select /*+ choose */
         lat.cd_local_atendimento cd_local_atendimento,
         o.cd_senha_master,
         o.cd_grupo_atendimento,
         o.cd_senha_atendimento,
         o.dt_geracao_senha,
         o.fl_tipo_senha,
         o.cd_atendimento,
         o.dt_inicio_cadastro,
         o.dt_fim_cadastro,
         o.cd_operador_cadastro,
         substr(cp.nu_carteira_convenio, 1, 14) cd_usuario,
         o.cd_operador_inicio,
         o.dt_inicio_atendimento,
         o.cd_operador_fim,
         o.dt_fim_atendimento,
         o.fl_status,
         o.cd_ponto_atendimento_cad,
         o.cd_ponto_atendimento_ate,
         o.fl_toca_som,
         nvl(p.nm_social, p.nm_paciente) nm_paciente,
         o.vl_idade,
         o.cd_paciente,
         decode(o.fl_prioridade, 1, 'U', null) fl_prioridade,
         decode(o.dt_fim_consulta_pac_obs,
                null,
                decode(o.dt_fim_cadastro,
                       null,
                       o.dt_inicio_cadastro,
                       o.dt_fim_cadastro),
                o.dt_fim_consulta_pac_obs) dt_fim_consulta_pac_obs,
         o.cd_terminal,
         o.dt_ordem,
         o.nm_operador_obs_retorno,
         o.cd_senha_master_uni,
         o.ds_obs_enfermagem,
         sysdate - decode(dt_fim_consulta_pac_obs,
                          null,
                          dt_inicio_atendimento,
                          dt_fim_consulta_pac_obs) qt_tempo_espera,
         a.cd_motivo_atendimento,
         a.cd_medico_atendente,
         o.dt_cancela_chamada,
         o.fl_triagem,
         o.cd_nivel_classificacao_risco,
         o.dt_lib_guia,
         o.fl_status_anterior,
         decode(fn_classif_risco_paciente(a.cd_atendimento),
                'emergencia',
                3,
                'urgencia',
                2,
                'nao_urgencia',
                1,
                null) cd_nivel_classif_risco_medico,
         (select nvl(min(cd_prioridade), 9)
            from tb_exame_solicitado_sa sa ,
                tb_procedimento         pro
           where sa.dt_importacao               is null
             and sa.dt_coleta_cancelada         is null
             and nvl(sa.fl_exame_cancelado, 'N') = 'N'
             and sa.cd_senha_master              = o.cd_senha_master
             and sa.cd_atendimento               = o.cd_atendimento
             and pro.cd_procedimento             = sa.cd_procedimento
             and pro.fl_tipo_exame               = 2  )cd_prioridade_imagem
    from tb_local_atendimento_sa lat,
         tb_local_atendimento_sa l,
         tb_convenio_pagador     cp,
         tb_paciente             p,
         tm_atendimento          a,
         tb_senha_atendimento_sa o
   where o.dt_geracao_senha                 >= trunc(sysdate)- 3
     and o.dt_geracao_senha                 >= trunc(sysdate)- nvl(l.qt_dias_coleta,1)
     and o.fl_status                        in (4, 5, 10)
     and a.cd_atendimento                   = o.cd_atendimento
     and p.cd_paciente                      = a.cd_paciente
     and a.dt_fim_atendimento               is null
     and cp.cd_atendimento                  = a.cd_atendimento
     and cp.cd_convenio_pagador             = 1
     and l.cd_local_atendimento             = o.cd_local_atendimento
     and lat.cd_setor                       = l.cd_local_realiza_exame_vi
     and exists
         (select a.cd_atendimento
            from tb_local_grupo_proced_sa g,
                 tb_grupo_atendimento_sa  gcp,
                 tb_local_atendimento_sa  lat,
                 tb_local_atendimento_sa  l,
                 tb_procedimento          p,
                 tb_exame_solicitado_sa   a
           where a.cd_senha_master              = o.cd_senha_master
             and a.cd_atendimento               = o.cd_atendimento
             and a.dt_importacao                is null
             and nvl(a.fl_exame_cancelado, 'N') = 'N'
             and p.cd_procedimento              = a.cd_procedimento
             and p.fl_tipo_exame                = 2
             and lat.cd_setor                   = l.cd_local_realiza_exame_vi
             and gcp.cd_local_atendimento       = lat.cd_local_atendimento
             and gcp.cd_grupo_procedimento      = 3
             and g.cd_grupo_atendimento         = gcp.cd_grupo_atendimento
             and g.cd_local_atendimento         = gcp.cd_local_atendimento
             and g.cd_grupo_procedimento        = p.cd_grupo_procedimento
             and gcp.cd_setor_grupo             is not null
             --and rownum = 1
             )
   union all
  select /*+ choose */
         g.cd_local_atendimento cd_local_atendimento,
         o.cd_senha_master,
         o.cd_grupo_atendimento,
         o.cd_senha_atendimento,
         o.dt_geracao_senha,
         o.fl_tipo_senha,
         o.cd_atendimento,
         o.dt_inicio_cadastro,
         o.dt_fim_cadastro,
         o.cd_operador_cadastro,
         o.cd_usuario,
         o.cd_operador_inicio,
         o.dt_inicio_atendimento,
         o.cd_operador_fim,
         o.dt_fim_atendimento,
         o.fl_status,
         o.cd_ponto_atendimento_cad,
         o.cd_ponto_atendimento_ate,
         o.fl_toca_som,
         nvl(p.nm_social, p.nm_paciente) nm_paciente,
         o.vl_idade,
         o.cd_paciente,
         decode(o.fl_prioridade, 1, 'U', null) fl_prioridade,
         decode(o.dt_fim_consulta_pac_obs,
                null,
                decode(o.dt_fim_cadastro,
                       null,
                       o.dt_inicio_cadastro,
                       o.dt_fim_cadastro),
                o.dt_fim_consulta_pac_obs) dt_fim_consulta_pac_obs,
         o.cd_terminal,
         o.dt_ordem,
         o.nm_operador_obs_retorno,
         o.cd_senha_master_uni,
         o.ds_obs_enfermagem,
         sysdate - decode(dt_fim_consulta_pac_obs,
                          null,
                          dt_inicio_atendimento,
                          dt_fim_consulta_pac_obs) qt_tempo_espera,
         a.cd_motivo_atendimento,
         a.cd_medico_atendente,
         o.dt_cancela_chamada,
         o.fl_triagem,
         o.cd_nivel_classificacao_risco,
         o.dt_lib_guia,
         o.fl_status_anterior,
         decode(fn_classif_risco_paciente(a.cd_atendimento),
                'emergencia',
                3,
                'urgencia',
                2,
                'nao_urgencia',
                1,
                null) cd_nivel_classif_risco_medico,
         null
    from tb_local_atendimento_sa  l,
         tb_paciente              p,
         tm_atendimento           a,
         tb_locais_agrupamento_sa g,
         tb_senha_atendimento_sa  o
   where dt_geracao_senha >= trunc(sysdate) - 3
     and dt_geracao_senha        >= trunc(sysdate)- nvl(l.qt_dias_coleta,1)
     and fl_status in (4, 5, 10)
     and g.cd_local_agrupamento  = o.cd_local_atendimento
     and a.cd_atendimento        = o.cd_atendimento
     and p.cd_paciente           = a.cd_paciente
     and a.dt_fim_atendimento    is null
     and l.cd_local_atendimento  = o.cd_local_atendimento
     and l.cd_local_realiza_exame_vi is null
     and exists
         (select a.cd_atendimento
            from tb_local_grupo_proced_sa g,
                 tb_grupo_atendimento_sa  gcp,
                 tb_local_atendimento_sa  lat,
                 tb_local_atendimento_sa  l,
                 tb_procedimento          p,
                 tb_exame_solicitado_sa   a
           where a.cd_senha_master              = o.cd_senha_master
             and a.cd_atendimento               = o.cd_atendimento
             and a.dt_importacao is null
             and nvl(a.fl_exame_cancelado, 'N') = 'N'
             and p.cd_procedimento              = a.cd_procedimento
             and p.fl_tipo_exame                = 2
             and lat.cd_setor                   = l.cd_local_realiza_exame_vi
             and gcp.cd_local_atendimento       = lat.cd_local_atendimento
             and gcp.cd_grupo_procedimento      = 3
             and g.cd_grupo_atendimento         = gcp.cd_grupo_atendimento
             and g.cd_local_atendimento         = gcp.cd_local_atendimento
             and g.cd_grupo_procedimento        = p.cd_grupo_procedimento
             and gcp.cd_setor_grupo             is not null
            -- and rownum = 1
             )
/

