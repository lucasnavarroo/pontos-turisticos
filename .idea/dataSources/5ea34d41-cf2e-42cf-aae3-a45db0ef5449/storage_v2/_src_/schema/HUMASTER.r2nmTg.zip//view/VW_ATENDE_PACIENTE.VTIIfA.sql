create view VW_ATENDE_PACIENTE as
select  tb_paciente.cd_paciente,
	tb_paciente.nm_paciente,
	tb_paciente.dt_nascimento,
	tb_paciente.nm_mae,
	rowidtochar(tb_paciente.rowid) ri_paciente,
	tb_atendimento.cd_atendimento,
	tb_atendimento.fl_internacao,
	tb_atendimento.dt_atendimento,
	rowidtochar(tb_atendimento.rowid) ri_atendimento
from tb_atendimento,tb_paciente
where   tb_atendimento.cd_paciente = tb_paciente.cd_paciente
/

