create view VW_IMPOSTO_RENDA as
select "DT_MES","CD_FAIXA","VL_INICIAL","VL_FINAL","PC_ALIQUOTA","VL_DEDUCAO"
     from tb_imposto_renda@hapvida
/

