create view VIM_PESSOA as
SELECT DISTINCT   
          p.cd_pessoa + 500000000 id_pessoa,   
          p.nm_pessoa_razao_social   nome,   
       DECODE(c.cd_tipo_cedente_sacado,0,  SUBSTR(p.nm_fantasia,1,10) || '-' ||TO_CHAR(p.cd_pessoa + 500000000) , -- cliente   
                                    12, SUBSTR(p.nm_fantasia,1,10) || '-' ||TO_CHAR(p.cd_pessoa + 500000000) , -- cliente   
                'F-' || TO_CHAR(p.cd_pessoa + 500000000)) apelido, -- fornecedor   
    SUBSTR(ep.cd_tipo_logradouro||' '||   
       ep.nm_rua_endereco ||' '||   
    TO_CHAR(ep.nu_endereco)||' '||   
    ep.ds_compl_enderero,1,65) ender,   
    SUBSTR(ep.nm_bairro_endereco,1,30) bairro,   
    ep.cd_cep_endereco cep,   
    NVL(SUBSTR(ep.nm_cidade_endereco,1,30),'FORTALEZA') municipio,   
    NVL(ep.cd_uf_endereco,'CE')  cod_uf,   
    'BRASIL' pais,   
    '' inscri_munic,   
    'S' ind_ativa,   
    mt.nu_meio_comunicacao tel,   
    '' fax,   
    SUBSTR(p.nm_pessoa_razao_social,1,30) contato,   
    'O' cod_classif_pessoa,   
    DECODE(p.fl_tipo_pessoa,1,'F','J')cod_tipo_pessoa,   
    c.dt_ultima_transacao dt_cadastro,   
    null cod_tipo_ocupacao,
    null num_pis_pasep_ci,
    null e_mail,
--  Pessoa Fisica  --   
    NULL num_classe_salario_base,   
    DECODE(p.fl_tipo_pessoa,1,LPAD(TO_CHAR(p.nu_cgc_cpf), 11, '0'),'') cpf,   
    0 qtd_dependentes,   
    DECODE(p.fl_tipo_pessoa,1,'A','') cod_classif_pessoa_fisica,   
    '' num_chapa,   
    DECODE(p.fl_tipo_pessoa,1,'S','') ind_dispensa_recol_inss,   
    DECODE(p.fl_tipo_pessoa,1,'0','') num_inscr_inss,   
    DECODE(p.fl_tipo_pessoa,1,'N','') ind_deducao_dependente_irrf,   
    null inscr_estadual_fis,
--  Pessoa Juridica  --   
    DECODE(p.fl_tipo_pessoa,2,LPAD(TO_CHAR(p.nu_cgc_cpf),14,'0'),'') cgc,   
    DECODE(p.fl_tipo_pessoa,2,nu_ident_insc_est,'0') inscr_estadual,   
    0 num_reg_junta_comercial,   
    TO_DATE('01011980','ddmmyyyy') dt_reg_junta_comercial,   
    'E' cod_classif_pessoa_juridica,   
    '' cod_condicao_pagto_padrao,   
    'S' ind_dispensa_calculo_inss_ret,   
--  Fornecedor  --   
    DECODE(c.cd_tipo_cedente_sacado,1,'S',   
                                    2,'S',   
                                    4,'S',   
                                    5,'S',   
                                    6,'S',   
                                    8,'S',   
              'N') ind_forncd,   
    '' apelido_filial_padrao,   
    0 cod_centro_custo_padrao,   
    '' cod_projeto_padrao_forncd,   
    '' cod_produto_servico_padrao,   
    '' cod_conta_contabil_padrao,   
    '' num_bacen_padrao,   
    '' num_bacen_cc_padrao,   
    '' num_agencia_cc_padrao,   
    '' num_cc_padrao,   
    '' cod_liqdc_financ_padrao,   
    'N' ind_calculo_irrf_baixo,   
    '' cod_condicao_pagto_padrao_forn,   
    0 fpas,   
--  Cliente  --   
    DECODE(c.cd_tipo_cedente_sacado,0, 'S',   
                                    12,'S',   
                'N') ind_cliente,   
    NVL(ep.cd_uf_endereco,'CE') cod_uf_cobranca,   
    '' cod_unidade_negocio,   
    '' cod_grupo_contabil_padrao,   
    '' cod_projeto_padrao_cliente,   
    '' cod_produto_servico_padrao_cli,   
   SUBSTR(ep.cd_tipo_logradouro||' '||   
           ep.nm_rua_endereco||' '||   
          TO_CHAR(ep.nu_endereco)||' '||   
          ep.ds_compl_enderero,1,60) ender_cobranca,   
    ep.cd_cep_endereco cep_cobranca,   
    NVL(SUBSTR(ep.nm_cidade_endereco,1,30),'FORTALEZA') municipio_cobranca,   
    'BRASIL' pais_cobranca,   
    '' cod_classif_cliente,   
    0 cod_sit_cliente,   
    '' cod_regiao,   
    0 vlr_limite_compra,   
    0 vlr_limite_credito,   
    '' cod_condicao_pagto_padrao_cli,   
    '' bairro_cobranca   
     FROM TB_MEIO_COMUNICACAO_PESSOA mt,   
          TB_ENDERECO_PESSOA ep,   
        TB_PESSOA p,   
         TB_CEDENTE_SACADO c   
    WHERE c.cd_tipo_cedente_sacado IN (0, 1, 2, 4, 5, 6,7,8,9, 10,12)   
   AND p.cd_pessoa = c.cd_pessoa   
   AND ep.cd_pessoa(+) = p.cd_pessoa   
   AND ep.fl_tipo_endereco(+) = DECODE(p.fl_tipo_pessoa,1,'1','2')   
   AND mt.cd_pessoa(+) = p.cd_pessoa   
      AND mt.cd_tipo_meio_comunicacao(+) = 1   
      AND mt.cd_ordem_meio_comunicacao(+) = 1
/

