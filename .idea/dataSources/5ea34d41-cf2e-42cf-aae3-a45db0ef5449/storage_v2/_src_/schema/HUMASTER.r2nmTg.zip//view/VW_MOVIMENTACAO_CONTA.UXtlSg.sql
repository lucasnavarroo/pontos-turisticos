create view VW_MOVIMENTACAO_CONTA as
    select decode(tc.fl_tipo_classificacao, 1, 'MEDICAMEMTO', 'MATERIAL') cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         n.cd_setor_destino cd_posto,
         n.dt_comanda,
         n.nu_comanda,
         s.nm_setor,
         n.cd_ocorrencia,
         cp.cd_convenio_base cd_convenio_pagador,
         pc.nm_fantasia nm_convenio,
         ct.ds_fl_tipo_classificacao,
         m.cd_mat_med cd_item,
         fn_ds_mat_med(m.cd_mat_med, sysdate) ds_item,
         --       d.nm_mat_med||' '||d.cd_apresentacao||' '||to_char(d.qt_conteudo)||d.cd_unidade ds_item,
         m.qt_material qt_item,
         m.qt_entregue + nvl(qt_devolvido, 0) qt_item_entregue,
         m.vl_material vl_item,
         m.vl_total vl_total_item,
         m.cd_cobranca,
         a.cd_tipo_atendimento,
         n.fl_requisicao_devolucao,
         m.cd_ordem,
         m.cd_ordem_cmd,
         m.cd_ordem_m,
         g.nu_guia,
         substr(fu_procedimento_guia(a.cd_atendimento,
                                     n.cd_ocorrencia,
                                     m.cd_ordem,
                                     n.dt_comanda),
                1,
                8) cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         m.cd_natureza_glosa,
         m.cd_ocorrencia_pacote,
         m.cd_item_hapvida
    from tb_mat_med                   d,
         tb_tipo_classificacao        tc,
         tb_classe_tipo_classificacao ct,
         tb_classificacao             c,
         tb_pessoa                    pc,
         tm_setor                     s,
         tb_convenio                  e,
         tb_paciente                  p,
         tb_convenio_pagador          cp,
         tb_guia                      g,
         tb_atendimento               a,
         tb_comanda                   n,
         tb_comanda_mat_med           m
   where n.cd_atendimento = m.cd_atendimento
     and n.cd_ocorrencia = m.cd_ocorrencia
     and n.cd_ordem = m.cd_ordem
     and n.cd_ordem_cmd = m.cd_ordem_cmd
     and n.fl_requisicao_devolucao in (1, 3, 5)
     and a.cd_atendimento = n.cd_atendimento
     and g.cd_atendimento = a.cd_atendimento
     and g.cd_ocorrencia = m.cd_ocorrencia
     and p.cd_paciente = a.cd_paciente
     and s.cd_setor(+) = n.cd_setor_destino
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
     and d.cd_mat_med = m.cd_mat_med
     and c.cd_classificacao = d.cd_classificacao
     and tc.cd_tipo_classificacao = c.cd_tipo_classificacao
     and ct.fl_tipo_classificacao = tc.fl_tipo_classificacao
     and cp.cd_atendimento = n.cd_atendimento
     and cp.cd_convenio_pagador = m.cd_convenio_pagador
     and e.cd_convenio = cp.cd_convenio_base
     and pc.cd_pessoa = e.cd_pessoa
  union all
  select 'TAXA' cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         n.cd_setor_destino cd_posto,
         n.dt_comanda,
         n.nu_comanda,
         s.nm_setor,
         n.cd_ocorrencia,
         cp.cd_convenio_base cd_convenio_pagador,
         pc.nm_fantasia,
         g.nm_grupo_taxas,
         to_number(nvl(txc.cd_taxas_convenio, 0)),
         d.nr_taxas,
         m.qt_taxa,
         m.qt_taxa,
         m.vl_taxa,
         m.vl_total,
         m.cd_cobranca,
         a.cd_tipo_atendimento,
         n.fl_requisicao_devolucao,
         m.cd_ordem,
         m.cd_ordem_cmd,
         m.cd_ordem_tx,
         g.nu_guia,
         substr(fu_procedimento_guia(a.cd_atendimento,
                                     n.cd_ocorrencia,
                                     m.cd_ordem,
                                     n.dt_comanda),
                1,
                8) cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         m.cd_natureza_glosa,
         m.cd_ocorrencia_pacote,
         m.cd_item_hapvida
    from tb_grupo_taxas      g,
         tb_taxas            d,
         tb_pessoa           pc,
         tb_convenio         e,
         tm_setor            s,
         tb_paciente         p,
         tb_guia             g,
         tb_atendimento      a,
         tb_taxas_convenio   txc,
         tb_convenio_pagador cp,
         tb_comanda          n,
         tb_comanda_taxa     m
   where n.cd_atendimento = m.cd_atendimento
     and n.cd_ocorrencia = m.cd_ocorrencia
     and n.cd_ordem = m.cd_ordem
     and n.cd_ordem_cmd = m.cd_ordem_cmd
     and n.fl_requisicao_devolucao in (1, 3, 5)
     and a.cd_atendimento = m.cd_atendimento
     and g.cd_atendimento = a.cd_atendimento
     and g.cd_ocorrencia = m.cd_ocorrencia
     and p.cd_paciente = a.cd_paciente
     and s.cd_setor(+) = n.cd_setor_destino
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
     and d.cd_taxas = m.cd_taxas
     and cp.cd_atendimento = n.cd_atendimento
     and cp.cd_convenio_pagador = m.cd_convenio_pagador
     and txc.cd_convenio(+) = cp.cd_convenio_base
     and txc.cd_plano_convenio(+) = cp.cd_plano_base
     and txc.cd_taxas = m.cd_taxas
     and e.cd_convenio = cp.cd_convenio_base
     and pc.cd_pessoa = e.cd_pessoa
     and g.cd_grupo_taxas = d.cd_grupo_taxas
  union all
  select 'PABX' cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         a.cd_setor cd_posto,
         a.dt_atendimento,
         '0',
         s.nm_setor,
         n.cd_ocorrencia,
         fn_convenio_particular,
         'UNIPAR',
         'PABX',
         0,
         'LIGACOES TELEFONICAS',
         0,
         0,
         m.vl_custo,
         m.vl_custo,
         m.cd_cobranca,
         a.cd_tipo_atendimento,
         3,
         n.cd_ordem,
         0,
         0,
         g.nu_guia,
         substr(fu_procedimento_guia(a.cd_atendimento,
                                     n.cd_ocorrencia,
                                     m.cd_ordem,
                                     n.dt_procedimento_realizado),
                1,
                8) cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         '0',
         null,
         null
    from tm_setor                  s,
         tb_paciente               p,
         tb_guia                   g,
         tb_atendimento            a,
         tb_procedimento_realizado n,
         tb_comanda_pabx           m
   where n.cd_atendimento = m.cd_atendimento
     and n.cd_ocorrencia = m.cd_ocorrencia
     and n.cd_ordem = m.cd_ordem
     and a.cd_atendimento = m.cd_atendimento
     and g.cd_atendimento = a.cd_atendimento
     and g.cd_ocorrencia = m.cd_ocorrencia
     and p.cd_paciente = a.cd_paciente
     and s.cd_setor = a.cd_setor
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
  union all
  select 'RESTAURANTE' cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         m.cd_setor_atendimento cd_posto,
         m.dt_comanda,
         m.nu_comanda_restaurante nu_comanda,
         s.nm_setor,
         m.cd_ocorrencia,
         fn_convenio_particular,
         'UNIPAR',
         'CONSUMO RESTAURANTE',
         i.cd_material,
         fn_ds_mat_med(i.cd_material, sysdate) ds_item,
         --       d.nm_mat_med,
         i.qt_comanda,
         i.qt_comanda,
         1.1 * i.vl_comanda,
         1.1 * i.vl_comanda,
         m.cd_cobranca,
         a.cd_tipo_atendimento,
         3,
         0,
         0,
         0,
         g.nu_guia,
         '99999999 ' cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         '0',
         null,
         null
    from tm_setor               s,
         tb_paciente            p,
         tb_mat_med             d,
         tb_guia                g,
         tb_atendimento         a,
         tb_item_restaurante    i,
         tb_comanda_restaurante m
   where a.cd_atendimento = m.cd_atendimento
     and g.cd_atendimento = a.cd_atendimento
     and g.cd_ocorrencia = m.cd_ocorrencia
     and i.cd_comanda_restaurante = m.nu_comanda_restaurante
     and i.nu_ocorrencia = m.cd_ocorrencia
     and d.cd_mat_med = i.cd_material
     and p.cd_paciente = a.cd_paciente
     and s.cd_setor = m.cd_setor_atendimento
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
  union all
  select 'EXAME' cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         substr(fu_posto_pac_internado_exame(a.cd_atendimento,
                                             pr.dt_procedimento_realizado,
                                             pr.hr_procedimento_realizado),
                1,
                6) cd_posto,
         nvl(pr.dt_procedimento_realizado, a.dt_atendimento) dt_comanda,
         '0',
         s.nm_setor,
         pr.cd_ocorrencia,
         cp.cd_convenio_base cd_convenio_pagador,
         pc.nm_fantasia,
         'PROCEDIMENTOS REALIZADOS',
         to_number(nvl(pcon.cd_procedimento_convenio, 0)),
         d.nr_procedimento,
         nvl(pr.qt_procedimento, 0),
         nvl(pr.qt_procedimento, 0),
         nvl(pr.vl_procedimento, 0),
         nvl(pr.vl_total, 0),
         prc.cd_cobranca,
         a.cd_tipo_atendimento,
         3,
         pr.cd_ordem,
         0,
         0,
         g.nu_guia,
         substr(fu_procedimento_guia(a.cd_atendimento,
                                     pr.cd_ocorrencia,
                                     pr.cd_ordem,
                                     pr.dt_procedimento_realizado),
                1,
                8) cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         pr.cd_natureza_glosa,
         pr.cd_ocorrencia_pacote,
         d.cd_procedimento
    from tb_procedimento            d,
         tm_setor                   s,
         tb_pessoa                  pc,
         tb_convenio                e,
         tb_paciente                p,
         tb_procedimento_convenio   pcon,
         tb_convenio_pagador        cp,
         tb_atendimento             a,
         tb_guia                    g,
         tb_proc_realizado_cobranca prc,
         tb_procedimento_realizado  pr
   where g.cd_atendimento = pr.cd_atendimento
     and pr.cd_procedimento not in ('99995555',
                                    '99997777',
                                    '99998888',
                                    '99999999',
                                    '00030015',
                                    '10103015',
                                    '00030031',
                                    '10103023')
     and nvl(pr.vl_procedimento, 0) > 0
     and prc.cd_atendimento(+) = pr.cd_atendimento
     and prc.cd_ocorrencia(+) = pr.cd_ocorrencia
     and prc.cd_ordem(+) = pr.cd_ordem
     and d.fl_cirurgia not in (1)
     and g.cd_atendimento = pr.cd_atendimento
     and g.cd_ocorrencia = pr.cd_ocorrencia
     and a.cd_atendimento = g.cd_atendimento
     and (
           (
                 pr.cd_pessoa_cobra = fn_pessoa_unidade
             and a.cd_unidade_atendimento not in ('009')
           )
           or
           (
                 pr.cd_pessoa_cobra in (fn_pessoa_unidade, 4251)
             and a.cd_unidade_atendimento in ('009')
           )
         )
     and p.cd_paciente = a.cd_paciente
     and d.cd_procedimento = pr.cd_procedimento
     and (
           (
                 d.cd_grupo_procedimento in ('25', '201')
             and nvl(d.fl_tipo_exame, 0) = 4
           ) --> proc/consulta
           or
           (
             d.cd_grupo_procedimento not in ('25', '201')
           )
         )
     and cp.cd_atendimento = pr.cd_atendimento
     and cp.cd_convenio_pagador = g.cd_convenio_pagador
     and pcon.cd_convenio(+) = cp.cd_convenio_base
     and pcon.cd_plano_convenio(+) = cp.cd_plano_base
     and pcon.cd_procedimento = pr.cd_procedimento
     and e.cd_convenio = cp.cd_convenio_base
     and pc.cd_pessoa = e.cd_pessoa
     and s.cd_setor = substr(fu_posto_pac_internado_exame(a.cd_atendimento,
                                                          pr.dt_procedimento_realizado,
                                                          pr.hr_procedimento_realizado),
                             1,
                             6)
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
     and not exists (select 'X'
                       from tb_prof_proced_realizado x
                      where x.cd_atendimento = pr.cd_atendimento
                        and x.cd_ocorrencia = pr.cd_ocorrencia
                        and x.cd_ordem = pr.cd_ordem
                        and x.cd_procedimento = pr.cd_procedimento
                        and x.fl_honorario = 'S')
  union all
  select 'HONORARIO' cd_tipo_movimento,
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         substr(fu_posto_pac_internado_exame(a.cd_atendimento,
                                             pr.dt_procedimento_realizado,
                                             pr.hr_procedimento_realizado),
                1,
                6) cd_posto,
         nvl(pr.dt_procedimento_realizado, a.dt_atendimento) dt_comanda,
         '0',
         s.nm_setor,
         pr.cd_ocorrencia,
         cp.cd_convenio_base cd_convenio_pagador,
         pc.nm_fantasia,
         'HONORARIOS MEDICOS',
         to_number(pr.cd_procedimento),
         --prof.nm_fantasia||' '||pf.cd_conselho||'/'||pf.cd_uf_conselho||' '||pf.cd_crm_profissional,
         --substr(d.nr_procedimento,1,30)||' Hr: '||
         ' Hora: ' ||
         substr(to_char(trunc(pr.hr_procedimento_realizado / 3600, 0)) || ':' ||
                substr(to_char(trunc((pr.hr_procedimento_realizado -
                                     trunc(pr.hr_procedimento_realizado / 3600,
                                            0)) / 60,
                                     0)),
                       1,
                       2),
                1,
                5) || ' - ' || substr(prof.nm_fantasia, 1, 26) ||
         ' Ato: ' || substr(t.nm_tipo_ato_profissional, 1, 17) ||
         decode(ppr.fl_incidiu_uso, 'S', ' (+ UCO )', null) ds_item,
         pr.qt_procedimento,
         pr.qt_procedimento,
         ppr.vl_honorario_prof,
         ppr.vl_honorario_prof,
         prc.cd_cobranca,
         a.cd_tipo_atendimento,
         3,
         pr.cd_ordem,
         ppr.cd_tipo_ato_profissional cd_ordem_cmd,
         0,
         g.nu_guia,
         substr(fu_procedimento_guia(a.cd_atendimento,
                                     pr.cd_ocorrencia,
                                     pr.cd_ordem,
                                     pr.dt_procedimento_realizado),
                1,
                8) cd_procedimento_guia,
         s.fl_centro_cirurgico,
         s.fl_hemodinamica,
         s.fl_uti,
         ppr.cd_natureza_glosa,
         ppr.cd_ocorrencia_pacote,
         pr.cd_proc_hapvida
    from tb_tipo_ato_profissional   t,
         tb_procedimento            d,
         tm_setor                   s,
         tb_pessoa                  pc,
         tb_pessoa                  prof,
         tb_profissional            pf,
         tb_convenio                e,
         tb_paciente                p,
         tb_convenio_pagador        cp,
         tb_atendimento             a,
         tb_guia                    g,
         tb_proc_realizado_cobranca prc,
         tb_prof_proced_realizado   ppr,
         tb_procedimento_realizado  pr
   where ppr.cd_atendimento = pr.cd_atendimento
     and pr.cd_procedimento not in ('99995555', '99997777', '99998888', '99999999')
     and ppr.cd_atendimento = pr.cd_atendimento
     and ppr.cd_ocorrencia = pr.cd_ocorrencia
     and ppr.cd_ordem = pr.cd_ordem
     and prc.cd_atendimento(+) = ppr.cd_atendimento
     and prc.cd_ocorrencia(+) = ppr.cd_ocorrencia
     and prc.cd_ordem(+) = ppr.cd_ordem
     and ppr.fl_honorario = 'S'
     and d.cd_procedimento = pr.cd_procedimento
     and g.cd_atendimento = pr.cd_atendimento
     and g.cd_ocorrencia = pr.cd_ocorrencia
     and a.cd_atendimento = g.cd_atendimento
     and (
           (
                 pr.cd_pessoa_cobra = fn_pessoa_unidade
             and a.cd_unidade_atendimento not in ('009')
           )
           or
           (
                 pr.cd_pessoa_cobra in (fn_pessoa_unidade, 4251)
             and a.cd_unidade_atendimento in ('009')
           )
         )
     and p.cd_paciente = a.cd_paciente
     and cp.cd_atendimento = pr.cd_atendimento
     and cp.cd_convenio_pagador = g.cd_convenio_pagador
     and e.cd_convenio = cp.cd_convenio_base
     and pc.cd_pessoa = e.cd_pessoa
     and s.cd_setor = substr(fu_posto_pac_internado_exame(a.cd_atendimento,
                                                          pr.dt_procedimento_realizado,
                                                          pr.hr_procedimento_realizado),
                             1,
                             6)
     and s.cd_unidade_atendimento = a.cd_unidade_atendimento
     and prof.cd_pessoa = ppr.cd_profissional
     and prof.cd_pessoa = pf.cd_profissional
     and t.cd_tipo_ato_profissional = ppr.cd_tipo_ato_profissional
/

