create view VW_PROCEDIMENTO_NAO_COBERTO_HV as
select "CD_PLANO","CD_PROCEDIMENTO" from tb_procedimento_nao_coberto@hapvida
/

