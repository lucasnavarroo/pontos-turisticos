create view VW_CST_MODELO as
select "CD_MODELO","NM_MODELO","CD_OCORRENCIA_PROCEDIMENTO","CD_PROCEDIMENTO","NM_PROCEDIMENTO","CD_TIPO_ITEM","NM_TIPO_ITEM","QTD_ITEM","TOTAL"
  from (/*Itens OPME*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item, sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
           and a.cd_tipo_item = 10
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item
        union all
        /*Itens de Kit Cirúrgico*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item, sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
           and a.cd_tipo_item = 11
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item
        union all
        /*Itens Prescrição*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item, sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
           and a.cd_tipo_item = 12
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item
        union all
        /*Exames de Laboratório*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item, sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
           and a.cd_tipo_item = 13
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item
        union all
        /*Exames de Imagem*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item, sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
           and a.cd_tipo_item = 14
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, a.cd_tipo_item, a.nm_tipo_item
        union all
        /*Total*/
        select a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento, 99, 'TOTAL', sum(a.qtd_item) qtd_item, sum(a.total) total
          from vw_itens_modelo a
         where 1 = 1
         group by a.cd_modelo, a.nm_modelo, a.cd_ocorrencia_procedimento, a.cd_procedimento, a.nm_procedimento) a
 where 1 = 1
/

