create view VW_ATENDIMENTO_QUEIMADO as
select  a.cd_atendimento,
	a.cd_paciente,
	p.nm_paciente,
	a.dt_atendimento,
	a.fl_internacao,
	d.cd_diagnostico,
	c.nr_cid,
	d.cd_tipo_diagnostico
from tb_diagnostico d,
     tb_paciente p,
     tb_cid c,
     tb_alta_atendimento al,
     tb_atendimento a
where a.cd_atendimento = d.cd_atendimento and
      a.cd_atendimento = al.cd_atendimento and
      a.cd_paciente = p.cd_paciente and
      d.cd_diagnostico = c.cd_cid and
      a.dt_fim_atendimento is null and
      a.fl_internacao = 'S' and
      al.dt_alta is null and
      c.nr_cid like 'QUEI%'
/

