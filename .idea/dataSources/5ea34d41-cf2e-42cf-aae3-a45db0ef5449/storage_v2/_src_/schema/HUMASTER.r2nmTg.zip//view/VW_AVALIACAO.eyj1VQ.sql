create view VW_AVALIACAO as
    select distinct
       1 tipo,
       na.cd_avaliacao cd_aval1,
       na.nm_nivel_avaliacao nm_nivel1,
       nb.cd_avaliacao cd_aval2,
       decode(ia.cd_avaliacao_referenciada,'','',ia.nm_item_avaliacao) nm_item1,
       lpad(na.nu_ordem_apresentacao,2,'0')||'.'||decode(ia.cd_avaliacao_referenciada,'',lpad(na.nu_ordem_apresentacao,2,'0') ,lpad(ia.nu_ordem_apresentacao,2,'0'))||'.'||lpad(nb.nu_ordem_apresentacao,2,'0')||'.'||lpad(nc.nu_ordem_apresentacao,2,'0') ordem,
       decode(nc.cd_avaliacao,'', decode(nb.cd_avaliacao,'', na.cd_avaliacao,nb.cd_avaliacao),nc.cd_avaliacao) cd_avaliacao,
       decode(nc.cd_nivel_avaliacao,'', decode(nb.cd_nivel_avaliacao,'', na.cd_nivel_avaliacao,nb.cd_nivel_avaliacao),nc.cd_nivel_avaliacao) cd_nivel_avaliacao,
       decode(nb.nm_nivel_avaliacao,'',decode(ia.cd_avaliacao_referenciada,'','',ia.nm_item_avaliacao),nb.nm_nivel_avaliacao)||decode(nc.nm_nivel_avaliacao,'','','-->'||nc.nm_nivel_avaliacao) nm_nivel_avaliacao,
       decode(nc.nu_ordem_apresentacao,'', decode(nb.nu_ordem_apresentacao,'', na.nu_ordem_apresentacao,nb.nu_ordem_apresentacao),nc.nu_ordem_apresentacao) nu_ordem_apresentacao,
       decode(nc.fl_totaliza_sub_totais_itens,'',decode(nb.fl_totaliza_sub_totais_itens,'',na.fl_totaliza_sub_totais_itens,nb.fl_totaliza_sub_totais_itens),nc.fl_totaliza_sub_totais_itens) fl_totaliza_sub_totais_itens,
       decode(nc.nm_documento,'', decode(nb.nm_documento,'', na.nm_documento,nb.nm_documento),nc.nm_documento) nm_documento,
       decode(nc.cd_tipo_solicitacao,'', decode(nb.cd_tipo_solicitacao,'', na.cd_tipo_solicitacao,nb.cd_tipo_solicitacao),nc.cd_tipo_solicitacao) cd_tipo_solicitacao,
       decode(nc.fl_ordem_alfabetica,'', decode(nb.fl_ordem_alfabetica,'', na.fl_ordem_alfabetica,nb.fl_ordem_alfabetica),nc.fl_ordem_alfabetica) fl_ordem_alfabetica
  from tb_avaliacao av,
       tb_nivel_avaliacao na,
       tb_item_avaliacao ia,
       tb_nivel_avaliacao nb,
       tb_item_avaliacao ib,
       tb_nivel_avaliacao nc,
       tb_item_avaliacao ic
 where na.cd_avaliacao = av.cd_avaliacao
   and ia.cd_avaliacao(+) = na.cd_avaliacao
   and ia.cd_nivel_avaliacao(+) = na.cd_nivel_avaliacao
   and ib.cd_avaliacao(+) = ia.cd_avaliacao_referenciada
   and nb.cd_avaliacao(+) = ib.cd_avaliacao
   and nb.cd_nivel_avaliacao(+) = ib.cd_nivel_avaliacao
   and ic.cd_avaliacao(+) = ib.cd_avaliacao_referenciada
   and nc.cd_avaliacao(+) = ic.cd_avaliacao
   and nc.cd_nivel_avaliacao(+) = ic.cd_nivel_avaliacao
union
select distinct
       2 tipo ,
       na.cd_avaliacao cd_aval1,
       na.nm_nivel_avaliacao nm_nivel1,
       null cd_aval2,
       null nm_item1,
       lpad(na.nu_ordem_apresentacao,2,'0') ordem,
       null cd_avaliacao,
       null cd_nivel_avaliacao,
       null nm_nivel_avaliacao,
       null nu_ordem_apresentacao,
       null fl_totaliza_sub_totais_itens,
       null nm_documento,
       null cd_tipo_solicitacao,
       null fl_ordem_alfabetica
  from tb_avaliacao av,
       tb_nivel_avaliacao na,
       tb_item_avaliacao ia,
       tb_nivel_avaliacao nb,
       tb_item_avaliacao ib,
       tb_nivel_avaliacao nc,
       tb_item_avaliacao ic
 where na.cd_avaliacao = av.cd_avaliacao
   and ia.cd_avaliacao(+) = na.cd_avaliacao
   and ia.cd_nivel_avaliacao(+) = na.cd_nivel_avaliacao
   and ib.cd_avaliacao(+) = ia.cd_avaliacao_referenciada
   and nb.cd_avaliacao(+) = ib.cd_avaliacao
   and nb.cd_nivel_avaliacao(+) = ib.cd_nivel_avaliacao
   and ic.cd_avaliacao(+) = ib.cd_avaliacao_referenciada
   and nc.cd_avaliacao(+) = ic.cd_avaliacao
   and nc.cd_nivel_avaliacao(+) = ic.cd_nivel_avaliacao
/

