create view VW_ITENS_KIT_FULL as
select /*
             Fred Monteiro - IVIA - 22/11/2017
             View que contem todos os itens do kit, nao contem itens extra
         */
         a.id_kit,
         a.cd_atendimento,
         ab.cd_unidade_atendimento,
         aba.nm_unidade_atendimento,
         aea.cd_param_grupo_proc,
         aea.nm_param_grupo_proc,
         aea.cd_tipo_grupo_proc,
         a.cd_procedimento,
         ac.nm_procedimento,
         a.dt_transacao,
         aaaaaa.fl_tipo_classificacao fl_tipo_classificacao_padr,
         aaaaaa.ds_fl_tipo_classificacao ds_fl_tipo_classificacao_padr,
         aaaaaa.cd_tipo_produto_servico cd_tipo_produto_servico_padr,
         aaaaa.cd_tipo_classificacao cd_tipo_classificacao_padr,
         aaaaa.ds_tipo_classificacao ds_tipo_classificacao_padr,
         aaaa.cd_classificacao cd_classificacao_padr,
         aaaa.nm_classificacao nm_classificacao_padr,
         aaa.cd_material cd_material_padrao,
         aaa.nm_material nm_material_padrao,
         aabaaa.fl_tipo_classificacao fl_tipo_classificacao_bip,
         aabaaa.ds_fl_tipo_classificacao ds_fl_tipo_classificacao_bip,
         aabaaa.cd_tipo_produto_servico cd_tipo_produto_servico_bip,
         aabaa.cd_tipo_classificacao cd_tipo_classificacao_bip,
         aabaa.ds_tipo_classificacao ds_tipo_classificacao_bip,
         aaba.cd_classificacao cd_classificacao_bip,
         aaba.nm_classificacao nm_classificacao_bip,
         aab.cd_material cd_material_bipado,
         aab.nm_material nm_material_bipado,
         nvl(sum(aa.qt_material),0) qtd,
         a.cd_pessoa_func_montou cd_pessoa
    from       tb_param_grupo_proc                   aea,    -- grupo de procedimento
            tb_proc_grupo_proc                       ae,     -- procedimento x grupo de procedimento
            tm_setor                                 ad,     -- setor que montou o kit
            tb_procedimento                          ac,     -- procedimento do kit
               tb_unidade_atendimento                aba,    -- unidade de atendimento
            tm_atendimento                           ab,     -- atendimento do kit
                        tb_classe_tipo_classificacao aabaaa, -- tipo classe
                     tb_tipo_classificacao           aabaa,  -- tipo de classificacao
                  tb_classificacao                   aaba,   -- classificacao do material
               tb_material                           aab,    -- item bipado do kit
                        tb_classe_tipo_classificacao aaaaaa, -- tipo classe
                     tb_tipo_classificacao           aaaaa,  -- tipo de classificacao
                  tb_classificacao                   aaaa,   -- classificacao do material
               tb_material                           aaa,    -- item padrao do kit
            tb_item_kit_cirurgia_lote                aa,     -- itens do kit
         tm_kit_cirurgia_lote                        a       -- kit
   where 1 = 1
     -- filtros
     -- join a -- aa
     and a.id_kit = aa.id_kit
     -- join aa -- aaa
     and nvl(aa.cd_material_original, fn_get_material_original(a.id_kit, aa.cd_material)) = aaa.cd_material
     -- join aaa -- aaaa
     and aaa.cd_classificacao = aaaa.cd_classificacao
     -- join aaaa -- aaaaa
     and aaaa.cd_tipo_classificacao = aaaaa.cd_tipo_classificacao
     -- join aaaaa -- aaaaaa
     and aaaaa.fl_tipo_classificacao = aaaaaa.fl_tipo_classificacao
     -- join aa -- aab
     and aa.cd_material = aab.cd_material
     -- join aab -- aaba
     and aab.cd_classificacao = aaba.cd_classificacao
     -- join aaba -- aabaa
     and aaba.cd_tipo_classificacao = aabaa.cd_tipo_classificacao
     -- join aabaa -- aabaaa
     and aabaa.fl_tipo_classificacao = aabaaa.fl_tipo_classificacao
     -- join a -- ab
     and a.cd_atendimento = ab.cd_atendimento(+)
     -- join ab -- aba
     and ab.cd_unidade_atendimento = aba.cd_unidade_atendimento(+)
     -- join a -- ac
     and a.cd_procedimento = ac.cd_procedimento
     -- join a -- ad
     and a.cd_setor_controle = ad.cd_setor
     -- join a -- ae
     and a.cd_procedimento = ae.cd_procedimento
     -- join ae -- aea
     and ae.cd_param_grupo_proc = aea.cd_param_grupo_proc
   group by a.id_kit,
            a.cd_atendimento,
            ab.cd_unidade_atendimento,
            aba.nm_unidade_atendimento,
            aea.cd_param_grupo_proc,
            aea.nm_param_grupo_proc,
            aea.cd_tipo_grupo_proc,
            a.cd_procedimento,
            ac.nm_procedimento,
            a.dt_transacao,
            aaaaaa.fl_tipo_classificacao,
            aaaaaa.ds_fl_tipo_classificacao,
            aaaaaa.cd_tipo_produto_servico,
            aaaaa.cd_tipo_classificacao,
            aaaaa.ds_tipo_classificacao,
            aaaa.cd_classificacao,
            aaaa.nm_classificacao,
            aaa.cd_material,
            aaa.nm_material,
            aabaaa.fl_tipo_classificacao,
            aabaaa.ds_fl_tipo_classificacao,
            aabaaa.cd_tipo_produto_servico,
            aabaa.cd_tipo_classificacao,
            aabaa.ds_tipo_classificacao,
            aaba.cd_classificacao,
            aaba.nm_classificacao,
            aab.cd_material,
            aab.nm_material,
            a.cd_pessoa_func_montou
/

