create view DEPTREE as
select d.nest_level, o.object_type, o.owner, o.object_name, d.seq#
from deptree_temptab d, all_objects o
where d.object_id = o.object_id (+)
/

