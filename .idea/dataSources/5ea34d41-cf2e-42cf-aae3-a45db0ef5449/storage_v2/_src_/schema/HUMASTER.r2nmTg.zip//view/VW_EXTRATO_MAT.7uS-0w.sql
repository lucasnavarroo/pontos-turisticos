create view VW_EXTRATO_MAT as
    select 0 cd_tipo,
       'INV' cd_doc,
       0 cd_nota,
       null nr_fornecedor,
       cd_setor_controle cd_setor_controle,
       cd_setor_controle cd_setor_destino,
       dt_estoque dt_emissao,
       cd_material,
       nvl(qt_estoque_c,0)+nvl(qt_estoque_n,0) qt_material,
       nvl(vl_estoque_c,0)                     vl_material,
       dt_estoque dt_transacao,
       tm_setor.cd_setor_emp empresa,
       0  qt_contada,
       tm_estoque_inventario.cd_usuario cd_usuario,
       null  nu_comanda,
       null  cd_lote,
       dt_validade  dt_validade_lote,
       0  nu_seq_nota,
       3 fl_status,
       null id_kit,
       'N' fl_perdas,
       0 protocolo
from tm_setor,tm_estoque_inventario
where tm_estoque_inventario.dt_estoque between add_months(sysdate,-36) and sysdate and
      tm_setor.cd_setor=tm_estoque_inventario.cd_setor_controle and
      tm_setor.fl_controla='S' and
      tm_setor.fl_estoque_proprio='S'
--    tm_setor.fl_posto='N' --and
--    tm_setor.cd_unidade_atendimento like fn_unidade
union all
select 1 cd_tipo,
       cd_especie_nota cd_doc,
       tm_nota.cd_nota_fornecedor cd_nota,
       nr_fornecedor,
       tb_item_nota.cd_setor_entrada cd_setor_controle,
       tb_item_nota.cd_setor_entrada cd_setor_destino,
       dt_entrada dt_emissao,
       cd_material,
       nvl(qt_material,0),
       nvl(vl_material,0),
       dt_transacao,
       cd_filial empresa,
       0 qt_contada,
       cd_usuario,
       null nu_comanda,
       cd_lote,
       dt_validade_lote,
       tm_nota.cd_nota nu_seq_nota,
       3 fl_status,
       null id_kit,
       'N' fl_perdas,
       0 protocolo
from tb_fornecedor,tm_nota,tb_item_nota
where tm_nota.cd_nota = tb_item_nota.cd_nota and
      tm_nota.dt_entrada between add_months(sysdate,-36) and sysdate and
      tm_nota.cd_especie_nota not like 'NC%' and
      tm_nota.cd_fornecedor = tb_fornecedor.cd_fornecedor
union all
 select 2,
  'REQ',
  tm_requisicao.cd_requisicao,
  '',
  cd_setor_controle,
  cd_setor_destino,
  dt_emissao,
  cd_material,
  nvl(qt_material_c+qt_material_n,0),
  nvl(vl_material_c,0),
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  cd_lote,
  dt_validade_lote,
  0 nu_seq_nota,
  tm_requisicao.fl_status,
  id_kit,
  fl_perda_outros fl_perdas,
  nu_protocolo protocolo
 from tm_setor,tm_requisicao,tb_item_requisicao
 where tm_requisicao.cd_requisicao=tb_item_requisicao.cd_requisicao
   and tm_requisicao.dt_transacao between add_months(sysdate,-36) and sysdate
   and tm_requisicao.cd_setor_controle=tm_setor.cd_setor
   and tb_item_requisicao.fl_status_item in (1,2,3)
   and tm_setor.fl_controla='S'
   and tm_setor.fl_estoque_proprio='S'
--   and tm_setor.fl_posto='N'
--   and tm_setor.cd_unidade_atendimento like fn_unidade
union all
 select 3,
  'DEV',
  tm_devolucao.cd_devolucao,
  '',
  cd_setor_controle,
  cd_setor_destino,
  dt_emissao,
  cd_material,
  nvl(qt_material,0),
  nvl(vl_material,0),
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  cd_lote,
  dt_validade_lote,
  0 nu_seq_nota,
  tm_devolucao.fl_status,
  null id_kit,
  'N' fl_perdas,
  0 protocolo
 from tm_setor,tm_devolucao,tb_item_devolucao
where tm_devolucao.cd_devolucao=tb_item_devolucao.cd_devolucao
  and tm_devolucao.dt_transacao between add_months(sysdate,-36) and sysdate
  and tm_devolucao.cd_setor_controle=tm_setor.cd_setor
  and tb_item_devolucao.fl_status_item in (1,2,3)
  and tm_setor.fl_controla='S'
  and tm_setor.fl_estoque_proprio='S'
--  O select abaixo é para setores que não atualizam estoque no recebimento
union all
 select 4,
  'TRA',
  t.cd_transferencia,
  '',
  t.cd_setor_destino cd_setor_controle,
  t.cd_setor_controle cd_setor_destino,
  t.dt_emissao,
  i.cd_material,
  nvl(i.qt_material_c+i.qt_material_n,0),
  nvl(i.vl_material_c,0),
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  i.cd_lote,
  i.dt_validade_lote,
  0 nu_seq_nota,
  t.fl_status,
  null id_kit,
  'N' fl_perdas,
  nu_protocolo protocolo
 from tm_setor,
      tm_transferencia t,
      tb_item_transferencia i
 where i.cd_transferencia = t.cd_transferencia
   and (t.dt_transacao between add_months(sysdate,-36) and sysdate and
         nvl(fl_estoque_rec_tra,'N') = 'N')
   and t.cd_setor_destino=tm_setor.cd_setor
   and i.fl_status_item in (1,2,3)
   and tm_setor.fl_controla='S'
   and tm_setor.fl_estoque_proprio='S'
--  O select abaixo é para setores que atualizam estoque no recebimento
union all
 select 4,
  'TRA',
  t.cd_transferencia,
  '',
  t.cd_setor_destino cd_setor_controle,
  t.cd_setor_controle cd_setor_destino,
  t.dt_emissao,
  i.cd_material,
  nvl(i.qt_mat_entregue+i.qt_material_n,0),
  nvl(i.vl_material_c,0),
  nvl(t.dt_recebimento,t.dt_transacao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  i.cd_lote,
  i.dt_validade_lote,
  0 nu_seq_nota,
  t.fl_status,
  null id_kit,
  'N' fl_perdas,
  nu_protocolo protocolo
 from tm_setor,
      tm_transferencia t,
      tb_item_transferencia i
 where i.cd_transferencia = t.cd_transferencia
   and (t.dt_recebimento between add_months(sysdate,-36) and sysdate and
         nvl(fl_estoque_rec_tra,'N') = 'S' and t.dt_recebimento is not null)
   and t.cd_setor_destino=tm_setor.cd_setor
   and i.fl_status_item in (1,2,3)
   and tm_setor.fl_controla='S'
   and tm_setor.fl_estoque_proprio='S'
--
  union all
   select 5,
  'TRN',
  t.cd_transferencia,
  '',
  t.cd_setor_controle,
  t.cd_setor_destino,
  t.dt_emissao,
  i.cd_material,
  nvl(i.qt_material_c+i.qt_material_n,0),
  nvl(i.vl_material_c,0),
  nvl(dt_transacao,dt_emissao) dt_transacao,
  tm_setor.cd_setor_emp empresa,
  0 qt_contada,
  cd_usuario,
  nu_comanda,
  i.cd_lote,
  i.dt_validade_lote,
  0 nu_seq_nota,
  t.fl_status,
  null id_kit,
  'N' fl_perdas,
  nu_protocolo protocolo
from tm_setor,
  tm_transferencia t,
  tb_item_transferencia i
   where i.cd_transferencia = t.cd_transferencia
     and t.dt_transacao between add_months(sysdate,-36) and sysdate
     and t.cd_setor_controle=tm_setor.cd_setor
     and i.fl_status_item in (1,2,3)
     and tm_setor.fl_controla='S'
     and tm_setor.fl_estoque_proprio='S'
--     and tm_setor.fl_posto='N'
--     and tm_setor.cd_unidade_atendimento like fn_unidade
union all
 select 6,
  'AJT',
  a.cd_ajuste,
  '',
  a.cd_setor_controle,
  a.cd_setor_controle,
  a.dt_ajuste dt_emissao,
  a.cd_material,
  nvl(a.qt_material,0),
  nvl(a.vl_material,0),
  a.dt_ajuste dt_transacao,
  tm_setor.cd_setor_emp empresa,
  a.qt_contada,
  cd_usuario,
  null nu_comanda,
  null cd_lote,
  dt_validade dt_validade_lote,
  0 nu_seq_nota,
  3 fl_status,
  null id_kit,
  'N' fl_perdas,
  0 protocolo
 from tm_setor,tm_ajuste_estoque a
 where a.dt_ajuste between add_months(sysdate,-36) and sysdate and
       tm_setor.cd_setor=a.cd_setor_controle and
       tm_setor.fl_controla='S' and
       tm_setor.fl_estoque_proprio='S'
/

