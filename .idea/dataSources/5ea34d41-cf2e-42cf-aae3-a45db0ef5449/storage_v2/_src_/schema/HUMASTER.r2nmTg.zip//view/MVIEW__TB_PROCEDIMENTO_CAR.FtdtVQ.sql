create view MVIEW$_TB_PROCEDIMENTO_CAR as
select "CD_CARENCIA","CD_PROCEDIMENTO", rowid m_row$$ from humaster.tb_procedimento_carencia@hapvida

/

comment on table MVIEW$_TB_PROCEDIMENTO_CAR is 'master view for snapshot HUMASTER.TB_PROCEDIMENTO_CARENCIA_S'
/

