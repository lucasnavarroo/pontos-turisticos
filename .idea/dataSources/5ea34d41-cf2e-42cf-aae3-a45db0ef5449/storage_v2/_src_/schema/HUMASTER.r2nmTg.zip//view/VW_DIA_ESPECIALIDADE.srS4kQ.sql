create view VW_DIA_ESPECIALIDADE as
select c.dt_inicio+b.cd_dia_semana-1 dt_plantao,
       b.nm_dia_semana,
       a.cd_especialidade,
       a.nm_especialidade
from tb_especialidade a, tb_dia_semana b, tb_semana_ano c
where c.dt_inicio >= add_months(sysdate,-3)
/

