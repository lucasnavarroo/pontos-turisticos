create view VW_VERIFICA_INTERNAMENTO as
select u.cd_unidade_atendimento,
       u.nm_unidade_atendimento,
       p.cd_paciente cd_prontuario,
       a.cd_atendimento,
       s.cd_setor,
       s.nm_setor nm_setor_atendimento,
       p.nm_paciente,
       to_char(p.dt_nascimento,'ddmmyyyy') dt_nascimento,
       a.cd_medico_atendente,
       pma.nm_pessoa_razao_social nm_medico_atendente,
       a.cd_medico_acompanha,
       pmc.nm_pessoa_razao_social nm_medico_acompanha,
       prof.cd_conselho,
       prof.cd_crm_profissional,
       prof.cd_uf_conselho,
       a.cd_tipo_atendimento,
       tp.nm_tipo_atendimento,
       a.cd_motivo_atendimento,
       decode(a.cd_motivo_atendimento,1,'URGENCIA','ELETIVO') nm_motivo_atendimento,
       to_char(a.dt_atendimento,'ddmmyyyy') dt_atendimento,
       fn_hora(a.hr_atendimento) hr_atendimento,
       to_char(a.dt_fim_atendimento,'ddmmyyyy') dt_alta_adm,
       fn_hora(a.hr_fim_atendimento) hr_alta_adm,
       a.cd_clinica,
       c.nm_clinica
  from tb_profissional prof,
       tb_pessoa pmc,
       tb_pessoa pma,
       tb_tipo_atendimento tp,
       tm_setor s,
       tb_clinica c,
       tb_unidade_atendimento u,
       tb_paciente p,
       tm_atendimento a
 where a.cd_paciente            =  p.cd_paciente
   and a.fl_internacao          = 'S'
   and u.cd_unidade_atendimento = a.cd_unidade_atendimento
   and c.cd_clinica             = a.cd_clinica
   and s.cd_setor               = a.cd_setor
   and tp.cd_tipo_atendimento   = a.cd_tipo_atendimento
   and pma.cd_pessoa            = a.cd_medico_atendente
   and pmc.cd_pessoa(+)         = a.cd_medico_acompanha
   and prof.cd_profissional     = a.cd_medico_atendente
/

