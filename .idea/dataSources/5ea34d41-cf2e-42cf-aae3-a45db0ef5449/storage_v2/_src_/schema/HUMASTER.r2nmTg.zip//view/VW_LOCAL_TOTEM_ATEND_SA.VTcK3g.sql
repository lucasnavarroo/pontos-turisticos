create view VW_LOCAL_TOTEM_ATEND_SA as
select l.cd_local_atendimento,
       l.ds_local_atendimento,
       l.fl_tipo_local,
       fn_tamanho_fila_atend(l.cd_local_atendimento,1) qt_senha_pendente,
       fn_tempo_espera_atend(l.cd_local_atendimento) qt_tempo_espera,
       substr(nvl(fn_prioridade_fila_atend(l.cd_local_atendimento),'N'),1,1) fl_prioridade,
       t.fl_disponivel,
       l.dt_prioridade_tele_atend
  from tb_local_totem_tele_sa t,
       tb_local_atendimento_sa l
 where l.fl_tipo_local = 'L'-- Pcd_tipo_local --> 'L' - Laboratorio 'H' - Hospital 'V' Vida Imagem
   and l.cd_status = 1 -- local ativo
   and t.cd_local_atendimento = l.cd_local_atendimento
   and t.fl_ativo  = 'S' -- local totem tele-atendimento ativo
   and t.fl_disponivel = 'S'
   and rownum = 1
   and exists (select 'x'
                 from tb_senha_atendimento_sa x
                where x.dt_geracao_senha between trunc(sysdate) and trunc(sysdate+1)
                  and x.cd_local_atendimento = l.cd_local_atendimento
                  and x.cd_grupo_atendimento in (Select distinct
                                                        g.Cd_Grupo_Atendimento  g
                                                   From tb_ponto_operador_atend_sa p,
                                                        Tb_Grupo_Ponto_Atend_Sa g
                                                  Where g.Cd_local_Atendimento = x.cd_local_atendimento
                                                    and g.cd_grupo_atendimento = x.cd_grupo_atendimento
                                                    and p.cd_local_atendimento = g.cd_local_atendimento
                                                    and p.cd_ponto_atendimento = g.cd_ponto_atendimento
                                                    and p.fl_tipo = 3
                                                    and rownum = 1)
                  and x.fl_status = 0
                  and nvl(x.fl_principal,'N') = 'N'
                  and nvl(x.cd_atendimento,0) =  0
                  and rownum  = 1)
/

