create view VW_SAM_PREC_PADRAO_MDS as
select cd_modelo,
       cd_ordem_proc_plano_uso,
       cd_procedimento,
       dt_inicio,
       fn_hora(hr_inicio) hr_inicio,
       dt_fim,
       fn_hora(hr_fim) hr_fim,
       ds_observacao,
       fl_status_uso,
       qt_procedimento,
       cd_unidade_usual,
       qt_frequencia_uso,
       cd_proc_plano_pai,
       cd_cid10,
       fl_tipo_aprazamento,
       cd_profissional_prescreve,
       cd_profissional_valida,
       fl_validado,
       fl_impresso,
       cd_profissional_cancela,
       cd_ordem_impressao,
       cd_ordem_impressao_item,
       dt_impressao,
       cd_profissional_imprime,
       nm_procedimento,
       cd_tipo_procedimento,
       dt_hr_suspensao,
       fl_necessario,
       fl_acm,
       dt_libera_sn,
       fn_hora(hr_libera_sn) hr_libera_sn,
       cd_profissional_libera_sn
  from tb_proced_plano_uso_modelo
 where cd_tipo_procedimento in (4, 5, 6)
   and cd_proc_plano_pai is null
   and fn_aerosol(cd_procedimento) = 0
/

