create view VW_TIPO_LOGRADOURO_HV as
select "CD_TIPO_LOGRADOURO" from tb_tipo_logradouro@hapvida
/

