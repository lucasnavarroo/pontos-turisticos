create view VW_SAM_HIST_DIAGNOSTICO as
select md.cd_mnemonico,
       de.ds_diagnostico_exame,
       CD_ATENDIMENTO,
       CD_OCORRENCIA,
       CD_ORDEM,
       NU_SEQ_DIAGNOSTICO
  from TB_DIAGNOSTICO_EXAME de, tb_modelo_diagnostico md
 where md.cd_modelo_diagnostico(+) = de.cd_modelo_diagnostico
/

