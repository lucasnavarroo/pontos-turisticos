create view VW_AGUARDANDO_RESULT_EXAME_DGN as
select distinct cd_atendimento,
                  cd_grupo_atendimento,
                  cd_local_atendimento,
                  nm_paciente,
                  dt_atendimento,
                  hr_atendimento,
                  cd_senha_master
    from (select distinct sa.cd_atendimento,
                          sa.cd_grupo_atendimento,
                          sa.cd_local_atendimento,
                          pa.nm_paciente,
                          a.dt_atendimento,
                          fn_hora(a.hr_atendimento) hr_atendimento,
                          sa.cd_senha_master
            from tb_procedimento           pro,
                 tb_paciente               pa,
                 tb_procedimento_realizado pr,
                 tm_atendimento            a,
                 tb_senha_atendimento_sa   sa
           where sa.dt_geracao_senha between sysdate - 1 and sysdate
             and sa.cd_atendimento = a.cd_atendimento
             and sa.cd_atendimento = pr.cd_atendimento
             and pr.cd_procedimento = pro.cd_procedimento
             and a.cd_paciente = pa.cd_paciente
             and a.cd_motivo_atendimento + 0 = 1
             and a.cd_tipo_atendimento + 0 not in (0, 5, 7, 8, 10)
             and pro.fl_tipo_exame in (0, 1)
             and pro.fl_cirurgia + 0 = 2
             and pr.cd_procedimento not in
                 ('20010010',
                  '75130050',
                  '28130367',
                  '40311210',
                  '28030141',
                  '28030150',
                  '40303128',
                  '40303110') -- exames sem tempo definido resposta
             and exists
                 (select 1
                    from tb_procedimento           pp,
                         tb_procedimento_realizado prr
                   where prr.cd_procedimento = pp.cd_procedimento
                     and pp.fl_tipo_exame in (0, 1)
                     and prr.cd_atendimento = sa.cd_atendimento
                     and prr.dt_resultado is null
                     and nvl(prr.fl_entregou_material, 'N') = 'S')
          union all
          select distinct sa.cd_atendimento,
                          sa.cd_grupo_atendimento,
                          sa.cd_local_atendimento,
                          pa.nm_paciente,
                          a.dt_atendimento,
                          fn_hora(a.hr_atendimento) hr_atendimento,
                          sa.cd_senha_master
            from tb_grupo_proc_sala_ctrl   gpsc,
                 tb_procedimento           pro,
                 tb_paciente               pa,
                 tb_procedimento_realizado pr,
                 tm_atendimento            a,
                 tb_senha_atendimento_sa   sa
           where sa.dt_geracao_senha between sysdate - 1 and sysdate
             and sa.cd_atendimento = a.cd_atendimento
             and sa.cd_atendimento = pr.cd_atendimento
             and pr.cd_procedimento = pro.cd_procedimento
             and a.cd_paciente = pa.cd_paciente
             and a.cd_motivo_atendimento + 0 = 1
             and a.cd_tipo_atendimento + 0 not in (0, 5, 7, 8, 10)
             and pro.fl_tipo_exame = 2
             and pro.cd_grupo_procedimento = gpsc.cd_grupo_procedimento
                 --('23', '33', '34', '36', '402', '409', '410', '411')
             and pr.cd_procedimento not in
                 ('20010010',
                  '75130050',
                  '28130367',
                  '40311210',
                  '28030141',
                  '28030150',
                  '40303128',
                  '40303110') -- exames sem tempo definido resposta
             and exists
                 (select 1
                    from tb_grupo_proc_sala_ctrl   gpscc,
                         tb_procedimento           pp,
                         tb_procedimento_realizado prr
                   where prr.cd_procedimento = pp.cd_procedimento
                     and pp.fl_tipo_exame = 2
                     and pp.cd_grupo_procedimento = gpscc.cd_grupo_procedimento
                         --('23', '33', '34', '36', '402', '409', '410', '411')
                     and prr.cd_atendimento = sa.cd_atendimento
                     and prr.dt_resultado is null))
   order by 4
/

