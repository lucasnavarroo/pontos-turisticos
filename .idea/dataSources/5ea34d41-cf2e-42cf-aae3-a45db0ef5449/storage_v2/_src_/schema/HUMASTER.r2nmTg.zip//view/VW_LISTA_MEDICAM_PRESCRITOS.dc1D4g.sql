create view VW_LISTA_MEDICAM_PRESCRITOS as
select pm1.cd_atendimento,
         pa.nu_carteira_convenio cd_beneficiario,
         pa.cd_paciente,
         pp.cd_mat_med cd_medimento,
         pd.nm_produto nm_medicamento_prescrito,
         pp.cd_profissional_prescreve,
         pf.nm_pessoa_razao_social nm_profissional_prescreve,
         pp.qt_dosagem,
         pp.cd_unidade_usual,
         pp.cd_ocorrencia_plano,
         pp.cd_ordem_prescricao,
         pp.cd_ordem_prescricao_plano,
         uu.nr_unidade_usual,
         ge.nu_comanda,
         to_char(pp.dt_transacao, 'ddmmyyyy') dt_prescricao,
         fn_hora(to_number(to_char(pp.dt_transacao,'SSSSS'))) hr_prescricao,
         to_char(r.dt_transacao, 'ddmmyyyy') dt_lib_farmacia,
         fn_hora(to_number(to_char(r.dt_transacao,'SSSSS'))) hr_lib_farmacia,
         to_char(apm.dt_aplicado, 'ddmmyyyy') dt_aplicado,
         fn_hora(apm.hr_aplicado) hr_aplicado
    from vw_profissional           pf,
         tb_paciente               pa,
         tm_atendimento            at,
         tb_produto                pd,
         tm_requisicao             r,
         tb_apraza_presc_mat_med   apm,
         tb_prescricao_medica      pm1,
         tb_prescricao_plano       pp,
         tb_prescricao_gasto_extra ge,
         tb_unidade_usual uu
   where pp.cd_atendimento = pm1.cd_atendimento
    and pp.cd_ocorrencia_plano = pm1.cd_ocorrencia_plano
     and pp.cd_ordem_prescricao = pm1.cd_ordem_prescricao
     and pp.cd_prescricao_plano_pai is null
     and pp.cd_profissional_cancela is null
     and ge.cd_atendimento(+) = pp.cd_atendimento
     and ge.cd_ocorrencia_plano(+) = pp.cd_ocorrencia_plano
     and ge.cd_ordem_prescricao(+) = pp.cd_ordem_prescricao
     and ge.cd_ordem_prescricao_plano(+) = pp.cd_ordem_prescricao_plano
     and ge.cd_mat_med(+) = pp.cd_mat_med
     and apm.cd_atendimento(+) = ge.cd_atendimento
     and apm.cd_ocorrencia_plano(+) = ge.cd_ocorrencia_plano
     and apm.cd_ordem_prescricao(+) = ge.cd_ordem_prescricao
     and apm.cd_ordem_prescricao_plano(+) = ge.cd_ordem_prescricao_plano
     and apm.cd_ordem(+) = ge.cd_ordem_hora_med
     and pd.nu_produto = pp.nu_produto
     and r.nu_comanda(+) = ge.nu_comanda
     and at.cd_atendimento = pp.cd_atendimento
     and pa.cd_paciente  = at.cd_paciente
     and pf.cd_profissional = pp.cd_profissional_prescreve
     and uu.cd_unidade_usual (+) = pp.cd_unidade_usual
/

