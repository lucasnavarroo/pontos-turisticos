create view PIXEON_REPORT_V as
select /*+ all_rows */
           lp.cd_atendimento || lp.cd_ocorrencia || lp.cd_ordem na_accessionnumber,
           to_char(pr.dt_resultado,'yyyymmddhh24miss') na_datetimereport,
           to_char(pr.dt_libera_laudo,'yyyymmddhh24miss') na_datetimereportrelease,
           a.bl_arquivo bo_report,
           sp.nm_setor_pacs na_requireunit,
           as1.assinatura bo_signature1,
           as2.assinatura bo_signature2
      from tb_classe_medico cm,
           tb_profissional pf,
           tm_setor se,
           tb_setor_pacs sp,
           tb_laudo_arquivo a,
           tb_assinatura_medico as2,
           tb_assinatura_medico as1,
           tb_prof_proced_realizado ppr,
           tb_modalidade_worklist w,
           tb_item_grupo_produto igp,
           tb_procedimento p,
           tb_laudo_paciente lp,
           tb_procedimento_realizado pr,
           tb_guia g
      where pr.dt_procedimento_realizado between (sysdate - 90) and sysdate
        and g.cd_atendimento = pr.cd_atendimento
        and g.cd_ocorrencia = pr.cd_ocorrencia
        and pr.cd_atendimento = lp.cd_atendimento
        and pr.cd_ocorrencia = lp.cd_ocorrencia
        and pr.cd_ordem = lp.cd_ordem
        and pr.cd_procedimento = p.cd_procedimento
        and p.cd_procedimento = igp.cd_produto
        and igp.cd_grupo_produto = w.cd_grupo_produto
        and pr.cd_atendimento = ppr.cd_atendimento
        and pr.cd_ocorrencia = ppr.cd_ocorrencia
        and pr.cd_ordem = ppr.cd_ordem
        and as1.cd_medico(+) = ppr.cd_profissional
        and as2.cd_medico(+) = lp.cd_medico_unidade
        and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem = a.na_accessionnumber
        and g.cd_setor_origem = se.cd_setor
        and se.cd_setor_pacs = sp.cd_setor_pacs
        and ppr.cd_profissional = pf.cd_profissional
        and cm.cd_classe_medico(+) = pf.cd_classe_medico
        and pr.dt_libera_laudo is not null
        and a.bl_arquivo is not null
        and p.fl_tipo_exame = 2
        and ppr.cd_tipo_ato_profissional = 20
        and g.dt_autorizacao_guia between (sysdate - 90) and sysdate
        and round(to_number(sysdate - pr.dt_libera_laudo) * 1440) > nvl(cm.nu_tempo_correcao,0)
        and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem not in ( select na_accessionumber
                                                                      from pixeon_report_integrated i
                                                                      where i.na_accessionumber = pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem )
/

