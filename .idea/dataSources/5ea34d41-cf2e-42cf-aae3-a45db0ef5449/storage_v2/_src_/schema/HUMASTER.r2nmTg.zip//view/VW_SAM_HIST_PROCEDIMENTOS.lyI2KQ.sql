create view VW_SAM_HIST_PROCEDIMENTOS as
select /*+first_rows(30)*/
 fn_hora(pr.hr_procedimento_realizado) hr_procedimento_realizado,
 pr.cd_procedimento, --COLOCAR TIPO DE EXAME NO PROCEDIMENTO
 mr.cd_metodo_realizado,
 mr.ds_metodo_realizado,
 pr.cd_atendimento,
 pr.cd_ocorrencia,
 pr.cd_ordem,
 case
   when ppr.cd_tipo_ato_profissional = 20 then
    ppr.cd_profissional
   else
    null
 end cd_prof_analista,
 case
   when ppr.cd_tipo_ato_profissional = 20 then
    a.nm_fantasia
   else
    null
 end nm_prof_fantasia,
 pr.fl_entregou_material,
 pr.fl_emitiu_resultado,
 p.nm_procedimento
  from TB_PROCEDIMENTO_REALIZADO pr,
       tb_procedimento           p,
       TB_METODO_REALIZADO       mr,
       TB_PROF_PROCED_REALIZADO  ppr,
       TB_PESSOA                 A
 where pr.cd_metodo_realizado = mr.cd_metodo_realizado(+)
   and ppr.cd_atendimento = pr.cd_atendimento(+)
   and ppr.cd_ocorrencia = pr.cd_ocorrencia(+)
   and ppr.cd_ordem = pr.cd_ordem(+)
   AND A.CD_PESSOA = ppr.cd_profissional
   and pr.cd_procedimento = p.cd_procedimento /*
   and nvl(ppr.cd_tipo_ato_profissional,20) = 20*/
/

