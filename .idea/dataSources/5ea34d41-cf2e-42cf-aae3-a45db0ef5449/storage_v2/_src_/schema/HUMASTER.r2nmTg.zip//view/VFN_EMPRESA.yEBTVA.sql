create view VFN_EMPRESA as
select "COD_EMPRESA","NOME","APELIDO","IND_ATIVA"
      from vfn_empresa@matera
/

