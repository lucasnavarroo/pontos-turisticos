create view VW_PROCEDIMENTO_MODULO_HV as
select "CD_TIPO_PLANO","CD_MODULO","CD_PROCEDIMENTO" from tb_procedimento_modulo@hapvida
/

