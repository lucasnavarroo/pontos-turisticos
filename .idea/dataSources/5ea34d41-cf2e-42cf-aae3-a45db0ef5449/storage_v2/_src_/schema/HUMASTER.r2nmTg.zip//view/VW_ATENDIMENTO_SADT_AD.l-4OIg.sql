create view VW_ATENDIMENTO_SADT_AD as
select distinct
         a.cd_atendimento,
         a.dt_atendimento,
         a.cd_paciente,
         p.nm_paciente,
         p.dt_nascimento,
         p.cd_sexo,
         p.cd_tipo_endereco || ' ' || p.nm_endereco || ' ' ||
         p.nu_endereco || ' ' || p.nm_bairro || ' ' ||
         p.nm_municipio || ' ' || p.cd_uf || ' ' || p.nu_cep ds_endereco,
         p.nu_telefone,
         decode(a.fl_internacao, 'S', 'INTERNO', 'N', 'EXTERNO') tipo,
         decode(a.cd_motivo_atendimento, 1, 'EMERGENCIA', 2, 'ELETIVO') motivo,
         p.nu_carteira_convenio,
         to_char(p.nu_rg) || ' ' || p.cd_orgao_expedidor || ' ' ||
         p.cd_uf_orgao num_rg,
         pec.nm_fantasia convenio,
         e.nu_pedido,
         e.dt_pedido,
         fn_hora(e.hr_pedido) hr_pedido,
         e.cd_ocorrencia ord_ped,
         e.cd_ocorrencia_ocupacao ord_ocupa,
         e.cd_tipo_entrega,
         g.cd_ocorrencia,
         g.cd_setor_origem,
         s.nm_setor,
         pr.cd_ordem,
         pr.cd_procedimento,
         r.nr_procedimento,
         pr.qt_procedimento,
         pr.vl_procedimento,
         pr.dt_entregou_material,
         pr.dt_procedimento_realizado,
         pr.hr_procedimento_realizado,
         pr.dt_libera_laudo,
         pr.cd_bioquimico_responsavel,
         'Dr(a) ' || pem.nm_pessoa_razao_social solicitante,
         m.cd_metodo_realizado,
         m.ds_metodo_realizado,
         rp.sq_resultado,
         prr.cd_parametro_referencia,
         rp.ds_resultado_procedimento || ' ' || u.nr_unidade_usual ds_resu_unid,
         u.nr_unidade_usual unid,
         rp.ds_resultado_procedimento,
         RPAD(prr.ds_parametro_referencia, 39, '.') || ':' ds_parametro_referencia,
         prr.ds_parametro_referencia ds_param_fezes
         --rp.fl_valor_parametro -- Não implementou ainda
    from tb_procedimento           r,
         tb_paciente               p,
         tb_unidade_usual          u,
         tb_parametro_referencia   prr,
         tb_resultado_procedimento rp,
         tb_metodo_realizado       m,
         tm_setor                  s,
         tm_convenio               co,
         tb_pessoa                 pec,
         tb_pessoa                 pem,
         tb_prof_proced_realizado  pfp,
         tb_procedimento_realizado pr,
         tb_convenio_pagador       cp,
         tb_guia                   g,
         tm_atendimento            a,
         tb_pedido_exame           e
   where /*rp.cd_parametro_referencia  in (select ppr1.cd_parametro_referencia
                                           from tb_proced_param_referencia ppr1
                                          where ppr1.cd_ref                = PK_DATA_CHECK.FN_REFERENCIA(a.cd_atendimento,
                                                                                                         pr.cd_ocorrencia,
                                                                                                         pr.cd_ordem,
                                                                                                         pr.cd_procedimento,
                                                                                                         pr.dt_resultado,
                                                                                                         '''I''')
                                            and ppr1.fl_aparecer_laudo     = 'S'
                                            and rp.cd_parametro_referencia = ppr1.cd_parametro_referencia
                                            and pr.cd_procedimento         = ppr1.cd_procedimento
                                          union all
                                         select ppr1.cd_parametro_referencia
                                           from tb_proced_param_referencia ppr1
                                          where ppr1.cd_ref                = PK_DATA_CHECK.FN_REFERENCIA(a.cd_atendimento,
                                                                                                         pr.cd_ocorrencia,
                                                                                                         pr.cd_ordem,
                                                                                                         pr.cd_procedimento,
                                                                                                         pr.dt_resultado,
                                                                                                         '''I''')
                                            and ppr1.fl_aparecer_laudo     = 'N'
                                            and rp.cd_parametro_referencia = ppr1.cd_parametro_referencia
                                            and pr.cd_procedimento         = ppr1.cd_procedimento
                                            and rp.vl_resultado_parametro is not null)
     and*/ a.cd_atendimento             = e.cd_atendimento
     and g.cd_atendimento             = e.cd_atendimento
     and g.cd_ocorrencia_pedido       = e.cd_ocorrencia
     and cp.cd_atendimento            = g.cd_atendimento
     and cp.cd_convenio_pagador       = g.cd_convenio_pagador
     and pr.cd_atendimento            = g.cd_atendimento
     and pr.cd_ocorrencia             = g.cd_ocorrencia
     and rp.cd_atendimento            = pr.cd_atendimento
     and rp.cd_ocorrencia             = pr.cd_ocorrencia
     and rp.cd_ordem                  = pr.cd_ordem
     and prr.cd_parametro_referencia  = rp.cd_parametro_referencia
     and pfp.cd_atendimento           = pr.cd_atendimento
     and pfp.cd_ocorrencia            = pr.cd_ocorrencia
     and pfp.cd_ordem                 = pr.cd_ordem
     and pfp.cd_tipo_ato_profissional = 21
     and co.cd_convenio               = cp.cd_convenio
     and pec.cd_pessoa                = co.cd_pessoa
     and pem.cd_pessoa                = pfp.cd_profissional
     and r.cd_procedimento            = pr.cd_procedimento
     and u.cd_unidade_usual(+)        = rp.cd_unidade_usual
     and m.cd_metodo_realizado        = pr.cd_metodo_realizado
     and p.cd_paciente                = a.cd_paciente
     and s.cd_setor                   = g.cd_setor_origem
/

