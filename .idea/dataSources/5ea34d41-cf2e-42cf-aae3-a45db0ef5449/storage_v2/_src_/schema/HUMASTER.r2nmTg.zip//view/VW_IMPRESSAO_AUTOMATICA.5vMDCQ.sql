create view VW_IMPRESSAO_AUTOMATICA as
select /*+ FIRST_ROW */ distinct
	  pe.dt_pedido,
	  pe.nu_pedido,
	  pe.cd_atendimento,
	  pe.cd_ocorrencia,
	  gu.cd_pessoa_realiza,
	  gu.cd_setor_origem,
	  a.cd_motivo_atendimento,
	  a.fl_internacao,
	  pa.nm_paciente
    from  tb_paciente pa,
	  tb_guia gu,
	  tb_atendimento a,
	  tb_pedido_exame pe
    where pe.dt_pedido >= sysdate-90
      and fu_vw_impressao_automatica(pe.cd_atendimento, pe.cd_ocorrencia) = 0
      and gu.cd_atendimento       = pe.cd_atendimento
      and gu.cd_ocorrencia_pedido = pe.cd_ocorrencia
      and a.cd_atendimento        = pe.cd_atendimento
      and pa.cd_paciente          = a.cd_paciente
/

