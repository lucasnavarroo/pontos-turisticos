create view VW_DIETAS_SETOR as
SELECT S.CD_SETOR,
                           S.NM_SETOR,
                           FN_LOCALIZA_PAC_ACOMODACAO(PM.CD_ATENDIMENTO, PM.DT_PRESCRICAO, PM.Hr_Prescricao) ACOMODACAO,
                           FN_LOCALIZA_PAC_NU_LEITO(PM.CD_ATENDIMENTO, PM.DT_PRESCRICAO, PM.Hr_Prescricao) NU_LEITO,
                           (FN_LOCALIZA_PAC_ACOMODACAO(PM.CD_ATENDIMENTO, PM.DT_PRESCRICAO, PM.Hr_Prescricao) || '-' ||
                           FN_LOCALIZA_PAC_NU_LEITO(PM.CD_ATENDIMENTO, PM.DT_PRESCRICAO, PM.Hr_Prescricao)) LEITO,
                           PM.CD_ATENDIMENTO,
                           FN_PACIENTE_ATENDIMENTO(PM.CD_ATENDIMENTO) NM_PACIENTE,
                           DP.DT_PRESCRICAO_DIETA, PM.HR_PRESCRICAO,
                           TD.DS_TIPO_DIETA, D.NM_DIETA,
                           TA.NM_TIPO_ACESSO, (TA.CD_MNEMONICO || ' - ' || TA.NM_TIPO_ACESSO) CD_MNEMONICO,
                           TD.FL_SUBMETER_FATOR_CUSTO, DECODE(TD.FL_SUBMETER_FATOR_CUSTO, 'S', TA.NU_FATOR_CUSTO, 1) NU_FATOR_CUSTO

                      FROM TB_PRESCRICAO_MEDICA PM,
                           TB_DIETA_PACIENTE DP,
                           TM_SETOR S, TB_DIETA D, TB_TIPO_ACESSO TA, TB_TIPO_DIETA TD

                     WHERE PM.FL_PRESCRICAO_MEDICA  = 'M' AND
                           PM.FL_STATUS_PRESCRICAO  = 'S' AND
                           DP.CD_ATENDIMENTO        = PM.CD_ATENDIMENTO AND
                           DP.CD_OCORRENCIA_PLANO   = PM.CD_OCORRENCIA_PLANO AND
                           DP.CD_ORDEM_PRESCRICAO   = PM.CD_ORDEM_PRESCRICAO AND
                           DP.FL_VALIDADO           = 'S' AND
                           DP.FL_STATUS_USO         = 'S' AND
                           S.CD_SETOR               = FN_LOCALIZA_PAC_POSTO(PM.CD_ATENDIMENTO, PM.DT_PRESCRICAO, PM.Hr_Prescricao) AND
                           D.CD_DIETA               = DP.CD_DIETA AND
                           TA.CD_TIPO_ACESSO        = DP.CD_TIPO_ACESSO AND
                           TD.CD_TIPO_DIETA         = D.CD_TIPO_DIETA AND
                           FN_UNIDADE_ATENDIMENTO(PM.CD_ATENDIMENTO) = '001'
/

