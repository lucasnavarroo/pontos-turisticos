create view VW_ITENS_KIT_COMBO as
    SELECT /*
          Fred Monteiro - IVIA - 18/06/2018
          View que recupera os itens,de acordo com as regras:
          - Ato de anestesia:  Maior quantidade de itens dos procedimentos de maior porte anestesico
          - Ato de abertura:   Maior quantidade de itens dos procedimentos de maior porte anestesico
          - Ato de cavidade:   Maior quantidade de itens dos procedimentos
          - Ato de fechamento: Maior quantidade de itens dos procedimentos de maior porte anestesico
       */
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        nvl(
            a.qt_pediatria,
            a.qt_produto
        ) qt_produto,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
        a.qt_kit_reduzido,
        a.cd_faixa
    FROM
        vw_itens_kit_agend_ato_anest a -- Itens do ato de anestesia
    WHERE
        1 = 1
    UNION ALL
    SELECT
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        nvl(
            a.qt_pediatria,
            a.qt_produto
        ) qt_produto,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
      --  a.fl_kit_reduzido,
        a.qt_kit_reduzido,
        a.cd_faixa
    FROM
        vw_itens_kit_agend_ato_abert a -- Itens do ato de abertura
    WHERE
        1 = 1
    UNION ALL
    SELECT
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        nvl(
            a.qt_pediatria,
            a.qt_produto
        ) qt_produto,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
     --   a.fl_kit_reduzido,
        a.qt_kit_reduzido,
        a.cd_faixa
    FROM
        vw_itens_kit_agend_ato_cav a -- Itens do ato de cavidade
    WHERE
        1 = 1
    UNION ALL
    SELECT
        a.cd_agenda,
        a.dt_agenda,
        a.dt_nascimento,
        a.cd_paciente,
        a.idade_meses,
        a.cd_material,
        nvl(
            a.qt_pediatria,
            a.qt_produto
        ) qt_produto,
        a.cd_ato_cirurgico,
        a.id_kit,
        a.cd_setor_controle,
        a.qt_kit_reduzido,
        a.cd_faixa
    FROM
        vw_itens_kit_agend_ato_fech a -- Itens do ato de fechamento
    WHERE
        1 = 1
/

