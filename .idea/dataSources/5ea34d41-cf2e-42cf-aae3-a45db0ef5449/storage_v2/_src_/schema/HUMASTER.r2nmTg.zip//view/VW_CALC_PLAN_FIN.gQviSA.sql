create view VW_CALC_PLAN_FIN as
select cd_filial,min(dt_mes) dt_mes
    from tb_planejamento_financeiro
    where fl_calculo = 1
    group by cd_filial
/

