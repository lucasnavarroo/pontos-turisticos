create view VW_SAM_ATENDIMENTO_DECLARACAO as
select ad.cd_atendimento,
       ad.nm_acompanhante,
       to_char(ad.dt_inicial, 'dd/mm/yyyy hh24:mi:ss') dt_inicial,
       to_char(ad.dt_final, 'dd/mm/yyyy hh24:mi:ss') dt_final,
       to_char(ad.dt_operacao, 'dd/mm/yyyy hh24:mi:ss') dt_operacao,
       ad.nm_operador
    from tb_atendimento_declaracao ad
/

