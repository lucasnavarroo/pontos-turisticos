create view VW_MOVIMENTACAO_CUSTO as
    select  decode(tc.fl_tipo_classificacao,1,'MEDICAMENTOS','MATERIAIS')
	ds_tipo_movimento,
	pr.cd_atendimento,
	pr.cd_ocorrencia,
	pr.cd_ordem,
	pr.dt_procedimento_realizado,
	cp.cd_convenio_base cd_convenio,
	p.fl_cirurgia,
	pr.cd_procedimento,
	pr.cd_comite,
	n.cd_setor_destino                     cd_posto,
	s.nm_setor                             nm_posto,
	m.cd_mat_med                           cd_item,
	d.nm_material                          ds_item,
	d.cd_apresentacao||d.cd_unidade_usual  ds_unid,
	nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0)   qt_item_entregue,
	decode(nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0),0,0,
               m.vl_total/decode((nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)),0,1,
                                 (nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)))) vl_item,
  m.vl_total                             vl_item_total
from tb_setor s,
     tb_procedimento p,
     tb_tipo_classificacao tc,
     tb_classificacao c,
     tb_material d,
     tb_convenio_pagador cp,
     tb_comanda n,
     tb_comanda_mat_med m,
     tb_procedimento_realizado pr
where m.cd_atendimento          = pr.cd_atendimento
  and m.cd_ocorrencia           = pr.cd_ocorrencia
  and m.cd_ordem                = pr.cd_ordem
  and m.cd_ordem_cmd            between 1 and 9999
  and m.cd_ordem_m              between 1 and 999
  and pr.cd_procedimento        not like '99996666'
  and n.cd_atendimento          = m.cd_atendimento
  and n.cd_ocorrencia           = m.cd_ocorrencia
  and n.cd_ordem                = m.cd_ordem
  and n.cd_ordem_cmd            = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and cp.cd_atendimento         = m.cd_atendimento
  and cp.cd_convenio_pagador    = m.cd_convenio_pagador
  and d.cd_material             = m.cd_mat_med
  and d.fl_consignado           = 'N'
  and c.cd_classificacao        = d.cd_classificacao
  and tc.cd_tipo_classificacao  = c.cd_tipo_classificacao
  and p.cd_procedimento         = pr.cd_procedimento
  and s.cd_setor                = n.cd_setor_destino
union all
select  decode(tc.fl_tipo_classificacao,1,'MEDICAMENTOS','MATERIAIS')
	ds_tipo_movimento,
	prr.cd_atendimento,
	prr.cd_ocorrencia,
	prr.cd_ordem,
	prr.dt_procedimento_realizado,
	cp.cd_convenio_base cd_convenio,
	p.fl_cirurgia,
	prr.cd_procedimento,
	prr.cd_comite,
	n.cd_setor_destino                     cd_posto,
	s.nm_setor                             nm_posto,
	m.cd_mat_med                           cd_item,
	d.nm_material                          ds_item,
	d.cd_apresentacao||d.cd_unidade_usual  ds_unid,
	nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0)    qt_item_entregue,
	decode(nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0),0,0,
               m.vl_total/decode((nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)),0,1,
                                 (nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)))) vl_item,
	m.vl_total                             vl_item_total
from tb_setor s,
     tb_procedimento p,
     tb_tipo_classificacao tc,
     tb_classificacao c,
     tb_material d,
     tb_convenio_pagador cp,
     tb_comanda n,
     tb_comanda_mat_med m,
     tb_procedimento_realizado prr,
     tb_procedimento_realizado pr
where m.cd_atendimento          = pr.cd_atendimento
  and m.cd_ocorrencia           = pr.cd_ocorrencia
  and m.cd_ordem                = pr.cd_ordem
  and m.cd_ordem_cmd            between 1 and 9999
  and m.cd_ordem_m              between 1 and 999
  and prr.cd_atendimento        = pr.cd_atendimento
  and pr.cd_procedimento        = '99996666'
  and n.cd_atendimento          = m.cd_atendimento
  and n.cd_ocorrencia           = m.cd_ocorrencia
  and n.cd_ordem                = m.cd_ordem
  and n.cd_ordem_cmd            = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and cp.cd_atendimento         = m.cd_atendimento
  and cp.cd_convenio_pagador    = m.cd_convenio_pagador
  and d.cd_material             = m.cd_mat_med
  and d.fl_consignado           = 'N'
  and c.cd_classificacao        = d.cd_classificacao
  and tc.cd_tipo_classificacao  = c.cd_tipo_classificacao
  and p.cd_procedimento         = pr.cd_procedimento
  and s.cd_setor                = n.cd_setor_destino
union all
select 'X CONSIGNADOS X'
	ds_tipo_movimento,
	pr.cd_atendimento,
	pr.cd_ocorrencia,
	pr.cd_ordem,
	pr.dt_procedimento_realizado,
	cp.cd_convenio_base cd_convenio,
	p.fl_cirurgia,
	pr.cd_procedimento,
	pr.cd_comite,
	n.cd_setor_destino                     cd_posto,
	s.nm_setor                             nm_posto,
	m.cd_mat_med                           cd_item,
	d.nm_material                          ds_item,
	d.cd_apresentacao||d.cd_unidade_usual  ds_unid,
	nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0)    qt_item_entregue,
	decode(nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0),0,0,
               m.vl_total/decode((nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)),0,1,
                                 (nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)))) vl_item,
	m.vl_total                             vl_item_total
from tb_setor s,
     tb_procedimento p,
     tb_tipo_classificacao tc,
     tb_classificacao c,
     tb_material d,
     tb_convenio_pagador cp,
     tb_comanda n,
     tb_comanda_mat_med m,
     tb_procedimento_realizado pr
where m.cd_atendimento          = pr.cd_atendimento
  and m.cd_ocorrencia           = pr.cd_ocorrencia
  and m.cd_ordem                = pr.cd_ordem
  and m.cd_ordem_cmd            between 1 and 9999
  and m.cd_ordem_m              between 1 and 999
  and pr.cd_procedimento        not like '99996666'
  and n.cd_atendimento          = m.cd_atendimento
  and n.cd_ocorrencia           = m.cd_ocorrencia
  and n.cd_ordem                = m.cd_ordem
  and n.cd_ordem_cmd            = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and cp.cd_atendimento         = m.cd_atendimento
  and cp.cd_convenio_pagador    = m.cd_convenio_pagador
  and d.cd_material             = m.cd_mat_med
  and d.fl_consignado           = 'S'
  and c.cd_classificacao        = d.cd_classificacao
  and tc.cd_tipo_classificacao  = c.cd_tipo_classificacao
  and p.cd_procedimento         = pr.cd_procedimento
  and s.cd_setor                = n.cd_setor_destino
union all
select 'X CONSIGNADOS X'
	ds_tipo_movimento,
	prr.cd_atendimento,
	prr.cd_ocorrencia,
	prr.cd_ordem,
	prr.dt_procedimento_realizado,
	cp.cd_convenio_base cd_convenio,
	p.fl_cirurgia,
	prr.cd_procedimento,
	prr.cd_comite,
	n.cd_setor_destino                     cd_posto,
	s.nm_setor                             nm_posto,
	m.cd_mat_med                           cd_item,
	d.nm_material                          ds_item,
	d.cd_apresentacao||d.cd_unidade_usual  ds_unid,
	nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0)                          qt_item_entregue,
	decode(nvl(m.qt_entregue,0)+nvl(m.qt_devolvido,0),0,0,
               m.vl_total/decode((nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)),0,1,
                                 (nvl(m.qt_entregue,1)+nvl(m.qt_devolvido,0)))) vl_item,
	m.vl_total                             vl_item_total
from tb_setor s,
     tb_procedimento p,
     tb_tipo_classificacao tc,
     tb_classificacao c,
     tb_material d,
     tb_convenio_pagador cp,
     tb_comanda n,
     tb_comanda_mat_med m,
     tb_procedimento_realizado prr,
     tb_procedimento_realizado pr
where m.cd_atendimento          = pr.cd_atendimento
  and m.cd_ocorrencia           = pr.cd_ocorrencia
  and m.cd_ordem                = pr.cd_ordem
  and m.cd_ordem_cmd            between 1 and 9999
  and m.cd_ordem_m              between 1 and 999
  and prr.cd_atendimento        = pr.cd_atendimento
  and pr.cd_procedimento        = '99996666'
  and n.cd_atendimento          = m.cd_atendimento
  and n.cd_ocorrencia           = m.cd_ocorrencia
  and n.cd_ordem                = m.cd_ordem
  and n.cd_ordem_cmd            = m.cd_ordem_cmd
  and n.fl_requisicao_devolucao in (1,3,5)
  and cp.cd_atendimento         = m.cd_atendimento
  and cp.cd_convenio_pagador    = m.cd_convenio_pagador
  and d.cd_material             = m.cd_mat_med
  and d.fl_consignado           = 'S'
  and c.cd_classificacao        = d.cd_classificacao
  and tc.cd_tipo_classificacao  = c.cd_tipo_classificacao
  and p.cd_procedimento         = pr.cd_procedimento
  and s.cd_setor                = n.cd_setor_destino
--union all
--select  'TAXAS',
--	pr.cd_atendimento,
--	pr.cd_ocorrencia,
--	pr.cd_ordem,
--	pr.dt_procedimento_realizado,
--	cp.cd_convenio_base cd_convenio,
--	p.fl_cirurgia,
--	pr.cd_procedimento,
--	pr.cd_comite,
--	n.cd_setor_destino,
--	s.nm_setor,
--	to_number(m.cd_taxas),
--	d.nr_taxas,
--	'UND',
--	m.qt_taxa,
--	m.vl_total/nvl(m.qt_taxa,1),
--	m.vl_total
--from    tb_procedimento p,
--	tb_setor s,
--	tb_taxas d,
--	tb_convenio_pagador cp,
--	tb_comanda n,
--	tb_comanda_taxa m,
--	tb_procedimento_realizado pr
--where m.cd_atendimento          = pr.cd_atendimento
--  and m.cd_ocorrencia           = pr.cd_ocorrencia
--  and m.cd_ordem                = pr.cd_ordem
--  and m.cd_ordem_cmd            between 1 and 9999
--  and m.cd_ordem_tx             between 1 and 99
--  and n.cd_atendimento          = m.cd_atendimento
--  and n.cd_ocorrencia           = m.cd_ocorrencia
--  and n.cd_ordem                = m.cd_ordem
--  and n.cd_ordem_cmd            = m.cd_ordem_cmd
--  and n.fl_requisicao_devolucao in (1,3,5)
--  and cp.cd_atendimento         = m.cd_atendimento
--  and cp.cd_convenio_pagador    = m.cd_convenio_pagador
--  and d.cd_taxas                = m.cd_taxas
--  and s.cd_setor                = n.cd_setor_destino
--  and p.cd_procedimento         = pr.cd_procedimento
union all
select  'EXAMES' ds_tipo_movimento,
	pr.cd_atendimento,
	pr.cd_ocorrencia,
	pr.cd_ordem,
	pr.dt_procedimento_realizado,
	cp.cd_convenio_base cd_convenio,
	d.fl_cirurgia,
	pr.cd_procedimento,
	pr.cd_comite,
	n.cd_setor_origem                       cd_posto,
	s.nm_setor                              nm_posto,
	to_number(m.cd_procedimento)            cd_item,
	d.nr_procedimento                       ds_item,
	'UND'                                   ds_unid,
	m.qt_procedimento                       qt_item_entregue,
	decode(nvl(m.qt_procedimento,0),0,0,m.vl_total/nvl(m.qt_procedimento,1))  vl_item,
	m.vl_total                              vl_item_total
from tb_procedimento d,
     tb_setor s,
     tb_convenio_pagador cp,
     tb_guia n,
     tb_procedimento_realizado m,
     tb_procedimento_realizado pr
where m.cd_atendimento          = pr.cd_atendimento
  and d.cd_procedimento         = m.cd_procedimento
  and d.fl_cirurgia             not in (1)
  and n.cd_atendimento          = m.cd_atendimento
  and n.cd_ocorrencia           = m.cd_ocorrencia
  and cp.cd_atendimento         = n.cd_atendimento
  and cp.cd_convenio_pagador    = n.cd_convenio_pagador
  and s.cd_setor                = n.cd_setor_origem
/

