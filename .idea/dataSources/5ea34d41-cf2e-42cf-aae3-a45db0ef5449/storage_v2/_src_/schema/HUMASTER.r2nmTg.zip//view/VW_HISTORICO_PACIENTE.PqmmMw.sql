create view VW_HISTORICO_PACIENTE as
    select a.dt_atendimento,
       a.hr_atendimento,
       a.cd_tipo_atendimento,
       ta.nm_tipo_atendimento,
       a.cd_motivo_atendimento,
       mo.nm_motivo_atendimento,
       a.cd_atendimento,
       pa.cd_paciente,
       pa.nm_paciente,
       a.nm_queixa_principal,
       a.cd_diagnostico cd_diagnostico_inicial,
       ci.descr         ds_diagnostico_inicial,
       a.cd_setor,
       s.nm_setor,
       cp.cd_convenio,
       cp.nm_convenio,
       a.dt_fim_atendimento,
       d.cd_diagnostico_cid10 cd_diagnostico_final,
       cf.descr               ds_diagnostico_final,
       a.cd_medico_atendente,
       p.nm_pessoa_razao_social nm_medico_atendente,
       a.cd_medico_acompanha,
       p1.nm_pessoa_razao_social nm_medico_acompanha,
       min(oa.dt_ocupacao) dt_inicio_ocupacao,
       decode(max(nvl(oa.dt_liberacao,to_date('31/12/3000','dd/mm/yyyy'))),
                    to_date('31/12/3000','dd/mm/yyyy'),null,max(oa.dt_liberacao))
                      dt_fim_ocupacao
from tm_setor s,
     tb_cid10 ci,
     tb_cid10 cf,
     tb_pessoa p1,
     tb_pessoa p,
     tb_tipo_atendimento ta,
     tb_motivo_atendimento mo,
     tb_paciente pa,
     tb_diagnostico d,
     tb_ocupacao_acomodacao oa,
     vw_convenio_pagador cp,
     tm_atendimento a
where cp.cd_atendimento= a.cd_atendimento and
      a.cd_tipo_atendimento+0 not in (2,3,4,6) AND
      cp.cd_convenio_pagador=1 and
      oa.cd_atendimento=a.cd_atendimento and
      pa.cd_paciente   = a.cd_paciente and
      ta.cd_tipo_atendimento=a.cd_tipo_atendimento and
      mo.cd_motivo_atendimento=a.cd_motivo_atendimento and
      d.cd_atendimento(+)=a.cd_atendimento and
      d.cd_tipo_diagnostico(+)=3 and
      p.cd_pessoa(+)=a.cd_medico_atendente and
      p1.cd_pessoa(+)=a.cd_medico_acompanha and
      ci.cid10(+)=nvl(a.cd_diagnostico,'X') and
      cf.cid10(+)=d.cd_diagnostico_cid10 and
      s.cd_setor=a.cd_setor
group by
       a.dt_atendimento,
       a.hr_atendimento,
       a.cd_tipo_atendimento,
       ta.nm_tipo_atendimento,
       a.cd_motivo_atendimento,
       mo.nm_motivo_atendimento,
       a.cd_atendimento,
       pa.cd_paciente,
       pa.nm_paciente,
       a.nm_queixa_principal,
       a.cd_diagnostico,
       ci.descr,
       a.cd_setor,
       s.nm_setor,
       cp.cd_convenio,
       cp.nm_convenio,
       a.dt_fim_atendimento,
       d.cd_diagnostico_cid10,
       cf.descr,
       a.cd_medico_atendente,
       p.nm_pessoa_razao_social,
       a.cd_medico_acompanha,
       p1.nm_pessoa_razao_social
UNION ALL
-- query para atendimentos da emergencia vindos do SAM
select a.dt_atendimento,
       a.hr_atendimento,
       a.cd_tipo_atendimento,
       ta.nm_tipo_atendimento,
       a.cd_motivo_atendimento,
       mo.nm_motivo_atendimento,
       a.cd_atendimento,
       pa.cd_paciente,
       pa.nm_paciente,
       a.nm_queixa_principal,
       a.cd_diagnostico cd_diagnostico_inicial,
       ci.descr         ds_diagnostico_inicial,
       a.cd_setor,
       s.nm_setor,
       cp.cd_convenio,
       cp.nm_convenio,
       a.dt_fim_atendimento,
       d.cd_diagnostico_cid10 cd_diagnostico_final,
       cf.descr               ds_diagnostico_final,
       a.cd_medico_atendente,
       p.nm_pessoa_razao_social nm_medico_atendente,
       a.cd_medico_acompanha,
       p1.nm_pessoa_razao_social nm_medico_acompanha,
       null dt_inicio_ocupacao, --min(a.dt_atendimento)         dt_inicio_ocupacao,
       null dt_fim_ocupacao --max(a.dt_fim_atendimento)    dt_fim_ocupacao
from tm_setor s,
     tb_cid10 ci,
     tb_cid10 cf,
     tb_pessoa p1,
     tb_pessoa p,
     tb_tipo_atendimento ta,
     tb_motivo_atendimento mo,
     tb_paciente pa,
     tb_diagnostico d,
     vw_convenio_pagador cp,
     tm_atendimento a
where cp.cd_atendimento = a.cd_atendimento and
      a.cd_tipo_atendimento+0 in (2,3,4,6) and
      pa.cd_paciente   = a.cd_paciente and
      ta.cd_tipo_atendimento=a.cd_tipo_atendimento and
      mo.cd_motivo_atendimento=a.cd_motivo_atendimento and
      d.cd_atendimento(+)=a.cd_atendimento and
      d.cd_tipo_diagnostico(+)=3 and
      p.cd_pessoa(+)=a.cd_medico_atendente and
      p1.cd_pessoa(+)=a.cd_medico_acompanha and
      ci.cid10(+)=nvl(a.cd_diagnostico,'X') and
      cf.cid10(+)=d.cd_diagnostico_cid10 and
      s.cd_setor=a.cd_setor
Order by 1,2
/

