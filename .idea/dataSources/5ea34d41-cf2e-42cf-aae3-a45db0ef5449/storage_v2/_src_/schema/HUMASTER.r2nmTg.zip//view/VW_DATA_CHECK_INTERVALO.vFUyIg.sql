create view VW_DATA_CHECK_INTERVALO as
    select ppr.cd_procedimento,
       ppr.cd_metodo_realizado,
       ppr.cd_parametro_referencia,
       pr.ds_parametro_referencia,
       ppr.cd_ref,
       decode(ppr.fl_tipo_valor,
              'T','TEXTO','NUMÉRICO') fl_tipo_valor,
       (case
         when ppr.cd_sexo = 'A' then
          'AMBOS'
         when ppr.cd_sexo = 'M' then
          'MASCULINO'
         when ppr.cd_sexo = 'F' then
          'FEMININO'
         else
          ''
       end) cd_sexo,
       (case
         when ppr.fl_unidade_tempo = 'D' then
          ppr.qt_idade_inicial
         when ppr.fl_unidade_tempo = 'M' then
          trunc(ppr.qt_idade_inicial / 30)
         when ppr.fl_unidade_tempo = 'A' then
          trunc(ppr.qt_idade_inicial / 365)
         else
          null
       end) nu_pr_inicial,
       (case
         when ppr.fl_unidade_tempo = 'D' then
          ppr.qt_idade_final
         when ppr.fl_unidade_tempo = 'M' then
          trunc(ppr.qt_idade_final / 30)
         when ppr.fl_unidade_tempo = 'A' then
          trunc(ppr.qt_idade_final / 365)
         else
          null
       end) nu_pr_final,
       decode(ppr.fl_tipo_valor,
              'T',
              (select ptr.ds_texto_resultado
                 from tb_proc_texto_resultado ptr
                where ptr.cd_procedimento = ppr.cd_procedimento
                  and ptr.cd_metodo_realizado = ppr.cd_metodo_realizado
                  and ptr.cd_ordem = ppr.cd_ordem
                  and ptr.cd_parametro_referencia =
                      ppr.cd_parametro_referencia
                  and ptr.cd_ref = ppr.cd_ref
                  and ptr.fl_referencia = 'S'
                  and rownum = 1),
              decode(ppr.vl_parametro_normal,
                     null,
                     ppr.vl_parametro_minimo,
                     ppr.vl_parametro_normal)) ds_intervalo1,
       to_char(ppr.vl_parametro_maximo) ds_intervalo2,
       decode(ppr.cd_referencia,'I','=','D','<>','M','>=','W','<=','E','INTERVALO') cd_referencia,
       null cd_programa,
       null ds_programa
  from tb_parametro_referencia     pr,
       tb_proced_param_referencia  ppr
 where pr.cd_parametro_referencia = ppr.cd_parametro_referencia
union all
-- PROGRAMAS MEDPREV
select med.cd_procedimento,
       med.cd_metodo_realizado,
       med.cd_parametro_referencia,
       pr.ds_parametro_referencia,
       med.cd_ref,
       decode(med.fl_tipo_valor,
              'T','TEXTO','NUMÉRICO') fl_tipo_valor,
       (case
         when med.fl_sexo = 'MF' then
          'AMBOS'
         when med.fl_sexo = 'M' then
          'MASCULINO'
         when med.fl_sexo = 'F' then
          'FEMININO'
         else
          ''
       end) cd_sexo,
       med.nu_ig_inicio  nu_pr_inicial,
       med.nu_ig_fim  nu_pr_final,
       med.ds_intervalo1 ,
       med.ds_intervalo2,
       decode(med.cd_referencia,'I','=','D','<>','M','>=','W','<=','E','INTERVALO') cd_referencia,
       h.cd_programa,
       h.ds_programa
  from tb_programa_happrev@hapvida h,
       tb_parametro_referencia     pr,
       tb_data_check_medprev       med
 where med.cd_parametro_referencia = pr.cd_parametro_referencia
   and h.cd_programa = med.cd_programa
/

