create view VW_MATERIAL as
select a.cd_material,a.nr_material,a.nm_material,a.cd_apresentacao,a.qt_conteudo,
	a.cd_unidade_usual,a.cd_classificacao,a.cd_similar,
	b.cd_tipo_classificacao,c.fl_tipo_classificacao
from tb_material a, tb_classificacao b,tb_tipo_classificacao c
where b.cd_classificacao = a.cd_classificacao and
	c.cd_tipo_classificacao = b.cd_tipo_classificacao
/

