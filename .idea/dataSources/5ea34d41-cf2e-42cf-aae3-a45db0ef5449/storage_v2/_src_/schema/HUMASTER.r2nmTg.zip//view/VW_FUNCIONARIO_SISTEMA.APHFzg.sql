create view VW_FUNCIONARIO_SISTEMA as
select p.cd_pessoa,
       p.nu_cgc_cpf,
       p.dt_nascimento_fundacao,
       decode(af.cd_funcionario,null,p.nm_pessoa_razao_social,af.nome_funcionario) nm_pessoa_razao_social,
       decode(af.cd_funcionario,null,p.nm_fantasia,af.nome_funcionario_r) nm_fantasia,
       p.fl_sexo,
       p.nu_ident_insc_est,
       p.nm_orgao_expedidor_ident,
       p.cd_uf_orgao_expedidor_ident,
       p.fl_tipo_pessoa,
       fs.cd_funcionario,
       fs.nu_matricula,
       fs.fl_tipo_funcionario,
       fs.fl_checa_horario,
       sf.cd_setor_funcionario,
       sf.ds_setor_funcionario,
       sf.cd_setor_folha,
       ef.cd_empresa_funcionario,
       ef.nm_empresa_funcionario,
       ef.nu_cgc,
       cf.cd_cargo_funcionario,
       cf.ds_cargo_funcionario,
       sf.cd_filial,
       fs.fl_coordenador,
       fs.fl_status,
       fs.fl_escala,
       fs.dt_admissao,
       fs.dt_demissao
from tb_pessoa@HAPVIDA p,
     tb_ajuste_funcionario@HAPVIDA af,
     tb_cargo_funcionario@HAPVIDA cf,
     tb_empresa_funcionario@HAPVIDA ef,
     tb_setor_funcionario@HAPVIDA sf,
     tb_funcionario_sistema@HAPVIDA fs
where  p.cd_pessoa = fs.cd_pessoa  and
       sf.cd_setor_funcionario(+) = fs.cd_setor_funcionario and
       ef.cd_empresa_funcionario(+) = sf.cd_empresa_funcionario and
       cf.cd_cargo_funcionario(+) = fs.cd_cargo_funcionario and
       af.cd_funcionario(+) = fs.cd_funcionario AND
       fs.fl_status = 1
/

