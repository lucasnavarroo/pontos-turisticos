create view VW_ORCAMENTO_CAIXA as
    select cd_operacao,dt_previsao,valor
from vw_orcamento_caixa_
union
select to_number(lpad(substr(cd_operacao,1,2),2,'0')),dt_previsao,sum(valor)
from vw_orcamento_caixa_
where cd_operacao not in (0,999999)
group by to_number(lpad(substr(cd_operacao,1,2),2,'0')),dt_previsao
union
select to_number(lpad(substr(cd_operacao,1,4),4,'0')),dt_previsao,sum(valor)
from vw_orcamento_caixa_
where cd_operacao not in (0,999999)
group by to_number(lpad(substr(cd_operacao,1,4),4,'0')),dt_previsao
/

