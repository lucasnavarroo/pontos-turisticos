create view VW_ATEND_DIGITAL as
select a.cd_atendimento,
          p.nm_paciente,
          a.dt_atendimento,
          a.hr_atendimento,
          substr(cp.nu_carteira_convenio,1,14) nu_carteira_convenio,
          decode(a.cd_tipo_atendimento,9,'DGN-'|| s.nm_setor,'CLI-' || s.nm_setor) nm_setor,
          a.cd_usuario_digitador
     from tb_setor s,
          tb_paciente p,
          tb_convenio_pagador cp,
          tm_atendimento a
    where cp.cd_atendimento   =  a.cd_atendimento
      and cp.cd_convenio_base in (22, 90, 222)
      and p.cd_paciente       =  a.cd_paciente
      and s.cd_setor          =  a.cd_setor
/

