create view VW_SAM_MS_GRUPO_PROCED as
select a.cd_grupo_procedimento, a.nm_grupo_procedimento
  from tb_grupo_procedimento a
 where exists
 (select 'X'
          from tb_subgrupo_procedimento b, tb_procedimento c
         where c.cd_grupo_procedimento = b.cd_grupo_procedimento
           and c.cd_subgrupo_procedimento = b.cd_subgrupo_procedimento
           and b.cd_grupo_procedimento = a.cd_grupo_procedimento
           and c.fl_tipo_exame in (4, 6))
/

