create view VW_EVENTO_HIGIENIZA_ACOMODACAO as
select u.cd_unidade_atendimento cd_unidade,
           u.nm_unidade_atendimento nm_unidade,
           s.cd_setor,
           s.nm_setor,
           t.cd_posto,
           t.cd_acomodacao,
           t.nu_leito,
           t.dt_status,
           (trunc((sysdate - t.dt_status) * 24) * 60 +
           round((((sysdate - t.dt_status) * 24) -
                  (trunc((sysdate - t.dt_status) * 24))) * 60)) Total_Minutos
      from tb_unidade_atendimento u,
           tm_setor s,
           tm_acomodacao a,
           tb_leito_acomodacao t
     where t.cd_status = 'L' --> leito em Higienizacao t4103
       and t.dt_status >= sysdate - 1
       and t.cd_classe_acomodacao NOT IN (33,36) --> nÃO hÁ contrele destas classes de acomodacao
       and a.cd_acomodacao = t.cd_acomodacao
       and a.cd_classe_acomodacao = t.cd_classe_acomodacao
       and a.cd_posto = t.cd_posto
       and nvl(a.fl_ativo,'A') = 'A'
       and s.cd_setor = t.cd_posto
       and s.nm_setor not in ('HEMODINAMICA')  -->> não controla higienizacao
       and s.fl_posto = 'S'
       and u.cd_unidade_atendimento = s.cd_unidade_atendimento
/

