create view VW_OPERACAO_CENTRO_CUSTO as
select
 m.dt_emissao_documento dt_emissao,
 v.dt_transacao            ,
 f.cd_filial               ,
 f.cd_empresa_organizacao  ,
 x.cd_centro_custo         ,
 c.cd_classe_tipo_operacao ,
 c.nm_classe_tipo_operacao ,
 t.cd_tipo_operacao        ,
 t.nm_tipo_operacao        ,
 ot.cd_operacao            ,
 o.nm_operacao             ,
 sum(decode(c.fl_natureza,'R',decode(m.fl_lancamento,'D',1,-1),
            'D',decode(m.fl_lancamento,'C',1,-1),1)*
            m.VL_TRANSACAO*x.vl_rateio/100*ot.vl_rateio/100) vl_centro_custo
from tb_filial f,
     tb_classe_tipo_operacao c,
     tb_tipo_operacao t,
     tb_nivel_operacao n,
     tb_operacao o,
     tm_setor s,
     tb_centro_custo_transacao x,
     tb_operacao_transacao ot,
     tm_movimento_transacao m,
     tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta and
   ot.cd_movimento_conta = m.cd_movimento_conta and
   ot.cd_ordem_transacao = m.cd_ordem_transacao and
   x.cd_movimento_conta = m.cd_movimento_conta and
   x.cd_ordem_transacao = m.cd_ordem_transacao and
   s.cd_setor = x.cd_centro_custo and
   o.cd_operacao = ot.cd_operacao and
   n.cd_nivel_operacao = o.cd_nivel_operacao and
   n.cd_tipo_operacao = o.cd_tipo_operacao and
   t.cd_tipo_operacao = n.cd_tipo_operacao and
   c.cd_classe_tipo_operacao = t.cd_classe_tipo_operacao and
   f.cd_filial(+) = s.cd_setor_emp and
   v.dt_estorno is null and
   (v.cd_conta_corrente_credito is null or v.cd_conta_corrente_debito is null)
group by m.dt_emissao_documento,
   v.dt_transacao            ,
   f.cd_filial               ,
   f.cd_empresa_organizacao  ,
   x.cd_centro_custo         ,
   c.cd_classe_tipo_operacao ,
   c.nm_classe_tipo_operacao ,
   t.cd_tipo_operacao        ,
   t.nm_tipo_operacao        ,
   ot.cd_operacao            ,
   o.nm_operacao
/

