create view VW_SAM_EXAMES_PARECER_MED as
select /* + first_rows(10) */
  distinct
         p.cd_procedimento
        ,p.nr_procedimento
        ,la.cd_local_atendimento           cd_local_atend_dest
        ,psp.cd_procedimento_especialidade cd_procedimento_dest
        ,psp.cd_clinica                    cd_clinica_dest
        ,psp.cd_tipo_atendimento           cd_tp_atend_dest
        ,ga.cd_grupo_atendimento           cd_grupo_dest
        ,psp.cd_especialidade
        ,e.nm_especialidade
        ,ed.cd_especialidade_detalhe
        ,ed.ds_especialidade_detalhe
    from tb_especialidade e
        ,tb_especialidade_detalhe ed
        ,tb_procedimento           p
        ,tb_local_atendimento_sa  la
        ,tm_setor                  s
        ,tb_proced_solic_parecer psp
        ,tb_grupo_atendimento_sa  ga
   where la.cd_pessoa_realiza              = fn_pessoa_unidade
     and la.cd_setor                       = s.cd_setor
     and psp.cd_filial                     = s.cd_setor_emp
     and psp.cd_procedimento_especialidade = p.cd_procedimento
     and ga.cd_local_atendimento           = la.cd_local_atendimento
     and e.cd_especialidade                = psp.cd_especialidade
     and ed.cd_especialidade               = psp.cd_especialidade
     and ed.cd_especialidade_detalhe       = psp.cd_especialidade_detalhe
     and psp.cd_tipo_atendimento          <> 0
     and ga.ds_grupo_atendimento        like 'SOBRE%'
     and p.fl_tipo_exame                   = 8
/

