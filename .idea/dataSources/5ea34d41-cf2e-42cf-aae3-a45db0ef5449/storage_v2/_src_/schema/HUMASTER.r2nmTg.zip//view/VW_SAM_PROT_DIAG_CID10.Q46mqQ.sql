create view VW_SAM_PROT_DIAG_CID10 as
    SELECT a.cd_cid10, null cd_macrodiag, a.cd_formulario_protocolo
  FROM tb_avaliacao_cid10 a, tb_cid10 c
 where a.cd_cid10 = c.cid10
union
SELECT m.CID10                   cd_cid10,
       a.cd_macrodiag_cid10      cd_macrodiag,
       a.cd_formulario_protocolo
  FROM tb_avaliacao_cid10 a, vw_macrodiag_cid10 m
 where a.cd_macrodiag_cid10 = m.cd_macrodiag_cid10
/

