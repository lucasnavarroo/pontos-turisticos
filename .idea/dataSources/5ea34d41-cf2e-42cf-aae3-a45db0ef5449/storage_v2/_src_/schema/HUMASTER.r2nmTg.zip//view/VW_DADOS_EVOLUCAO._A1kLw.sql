create view VW_DADOS_EVOLUCAO as
select e.cd_atendimento,
         e.cd_ocorrencia_plano,
         e.cd_ordem,
         e.nu_evolucao,
         e.dt_evolucao,
         e.ds_observacao,
         e.hr_evolucao,
         e.fl_evolucao,
         ea.cd_ordem_avaliacao,
         ea.cd_avaliacao
    from tb_evolucao e, tb_evolucao_avaliacao ea
   where e.cd_atendimento = ea.cd_atendimento
     and e.cd_ocorrencia_plano = ea.cd_ocorrencia_plano
     and e.cd_ordem = ea.cd_ordem
/

