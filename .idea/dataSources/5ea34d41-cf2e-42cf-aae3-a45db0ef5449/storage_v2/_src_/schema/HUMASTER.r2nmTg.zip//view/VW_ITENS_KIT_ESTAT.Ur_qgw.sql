create view VW_ITENS_KIT_ESTAT as
select /*
           Fred Monteiro - IVIA - 18/01/2018
           View que contem os itens do kit que nao sao fracionados e nem custo 9 com as seguintes informações
           1 - quantidade que foi dispensada
           2 - quantidade extra
           3 - quantidade devolvida
           4 - quantidade utilizada (1+2-3)
           5 - quantidade padrao de dispensacao
           6 - quantidade padrao de consumo
           OBS: SEMPRE usar o id_kit no select.
       */
       x.id_kit,
       x.dt_transacao,
       x.cd_atendimento,
       x.cd_unidade_atendimento,
       x.nm_unidade_atendimento,
       x.cd_procedimento,
       x.nm_procedimento,
       x.fl_tipo_classificacao_padr,
       x.ds_fl_tipo_classificacao_padr,
       x.cd_tipo_produto_servico_padr,
       x.cd_tipo_classificacao_padr,
       x.ds_tipo_classificacao_padr,
       x.cd_classificacao_padr,
       x.nm_classificacao_padr,
       x.cd_material_padrao,
       x.nm_material_padrao,
       sum(decode(x.tipo, 1, x.qtd, 0)) qtd_disp,
       sum(decode(x.tipo, 2, x.qtd, 0)) qtd_extra,
       sum(decode(x.tipo, 3, x.qtd, 0)) qtd_devol,
       sum(decode(x.tipo, 1, x.qtd, 0)) +
       sum(decode(x.tipo, 2, x.qtd, 0)) -
       sum(decode(x.tipo, 3, x.qtd, 0)) qtd_utiliz,
       sum(decode(x.tipo, 4, x.qtd, 0)) qtd_padr_disp,
       sum(decode(x.tipo, 5, x.qtd, 0)) qtd_padr_cons
  from (select a.id_kit,
               a.dt_transacao,
               a.cd_atendimento,
               a.cd_unidade_atendimento,
               a.nm_unidade_atendimento,
               a.cd_procedimento,
               a.nm_procedimento,
               a.fl_tipo_classificacao_padr,
               a.ds_fl_tipo_classificacao_padr,
               a.cd_tipo_produto_servico_padr,
               a.cd_tipo_classificacao_padr,
               a.ds_tipo_classificacao_padr,
               a.cd_classificacao_padr,
               a.nm_classificacao_padr,
               a.cd_material_bipado cd_material_padrao,
               a.nm_material_bipado nm_material_padrao,
               a.qtd,
               1 tipo
          from vw_itens_kit_bipados a
         where 1 = 1
         union all
        select b.id_kit,
               b.dt_transacao,
               b.cd_atendimento,
               b.cd_unidade_atendimento,
               b.nm_unidade_atendimento,
               b.cd_procedimento,
               b.nm_procedimento,
               b.fl_tipo_classificacao,
               b.ds_fl_tipo_classificacao,
               b.cd_tipo_produto_servico,
               b.cd_tipo_classificacao,
               b.ds_tipo_classificacao,
               b.cd_classificacao,
               b.nm_classificacao,
               b.cd_material,
               b.nm_material,
               b.qtd,
               2 tipo
          from vw_itens_kit_extra b
         where 1 = 1
         union all
        select c.id_kit,
               c.dt_transacao,
               c.cd_atendimento,
               c.cd_unidade_atendimento,
               c.nm_unidade_atendimento,
               c.cd_procedimento,
               c.nm_procedimento,
               c.fl_tipo_classificacao,
               c.ds_fl_tipo_classificacao,
               c.cd_tipo_produto_servico,
               c.cd_tipo_classificacao,
               c.ds_tipo_classificacao,
               c.cd_classificacao,
               c.nm_classificacao,
               c.cd_material,
               c.nm_material,
               c.qtd,
               3 tipo
          from vw_itens_kit_devolvido c
         where 1 = 1
         union all
        select d.id_kit,
               d.dt_transacao,
               d.cd_atendimento,
               d.cd_unidade_atendimento,
               d.nm_unidade_atendimento,
               d.cd_procedimento,
               d.nm_procedimento,
               d.fl_tipo_classificacao,
               d.ds_fl_tipo_classificacao,
               d.cd_tipo_produto_servico,
               d.cd_tipo_classificacao,
               d.ds_tipo_classificacao,
               d.cd_classificacao,
               d.nm_classificacao,
               d.cd_material_padrao,
               d.nm_material_padrao,
               d.qtd,
               4 tipo
          from vw_itens_kit_padrao d
         where 1 = 1
         union all
        select e.id_kit,
               e.dt_transacao,
               e.cd_atendimento,
               e.cd_unidade_atendimento,
               e.nm_unidade_atendimento,
               e.cd_procedimento,
               e.nm_procedimento,
               e.fl_tipo_classificacao,
               e.ds_fl_tipo_classificacao,
               e.cd_tipo_produto_servico,
               e.cd_tipo_classificacao,
               e.ds_tipo_classificacao,
               e.cd_classificacao,
               e.nm_classificacao,
               e.cd_material_padrao,
               e.nm_material_padrao,
               e.qtd,
               5 tipo
          from vw_itens_kit_padrao_consumo e
         where 1 = 1) x
where 1 = 1
  --and fn_custo9(x.cd_material_padrao) = 'N'
group by x.id_kit,
         x.dt_transacao,
         x.cd_atendimento,
         x.cd_unidade_atendimento,
         x.nm_unidade_atendimento,
         x.cd_procedimento,
         x.nm_procedimento,
         x.fl_tipo_classificacao_padr,
         x.ds_fl_tipo_classificacao_padr,
         x.cd_tipo_produto_servico_padr,
         x.cd_tipo_classificacao_padr,
         x.ds_tipo_classificacao_padr,
         x.cd_classificacao_padr,
         x.nm_classificacao_padr,
         x.cd_material_padrao,
         x.nm_material_padrao
/

