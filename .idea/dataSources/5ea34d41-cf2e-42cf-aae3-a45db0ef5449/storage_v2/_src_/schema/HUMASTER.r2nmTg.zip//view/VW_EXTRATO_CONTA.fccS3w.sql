create view VW_EXTRATO_CONTA as
    select
 d.cd_movimento_conta cd_movimento,
 d.dt_transacao,
 d.cd_tipo_transacao_db cd_tipo_transacao,
 td.nm_tipo_transacao nm_tipo_transacao,
 d.cd_documento_debito cd_documento,
 d.cd_conta_corrente_debito cd_conta_corrente,
 d.cd_autoriza_cheque,
 d.cd_um,
 d.vl_movimento vl_debito,
 0 vl_credito,
 d.fl_movimento_conta,
 d.cd_nota_fiscal
from  tb_tipo_transacao td,
      tm_movimento_conta d
where d.dt_estorno is null and td.cd_tipo_transacao = d.cd_tipo_transacao_db
UNION ALL
select
 c.cd_movimento_conta cd_movimento,
 c.dt_transacao,
 c.cd_tipo_transacao_cr cd_tipo_transacao,
 tc.nm_tipo_transacao nm_tipo_transacao,
 c.cd_documento_credito cd_documento,
 c.cd_conta_corrente_credito cd_conta_corrente,
 c.cd_autoriza_cheque,
 c.cd_um,
 0 vl_debito,
 c.vl_movimento vl_credito,
 c.fl_movimento_conta,
 c.cd_nota_fiscal
from tb_tipo_transacao tc,
     tm_movimento_conta c
where c.dt_estorno is null and tc.cd_tipo_transacao = c.cd_tipo_transacao_cr
/

