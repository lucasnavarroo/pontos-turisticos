create view VW_ACOMPANHAMENTO_EXAMES_TER as
select a.cd_atendimento,
       pe.nu_pedido,
       p.nm_paciente,
       pe.dt_pedido,
       pr.cd_procedimento,
       proc.nr_procedimento,
       pt.cd_mnemonico_exame,
       (select ptp.qt_dias_terceirizados
          from tb_procedimento_tempo_padrao ptp
         where ptp.cd_unidade_atendimento = a.cd_unidade_atendimento
           and ptp.cd_procedimento = pr.cd_procedimento) qt_dias_terceirizados,
       decode((select count(*)
                from tb_lote_pedido_lab_apoio lped,
                     tb_lote_envio_lab_apoio  lexa
               where lexa.nu_pedido = pe.nu_pedido
                 and lexa.cd_laboratorio_apoio = pt.cd_laboratorio_apoio
                 and lexa.cd_mnemonico_exame = pt.cd_mnemonico_exame
                 and lped.cd_atendimento = a.cd_atendimento
                 and lexa.nu_pedido = lped.nu_pedido
                 and lexa.cd_lote = lped.cd_lote
                 and lexa.cd_laboratorio_apoio = lped.cd_laboratorio_apoio),
              0,
              'NÃO ENVIADO',
              1,
              'ENVIADO',
              'MAIS DE UMA VEZ') Envio,
       (select max(lped1.cd_lote)
          from tb_lote_pedido_lab_apoio lped1, tb_lote_envio_lab_apoio lexa1
         where lexa1.nu_pedido = pe.nu_pedido
           and lexa1.cd_laboratorio_apoio = pt.cd_laboratorio_apoio
           and lexa1.cd_mnemonico_exame = pt.cd_mnemonico_exame
           and lped1.cd_atendimento = a.cd_atendimento
           and lexa1.nu_pedido = lped1.nu_pedido
           and lexa1.cd_lote = lped1.cd_lote
           and lexa1.cd_laboratorio_apoio = lped1.cd_laboratorio_apoio) loteenvio,
       (select max(l.dt_lote)
          from tb_lote_lab_apoio        l,
               tb_lote_pedido_lab_apoio lped2,
               tb_lote_envio_lab_apoio  lexa2
         where lexa2.nu_pedido = pe.nu_pedido
           and lexa2.cd_laboratorio_apoio = pt.cd_laboratorio_apoio
           and lexa2.cd_mnemonico_exame = pt.cd_mnemonico_exame
           and lped2.cd_atendimento = a.cd_atendimento
           and lexa2.nu_pedido = lped2.nu_pedido
           and lexa2.cd_lote = lped2.cd_lote
           and lexa2.cd_laboratorio_apoio = lped2.cd_laboratorio_apoio
           and lped2.cd_lote = l.cd_lote) dataenvio,
       decode((select count(*)
                from tb_resultado_importado_b2b ri
               where ri.cd_laboratorio_apoio = pt.cd_laboratorio_apoio
                 and ri.nu_pedido = pe.nu_pedido
                 and ri.dt_pedido = pe.dt_pedido
                 and ri.cd_atendimento = pr.cd_atendimento
                 and ri.cd_ocorrencia = pr.cd_ocorrencia
                 and ri.cd_ordem = pr.cd_ordem
                 and ri.cd_procedimento = pr.cd_procedimento
                 and ri.cd_mnemonico = pt.cd_mnemonico_exame),
              0,
              'NÃO RECEBIDO',
              1,
              'RECEBIDO',
              'MAIS DE UMA VEZ') recebido,
       (select max(ri.dt_importacao)
          from tb_resultado_importado_b2b ri
         where ri.cd_laboratorio_apoio = pt.cd_laboratorio_apoio
           and ri.nu_pedido = pe.nu_pedido
           and ri.dt_pedido = pe.dt_pedido
           and ri.cd_atendimento = pr.cd_atendimento
           and ri.cd_ocorrencia = pr.cd_ocorrencia
           and ri.cd_ordem = pr.cd_ordem
           and ri.cd_procedimento = pr.cd_procedimento
           and ri.cd_mnemonico = pt.cd_mnemonico_exame) datarecebimento,
       decode((select count(*)
                from tb_resultado_procedimento rp
               where rp.cd_atendimento = pr.cd_atendimento
                 and rp.cd_ocorrencia = pr.cd_ocorrencia
                 and rp.cd_ordem = pr.cd_ordem),
              0,
              'SEM RESULTADO',
              'COM RESULTADO') Resultado,
       pr.dt_resultado,
       a.cd_unidade_atendimento,
       pt.cd_laboratorio_apoio
  from tb_procedimento              proc,
       tb_paciente                  p,
       tb_pedido_exame              pe,
       tm_atendimento               a,
       tb_guia                      g,
       tb_procedimento_terceirizado pt,
       tb_procedimento_realizado    pr
 where a.cd_paciente = p.cd_paciente
   and a.cd_atendimento = pe.cd_atendimento
   and g.cd_atendimento = pe.cd_atendimento
   and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = g.cd_atendimento
   and pr.cd_ocorrencia = g.cd_ocorrencia
   and pr.cd_atendimento = pt.cd_atendimento
   and pr.cd_ocorrencia = pt.cd_ocorrencia
   and pr.cd_ordem = pt.cd_ordem
   and pr.cd_procedimento = proc.cd_procedimento
/

