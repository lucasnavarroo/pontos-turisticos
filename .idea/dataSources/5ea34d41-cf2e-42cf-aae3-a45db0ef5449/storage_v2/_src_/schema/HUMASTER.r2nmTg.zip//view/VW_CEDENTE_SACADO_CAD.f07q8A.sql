create view VW_CEDENTE_SACADO_CAD as
select  tb_pessoa.cd_pessoa,
   tb_pessoa.nu_cgc_cpf,
   tb_pessoa.nm_pessoa_razao_social,
   tb_pessoa.nm_fantasia,
   tb_pessoa.dt_nascimento_fundacao,
   tb_pessoa.nu_ident_insc_est,
   tb_pessoa.nm_orgao_expedidor_ident,
   tb_pessoa.cd_uf_orgao_expedidor_ident,
   tb_pessoa.fl_tipo_pessoa,
   rowidtochar(tb_pessoa.rowid) ri_pessoa,
   tb_cedente_sacado.cd_tipo_cedente_sacado,
   tb_cedente_sacado.fl_status,
   tb_cedente_sacado.dt_ultima_transacao,
   rowidtochar(tb_cedente_sacado.rowid) ri_cedente_sacado,
   tb_cedente_sacado.fl_exclusivo,
   tb_cedente_sacado.nu_ident_insc_munic
from tb_pessoa,tb_cedente_sacado
where   tb_pessoa.cd_pessoa = tb_cedente_sacado.cd_pessoa and
   tb_pessoa.fl_tipo_pessoa in (1,2)
/

