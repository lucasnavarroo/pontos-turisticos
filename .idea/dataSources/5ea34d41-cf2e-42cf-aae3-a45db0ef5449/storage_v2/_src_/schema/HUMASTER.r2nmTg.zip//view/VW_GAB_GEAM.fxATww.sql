create view VW_GAB_GEAM as
select a.cd_atendimento,
         a.dt_atendimento,
         a.cd_tipo_atendimento,
         a.cd_motivo_atendimento,
         a.fl_internacao,
         a.dt_fim_atendimento dt_alta,
         g.nu_guia,
         g.cd_ocorrencia,
         g.nu_gab nu_gab_geam,
         decode(g.fl_tipo_gab,1,'GAB',2,'GEAM','') fl_tipo_gab,
         pa.cd_paciente,
         pa.nm_paciente,
         c.cd_convenio,
         substr(cp.nu_carteira_convenio,1,14) nu_carteira_convenio,
         p.nm_fantasia nm_convenio,
         fn_filial_setor(a.cd_setor) cd_filial
  from   tb_pessoa p,
         tb_paciente pa,
         tb_guia g,
         tm_atendimento a,
         tb_convenio_pagador cp,
         tm_convenio c
  where c.cd_tipo_convenio = 13
    and cp.cd_convenio_pagador = 1
    and c.cd_convenio = cp.cd_convenio_base
    and cp.cd_atendimento = a.cd_atendimento
    and a.cd_atendimento = g.cd_atendimento
    and a.cd_paciente = pa.cd_paciente
    and c.cd_pessoa = p.cd_pessoa
/

