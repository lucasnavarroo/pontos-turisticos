create view VW_ITENS_KIT_COMBO_PADRAO as
select /*
          Fred Monteiro - IVIA - 18/06/2018
          View que contem os itens bipaveis dos combos
       */
       a.cd_agenda,
       a.dt_agenda,
       a.dt_nascimento,
       a.cd_paciente,
       a.idade_meses, 
       a.cd_material,
       a.qt_produto,
       a.cd_ato_cirurgico,
       a.id_kit,
       a.cd_setor_controle
  from    tm_setor             ab,
          tb_material          aa,
       vw_itens_kit_combo      a
 where 1 = 1
   -- filtros
   -- tem validade
   --and nvl(aa.fl_validade, 'N') = 'S'
   -- nao e fragmentado
   and nvl(aa.fl_fragmenta, 'N') = 'N'
   -- controla lote
   and nvl(ab.fl_controla_lote, 'N') = 'S'
   -- join a -- aa
   and a.cd_material = aa.cd_material
   -- join ab -- ab
   and a.cd_setor_controle = ab.cd_setor(+)
/

