create view VW_PACIENTE as
select a.cd_paciente,
       a.nm_paciente,
       a.dt_nascimento,
	  ltrim(lpad(trunc(months_between(sysdate,dt_nascimento)/12),3,' ')||'A '||
       ltrim(lpad(trunc(months_between(sysdate,dt_nascimento))-
	  trunc(months_between(sysdate,dt_nascimento)/12)*12,2,' '),' ')||'M '||
       ltrim(lpad(trunc(mod(months_between(sysdate,dt_nascimento),
	  trunc(months_between(sysdate,dt_nascimento)))*30),2,'0'),' ')||'D',' ') ds_idade,
	  cd_sexo,
	  nm_municipio,
	  cd_uf,
	  cd_estado_civil,
	  cd_cor,
	  fl_tipo_sanguineo,
	  fl_fator_RH,
	  cd_profissao,
	  nm_pai,
	  nm_mae,
	  cd_prof_pai,
	  cd_prof_mae,
	  ltrim(cd_tipo_endereco||' '||nm_endereco||' '||nu_endereco,' ') ds_endereco,
	  nm_complemento_end,
	  nm_bairro,
	  nu_cep,
	  nu_telefone,
	  nu_ramal,
	  nm_ponto_referencia,
	  ds_local_trabalho_paciente,
	  nu_telefone_trabalho
from tb_paciente a
/

