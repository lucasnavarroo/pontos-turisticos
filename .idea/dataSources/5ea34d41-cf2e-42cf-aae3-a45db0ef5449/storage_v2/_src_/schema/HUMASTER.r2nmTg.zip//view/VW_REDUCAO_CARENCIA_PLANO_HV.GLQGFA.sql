create view VW_REDUCAO_CARENCIA_PLANO_HV as
select "CD_PLANO","CD_CARENCIA","CD_TIPO_REDE_ATENDIMENTO","PC_REDUCAO" from tb_reducao_carencia_plano@hapvida
/

