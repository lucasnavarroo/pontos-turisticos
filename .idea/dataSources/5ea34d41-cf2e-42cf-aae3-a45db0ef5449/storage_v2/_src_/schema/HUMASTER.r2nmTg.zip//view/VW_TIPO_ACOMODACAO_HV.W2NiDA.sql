create view VW_TIPO_ACOMODACAO_HV as
select "CD_TIPO_ACOMODACAO","NR_TIPO_ACOMODACAO","DS_TIPO_ACOMODACAO" from tb_tipo_acomodacao@hapvida
/

