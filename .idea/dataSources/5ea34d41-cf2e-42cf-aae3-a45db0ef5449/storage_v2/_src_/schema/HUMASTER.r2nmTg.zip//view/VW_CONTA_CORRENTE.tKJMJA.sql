create view VW_CONTA_CORRENTE as
select (substr(nm_agencia,1,30)||' C/C '||cd_conta_corrente) nm_conta_bancaria,
   cd_conta_corrente,
   cd_conta_bancaria,
   cd_tipo_conta_corrente,
   6 cd_um_saldo,
   CD_UM_INICIAL          ,
   DT_SALDO_INICIAL       ,
   VL_SALDO_INICIAL       ,
   DT_SALDO               ,
   VL_SALDO VL_SALDO,
   VL_SALDO_INICIAL_CHEQUE,
   VL_SALDO_CHEQUE VL_SALDO_CHEQUE,
   FL_FINANCEIRO          ,
   cd_filial,
   NM_OPERADOR
  from tb_agencia_bancaria a,tm_conta_corrente c
  where a.cd_banco = c.cd_banco and
   a.cd_agencia = c.cd_agencia
/

