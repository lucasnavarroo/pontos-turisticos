create view VW_TRANSACAO_CONTA_NATUREZA as
select tb_transacao_conta_corrente.cd_tipo_transacao,
   tb_tipo_transacao.nm_tipo_transacao,
   tb_transacao_conta_corrente.cd_tipo_conta_corrente,
   cd_natureza_transacao,
   fl_especie
from tb_tipo_transacao,tb_transacao_conta_corrente
where tb_tipo_transacao.cd_tipo_transacao =
   tb_transacao_conta_corrente.cd_tipo_transacao
/

