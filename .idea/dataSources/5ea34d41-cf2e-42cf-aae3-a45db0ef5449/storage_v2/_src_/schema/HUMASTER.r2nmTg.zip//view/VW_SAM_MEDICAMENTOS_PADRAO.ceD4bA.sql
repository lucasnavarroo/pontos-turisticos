create view VW_SAM_MEDICAMENTOS_PADRAO as
select "CD_MODELO","CD_ORDEM_PRESCRICAO_PLANO","CD_PRESCRICAO_PLANO_PAI","CD_MAT_MED","QT_FREQUENCIA_USO","CD_UNIDADE_USUAL","CD_TIPO_ACESSO","QT_DOSAGEM","QT_DILUICAO","CD_GOTEJAMENTO","FL_STATUS_USO","FL_NECESSARIO","FL_DILUICAO","CD_APRESENTACAO","FL_FREQUENCIA_USO","CD_TIPO_PRESCRICAO_PLANO","QT_RECONSTITUICAO","CD_DILUENTE","NU_PRODUTO","NM_PRODUTO","FL_ALTA_VIGILANCIA","FL_CONTROLADO","NM_MATERIAL"
  from (select pp.cd_modelo,
               pp.cd_ordem_prescricao_plano,
               pp.cd_prescricao_plano_pai,
               pp.cd_mat_med,
               pp.qt_frequencia_uso,
               pp.cd_unidade_usual,
               pp.cd_tipo_acesso,
               pp.qt_dosagem,
               pp.qt_diluicao,
               pp.cd_gotejamento,
               pp.fl_status_uso,
               pp.fl_necessario,
               pp.fl_diluicao,
               pp.cd_apresentacao,
               pp.fl_frequencia_uso,
               pp.cd_tipo_prescricao_plano,
               pp.qt_reconstituicao,
               pp.cd_diluente,
               pp.nu_produto,
               decode(nvl(p.nr_produto, 'X'),
                      'X',
                      p.nm_produto,
                      p.nr_produto) nm_produto,
               mat.fl_alta_vigilancia,
               mat.fl_controlado,
               fn_ds_mat_med(pp.cd_mat_med) nm_material
          from tb_produto p, tb_prescricao_plano_modelo pp, tb_material mat
         where pp.nu_produto = p.nu_produto(+)
           and pp.cd_mat_med = mat.cd_material) tb
 where cd_tipo_prescricao_plano in (1, 4)
/

