create view VW_CONVENIO_PAGADOR as
select v.cd_atendimento,
  v.cd_convenio_pagador,
  decode(v.cd_convenio_pagador,1,'PRINCIPAL',2,'SECUNDARIO',
          'OUTROS') nm_convenio_pagador,
  v.cd_convenio_base cd_convenio,
  p.nm_fantasia nm_convenio,
  v.cd_plano_base    cd_plano,
  pc.ds_plano_convenio
from tb_pessoa p,
     tb_plano_convenio pc,
     tb_convenio c,
     tb_convenio_pagador v
where c.cd_convenio           = v.cd_convenio_base and
   p.cd_pessoa          = c.cd_pessoa and
   pc.cd_convenio       = v.cd_convenio_base+0 and
   pc.cd_plano_convenio = v.cd_plano_base


-- fim solic 6905
--grant select on VW_CONVENIO_PAGADOR to RL_ADMINISTRACAO1;
--grant select on VW_CONVENIO_PAGADOR to RL_ADMINISTRACAO4;
--grant select, insert, update, delete on VW_CONVENIO_PAGADOR to SAH with grant option;
--grant select, insert, update, delete on VW_CONVENIO_PAGADOR to WEBHOSP
/

