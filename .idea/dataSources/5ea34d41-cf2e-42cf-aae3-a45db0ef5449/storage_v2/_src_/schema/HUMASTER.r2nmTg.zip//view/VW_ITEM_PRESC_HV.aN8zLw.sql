create view VW_ITEM_PRESC_HV as
select CD_ATENDIMENTO,
        CD_OCORRENCIA_PLANO,
        CD_ORDEM_PRESCRICAO,
        CD_ORDEM_HV,
        VIG,
        VOLUME_TOTAL,
        QT_FREQUENCIA_USO,
        FL_FREQUENCIA_USO,
        QT_GOTEJAMENTO,
        CD_GOTEJAMENTO,
        FL_BOMBA_INFUSAO,
        QT_SORO_S_GLICOSE,
        QT_SORO_C_GLICOSE,
        FL_IMPRESSO,
        CD_PROFISSIONAL_PRESCREVE,
        CD_PROFISSIONAL_VALIDA,
        CD_PROFISSIONAL_CANCELA,
        CD_OPERADOR,
        CD_TERMINAL,
        DT_TRANSACAO,
        cd_tipo_acesso_infusao,
        cd_tipo_fase,
        qt_tempo_fase_rapida,
        cd_unid_tempo_fase_rapida,
        fl_necessario,
        fl_acm,
        nvl(fl_validado, 'N') fl_validado,
        nvl(fl_status_uso, 'N') fl_status_uso,
        presc.nm_fantasia prof_prescritor,
        val.nm_fantasia prof_validador,
        canc.nm_fantasia prof_cancelador
   from tb_prescricao_medica_hv h,
        tb_pessoa               presc,
        tb_pessoa               val,
        tb_pessoa               canc
  where h.cd_profissional_prescreve = presc.cd_pessoa(+)
    and h.cd_profissional_valida = val.cd_pessoa(+)
    and h.cd_profissional_cancela = canc.cd_pessoa(+)
/

