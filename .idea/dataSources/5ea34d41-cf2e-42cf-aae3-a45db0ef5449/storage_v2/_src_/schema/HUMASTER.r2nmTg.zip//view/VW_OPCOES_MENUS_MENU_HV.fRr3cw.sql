create view VW_OPCOES_MENUS_MENU_HV as
select "COD_OP","DESCRICAO","TIPO","AJUDA","NM_PROG","COD_OP_REL","CD_TELA","CD_TELA_ALIAS","CD_LOGOTIPO" from tb_opcoes_menu@hapvida
/

