create view VW_DADOS_ATENDIMENTO as
select -- dados do atendimento --
         a.cd_unidade_atendimento,
         pes.nm_pessoa_razao_social nm_prestador,
         pes.nm_fantasia nm_prestador_fantasia,
         a.cd_atendimento,
         to_char(a.dt_atendimento, 'ddMMyyyy') dt_atendimento,
         fn_hora(a.hr_atendimento) hr_atendimento,
         to_char(a.dt_fim_atendimento, 'ddMMyyyy') dt_fim_atendimento,
         fn_hora(a.hr_fim_atendimento) hr_fim_atendimento,
         a.cd_setor,
         s.nm_setor,
         a.cd_tipo_atendimento,
         ta.nm_tipo_atendimento,
         a.cd_paciente,
         substr(cp.nu_carteira_convenio,1,14) nu_carteira,
         cp.cd_convenio_base cd_convenio
   from tb_pessoa pes,
        tb_unidade_atendimento u,
        tb_tipo_atendimento ta,
        tm_setor s,
        tb_convenio_pagador cp,
        tm_atendimento a
  where s.cd_setor               = a.cd_setor
    and cp.cd_atendimento        = a.cd_atendimento
    and cp.cd_convenio_pagador   = 1
    and ta.cd_tipo_atendimento   = a.cd_tipo_atendimento
    and u.cd_unidade_atendimento = a.cd_unidade_atendimento
    and pes.cd_pessoa            = u.cd_pessoa_cobra
    and a.dt_canc_atend         is null
/

