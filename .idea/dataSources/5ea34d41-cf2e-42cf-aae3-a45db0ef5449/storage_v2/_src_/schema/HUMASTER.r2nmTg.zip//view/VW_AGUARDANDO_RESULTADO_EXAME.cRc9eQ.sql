create view VW_AGUARDANDO_RESULTADO_EXAME as
select distinct sa.cd_atendimento,
       sa.cd_grupo_atendimento,
       sa.cd_local_atendimento,
       pa.nm_paciente,
       a.DT_ATENDIMENTO,
       sa.cd_senha_master
 from tb_procedimento pro,
      tb_paciente pa,
      tb_procedimento_realizado pr,
      tm_atendimento a,
      tb_senha_atendimento_sa sa
  where sa.dt_geracao_senha between sysdate -1 and sysdate
    and sa.cd_atendimento = a.CD_ATENDIMENTO
    and sa.cd_atendimento = pr.cd_atendimento
    and pr.cd_procedimento = pro.cd_procedimento
    and a.CD_PACIENTE = pa.cd_paciente
    and a.CD_MOTIVO_ATENDIMENTO = 1
    and a.CD_TIPO_ATENDIMENTO in (2,3,4,5,6,11)
    and pro.fl_tipo_exame in (0,1)
    and exists (select 'X'
                  from  tb_procedimento pp,
                        tb_procedimento_realizado prr
                  where prr.cd_procedimento = pp.cd_procedimento
                    and pp.fl_tipo_exame in (0,1)
                    and prr.cd_atendimento = sa.cd_atendimento
                    and nvl(prr.fl_emitiu_resultado,'N') = 'N'
          and nvl(prr.fl_entregou_material, 'N') = 'S')
 order by pa.nm_paciente
/

