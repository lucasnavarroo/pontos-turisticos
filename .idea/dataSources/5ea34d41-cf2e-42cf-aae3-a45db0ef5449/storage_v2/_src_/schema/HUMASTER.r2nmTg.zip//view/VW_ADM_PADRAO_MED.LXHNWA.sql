create view VW_ADM_PADRAO_MED as
select distinct ta.cd_mnemonico,
                ad.ds_administracao_diluicao,
                pr.nm_produto nm_reconstituir,
                to_char(ad.qt_reconstituir) ||
                decode(ad.qt_reconstituir, null, '', 'ML') qt_reconstituir,
                pr1.nm_produto nm_diluente,
                to_char(ad.qt_diluente) ||
                decode(ad.qt_diluente, null, '', 'ML') qt_diluente,
                ad.cd_principio_ativo,
                ad.cd_ocorrencia_diluicao,
                ad.cd_ordem_administracao,
                ad.qt_diluente qtde_diluente,
                ad.qt_reconstituir qtde_reconstituir,
                pr2.nm_produto nm_reconstituir2,
                ad.qt_reconstituir2,
                ad.cd_diluente,
                ad.fl_tipo_administracao,
                decode(ad.fl_tipo_administracao,
                       'B',
                       'Bolus',
                       'C',
                       'Contínuo',
                       'L',
                       'Lento') tipo_adm,
                ad.cd_apresentacao_diluente,
                m.cd_material,
                ad.cd_tipo_acesso,
                ap.qt_volume,
                m.fl_fragmenta,
                ap.cd_unidade_dosagem,
                ap.qt_dosagem
  from tb_tipo_acesso             ta,
       tb_produto                 pr2,
       tb_produto                 pr,
       tb_produto                 pr1,
       tb_material                m,
       tb_produto_mat_med         pf,
       tb_param_classe_diluicao   pcd,
       tb_principio_ativo         pa,
       tb_produto_principio_ativo ppa,
       tb_apresentacao_diluicao   ap,
       tb_administracao_diluicao  ad
 where ad.cd_principio_ativo = ppa.cd_principio_ativo
   and ap.cd_principio_ativo = ad.cd_principio_ativo
   and ap.cd_ocorrencia_diluicao = ad.cd_ocorrencia_diluicao
   and ppa.nu_produto = pf.nu_produto
   and pa.cd_principio_ativo = ppa.cd_principio_ativo
   and pcd.cd_principio_ativo(+) = ad.cd_principio_ativo
   and pcd.cd_ocorrencia_diluicao(+) = ad.cd_ocorrencia_diluicao
   and pcd.cd_ordem_administracao(+) = ad.cd_ordem_administracao
   and pr.nu_produto(+) = ad.cd_reconstituir
   and pr1.nu_produto(+) = ad.cd_diluente
   and pr2.nu_produto(+) = ad.cd_reconstituir2
   and m.cd_material = pf.cd_mat_med
   and ta.cd_tipo_acesso = ad.cd_tipo_acesso
   and pcd.cd_classe_acomodacao in (33,36) --AMB. ADT e AMB. PED
   and ad.cd_diluente is not null
/

