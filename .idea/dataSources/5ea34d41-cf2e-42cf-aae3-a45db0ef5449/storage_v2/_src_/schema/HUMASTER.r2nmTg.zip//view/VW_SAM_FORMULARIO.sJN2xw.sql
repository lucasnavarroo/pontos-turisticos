create view VW_SAM_FORMULARIO as
select na.cd_avaliacao,
       na.cd_nivel_avaliacao,
       na.nm_nivel_avaliacao,
       ia.cd_ordem,
       ia.cd_ordem_pai,
       ia.nm_item_avaliacao,
       ia.ds_item_avaliacao,
       ia.ds_formula,
       ia.fl_formula,
       ia.fl_tipo_atributo,
       ia.fl_tipo_valor,
       ia.ds_instrucao,
       ia.fl_obrigatorio,
       ia.id_componente,
       ia.cd_avaliacao_referenciada
  from tb_nivel_avaliacao na, tb_item_avaliacao ia
 where ia.cd_avaliacao = na.cd_avaliacao
   and ia.cd_nivel_avaliacao = na.cd_nivel_avaliacao
      --   and na.cd_avaliacao = 248
   and nvl(ia.fl_mostra, 'N') = 'S'
 order by na.nu_ordem_apresentacao, ia.cd_ordem
/

