create view FN_SITE_FILIAL as
select "ID_FILIAL","COD_SITE","IND_PRINCIPAL"
     from fn_site_filial@matera
/

