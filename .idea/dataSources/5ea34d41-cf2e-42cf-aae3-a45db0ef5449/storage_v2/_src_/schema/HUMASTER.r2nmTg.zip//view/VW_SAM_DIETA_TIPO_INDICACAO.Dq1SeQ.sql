create view VW_SAM_DIETA_TIPO_INDICACAO as
select "CD_DIETA","NM_DIETA","CD_TIPO_DIETA","DS_TIPO_DIETA","DS_INDICACAO_USO"
  from vw_dieta_tipo_indicacao
 /*where cd_tipo_dieta in
       (select cd_tipo_dieta from tb_tipo_dieta where fl_ativo = 'S')*/
/

