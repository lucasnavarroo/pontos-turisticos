create view VW_SAM_EXAMES_LAB as
select /* + first_rows(10) */
            pr.cd_procedimento,
            pr.nu_prioridade_exame,
            pr.nr_procedimento,
            pr.cd_procedimento_cbhpm,
            pr.fl_urgencia
       from tb_procedimento pr
      where nvl(pr.fl_urgencia,'N') = 'S'
        and pr.fl_tipo_exame   in (0,1) -- exames laboratorio
        and nvl(pr.fl_cbhpm,'N') = 'N'
/

