create view VW_GLOSA_PROCESSO_HAP as
select "NU_ORDEM","DT_PRODUCAO","NU_DOCUMENTO",
       "NU_SEQ_DOCUMENTO",
       "DT_PAGAMENTO",
       "NU_CNPJ_PRESTADOR",
       "NU_CPF_SOLICITANTE",
       "CD_BENEFICIARIO",
       "NM_BENEFICIARIO",
       "TP_SERVICO",
       "DT_ATENDIMENTO",
       "CD_SERVICO",
       "DS_SERVICO",
       "QT_SERVICO_INF",
       "VL_SERVICO_INF",
       "QT_SERVICO",
       "VL_SERVICO",
       "VL_SERVICO_PG",
       "CD_SENHA",
       "FL_ERRO",
       "CD_TIPO_ATO",
       "FL_PACOTE" 
  FROM vw_glosa_processo@hapvida
/

