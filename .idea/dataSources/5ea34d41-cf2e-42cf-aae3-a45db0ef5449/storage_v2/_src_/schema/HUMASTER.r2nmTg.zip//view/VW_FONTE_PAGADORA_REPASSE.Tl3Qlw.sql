create view VW_FONTE_PAGADORA_REPASSE as
select rm.cd_pessoa,
       pj.nm_pessoa_razao_social,
       pj.nu_cgc_cpf,
       rm.nu_nfiscal,
       sum(rm.vl_pago) vl_pago,
       rm.cd_obrigacao,
       rm.dt_obrigacao
  from tb_profissional prof_pj, tb_pessoa pj, tb_repasse_medico rm
 where 1e1 = 1e1
   and rm.cd_unidade_atendimento = FN_UNIDADE_OPERADOR
   and prof_pj.cd_cooperativa = 'S'
   and rm.cd_pessoa = pj.cd_pessoa
   and rm.cd_pessoa = prof_pj.cd_profissional
group by rm.cd_pessoa,
       pj.nm_pessoa_razao_social,
       pj.nu_cgc_cpf,
       rm.nu_nfiscal,
       rm.cd_obrigacao,
       rm.dt_obrigacao
/

