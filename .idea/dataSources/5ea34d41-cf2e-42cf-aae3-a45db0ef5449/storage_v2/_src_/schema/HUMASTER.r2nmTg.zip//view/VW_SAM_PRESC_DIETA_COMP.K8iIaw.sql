create view VW_SAM_PRESC_DIETA_COMP as
select distinct cdp.cd_atendimento,
                cdp.cd_ocorrencia_plano,
                cdp.cd_ordem_prescricao,
                cdp.cd_ordem_dieta,
                cdp.cd_ordem,
                cdp.cd_mat_med,
                cdp.qt_composicao,
                cdp.cd_unidade_usual,
                cd.nm_composicao_dieta
  from tb_composicao_dieta_paciente cdp,
       tb_dieta_paciente            dp,
       tb_composicao_dieta          cd
 where cdp.cd_atendimento = dp.cd_atendimento
   and cdp.cd_ocorrencia_plano = dp.cd_ocorrencia_plano
   and cdp.cd_ordem_prescricao = dp.cd_ordem_prescricao
   and dp.cd_dieta = cd.cd_dieta
   and cdp.cd_mat_med = cd.cd_mat_med
/

