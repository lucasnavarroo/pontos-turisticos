create view VW_SAM_HIST_DT_EXAMES as
select to_char(pe.dt_pedido, 'dd/mm/yyyy') dt_mov,
           pe.cd_atendimento,
           pe.cd_ocorrencia,
           g.cd_ocorrencia cd_ocorrencia_guia,
           to_char(pe.nu_pedido) cd_doc,
           g.nu_guia,
           '1009901' || ';' || pe.cd_atendimento || ';' || pe.cd_ocorrencia || ';' ||
           g.cd_ocorrencia || ';' cd_chave,
           a.cd_tipo_atendimento
      from tb_tipo_atendimento ta,
           tb_paciente         pa,
           tb_convenio_pagador cp,
           tb_guia             g,
           tm_atendimento      a,
           tb_pedido_exame     pe
     where pe.cd_atendimento = a.cd_atendimento
       and g.cd_atendimento = a.cd_atendimento
       and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
       and cp.cd_atendimento = a.cd_atendimento
       and cp.cd_convenio_pagador = 1
       and pa.cd_paciente = a.cd_paciente
       and ta.cd_tipo_atendimento = a.cd_tipo_atendimento
/

