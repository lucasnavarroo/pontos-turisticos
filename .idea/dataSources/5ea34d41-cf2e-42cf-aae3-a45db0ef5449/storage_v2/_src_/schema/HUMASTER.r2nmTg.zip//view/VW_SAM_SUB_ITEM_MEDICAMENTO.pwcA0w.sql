create view VW_SAM_SUB_ITEM_MEDICAMENTO as
select pp.cd_modelo,
       pp.cd_ordem_prescricao_plano,
       pp.cd_prescricao_plano_pai,
       pp.cd_mat_med,
       pp.qt_frequencia_uso,
       pp.cd_unidade_usual,
       pp.cd_tipo_acesso,
       pp.qt_dosagem,
       pp.qt_diluicao,
       pp.cd_gotejamento,
       pp.fl_status_uso,
       pp.fl_necessario,
       pp.cd_diluente,
       pp.fl_diluicao,
       pp.cd_apresentacao,
       pp.fl_frequencia_uso,
       pp.cd_tipo_prescricao_plano,
       decode(nvl(p.nr_produto, 'X'), 'X', p.nm_produto, p.nr_produto) nm_produto,
       pp.qt_reconstituicao
  from tb_produto p, tb_prescricao_plano_modelo pp
 where pp.nu_produto = p.nu_produto(+)
   and pp.cd_tipo_acesso = 6
 and pp.cd_tipo_prescricao_plano in (1,4)
/

