create view VW_CLASSI_PRIORIDADE as
select e.cd_prioridade,
       e.ds_prioridade,
       e.cd_color,
       e.cd_risco_associado_emg
  from tb_classi_prioridade_exame e
 where e.cd_risco_associado_emg is not null
/

