create view VW_DBL_TESTE as
select "ID_TIT_FINPAC","CD_SISTEMA_ORIGEM","CD_OBRIGACAO","CD_ORIGEM_OBRIGACAO" from tb_obrigacao_finpac@hapvida
/

