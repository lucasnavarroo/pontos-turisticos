create view MVIEW$_TB_CARENCIA_S as
select "CD_CARENCIA","NM_CARENCIA","NR_CARENCIA","FL_EMISSAO","FL_SEXO", rowid m_row$$ from humaster.tb_carencia@hapvida

/

comment on table MVIEW$_TB_CARENCIA_S is 'master view for snapshot HUMASTER.TB_CARENCIA_S'
/

