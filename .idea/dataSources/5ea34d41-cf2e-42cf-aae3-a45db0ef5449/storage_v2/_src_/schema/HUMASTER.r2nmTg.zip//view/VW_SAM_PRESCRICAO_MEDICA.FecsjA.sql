create view VW_SAM_PRESCRICAO_MEDICA as
select pm.cd_atendimento,
       pm.cd_ocorrencia_plano,
       pm.cd_ordem_prescricao,
       pm.cd_ordem_prescricao_pai,
       pm.nu_prescricao_medica,
       to_char(pm.dt_prescricao, 'dd/mm/yyyy') dt_prescricao,
       fn_hora(pm.hr_prescricao) hr_prescricao,
       pm.qt_peso_kg_registrado
  from tb_prescricao_medica pm
 where pm.FL_PRESCRICAO_MEDICA = 'M'
 order by pm.dt_prescricao desc, pm.hr_prescricao desc
/

