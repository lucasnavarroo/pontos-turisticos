create view VW_ACOMODACAO_UNIDADE as
select a.CD_ACOMODACAO,
       a.CD_CLASSE_ACOMODACAO,
       a.CD_POSTO,
       a.QT_LEITOS,
       a.FL_ATIVO
from tb_setor s,
     tb_acomodacao a
where s.cd_setor = a.cd_posto and
     (s.fl_centro_cirurgico='S' or
      s.fl_oncologia='S' or
      s.fl_centro_obstetrico='S' or
      s.fl_hemodinamica='S')
/

