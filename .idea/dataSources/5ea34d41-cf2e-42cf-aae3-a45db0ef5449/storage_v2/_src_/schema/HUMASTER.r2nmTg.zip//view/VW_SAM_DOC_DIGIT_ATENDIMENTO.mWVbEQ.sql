create view VW_SAM_DOC_DIGIT_ATENDIMENTO as
select d.cd_ocorrencia,
       d.CD_ATENDIMENTO,
       to_char(d.dt_transacao, 'dd/mm/yyyy') dt_transacao,
       d.ds_ocorrencia,
       t.nm_tipo,
       d.IM_DIGITALIZACAO,
       a.cd_paciente
  from TB_ATENDIMENTO_DOC_DIGIT d, tm_atendimento a, TB_TIPO_DOC_DIGIT t
 where d.cd_atendimento = a.cd_atendimento
   and d.CD_TIPO_DOC_DIGIT = t.cd_tipo_doc_digit
   and t.fl_clinico = 'S'
/

