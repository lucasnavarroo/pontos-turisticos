create view VW_EXAMES_NAO_ENVIADOS_LAB as
select g.cd_pessoa_realiza,
       pe.nm_pessoa_razao_social,
       v.CD_SETOR,
       s.nm_setor,
       v.cd_laboratorio_apoio,
       la.nm_laboratorio_apoio,
       v.CD_ATENDIMENTO,
       v.nu_pedido,
       v.nm_paciente,
       pt.cd_mnemonico_exame,
       v.CD_PROCEDIMENTO,
       p.nr_procedimento,
       v.DT_PROCEDIMENTO_REALIZADO,
       v.dt_pedido
  from tb_laboratorio_apoio         la,
       tm_setor                     s,
       tb_procedimento              p,
       tb_guia                      g,
       tb_procedimento_terceirizado pt,
       vw_exame_terceirizado        v,
       tb_pessoa                    pe
 where nvl(v.fl_entregou_material, 'N') = 'S'
   and not exists
 (select 'x'
          from tb_lote_envio_lab_apoio le
         where le.nu_pedido = v.nu_pedido
           and le.cd_mnemonico_exame = pt.cd_mnemonico_exame
           and le.cd_laboratorio_apoio in
               (v.cd_laboratorio_apoio,
                (select cd_laboratorio_apoio
                   from tb_laboratorio_apoio_aux
                  where cd_laboratorio_apoio_aux = v.cd_laboratorio_apoio)))
   and pe.cd_pessoa = g.cd_pessoa_realiza
   and v.CD_ATENDIMENTO = pt.cd_atendimento
   and v.CD_OCORRENCIA = pt.cd_ocorrencia
   and v.CD_ORDEM = pt.cd_ordem
   and v.CD_ATENDIMENTO = g.cd_atendimento
   and v.CD_OCORRENCIA = g.cd_ocorrencia
   and v.CD_PROCEDIMENTO = p.cd_procedimento
   and v.CD_SETOR = s.cd_setor
   and v.cd_laboratorio_apoio = la.cd_laboratorio_apoio
 order by g.cd_pessoa_realiza, s.cd_setor, v.cd_laboratorio_apoio, v.CD_ATENDIMENTO
/

