create view VW_USUARIOS_OUVIDORIA as
    select 'XXXXX' nm_paciente,
       0 cd_atendimento,
       u.cd_usuario cd_usuario_hap
from   tb_usuario@hapvida u
where  u.cd_usuario > '00000000000000'
union all
select p.nm_paciente,
       a.cd_atendimento,
       null cd_usuario_hap
from   tb_paciente p,
       tb_atendimento a
where  a.dt_atendimento between add_months(sysdate,-24) and sysdate and
       p.cd_paciente=a.cd_paciente
/

