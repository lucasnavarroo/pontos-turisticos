create view VW_EVENTO_PRESCRICAO_APLICACAO as
select distinct a."CD_ATENDIMENTO",
       a."CD_PACIENTE",
       a."CD_MOTIVO_ATENDIMENTO",
       a."FL_NIVEL",
       a."DT_ATENDIMENTO",
       a."HR_ATENDIMENTO",
       a."CD_ATENDIMENTO_MAE",
       a."CD_SETOR",
       alocacao."NM_POSTO",
       nvl(alocacao.fl_alocacao, 0) as "FL_ALOCACAO",
       alocacao.dt_alocacao_fn,
       a."CD_CLINICA",
       a."CD_MEDICO_ATENDENTE",
       a."CD_MEDICO_ACOMPANHA",
       a."CD_ENCAMINHA",
       a."CD_TIPO_ATENDIMENTO",
       a."CD_GRUPO_ATENDIMENTO",
       a."CD_MATRICULA",
       a."CD_TIPO_DOCUMENTO",
       a."CD_CONDICAO_SOCIAL",
       a."CD_ESTADO_PACIENTE",
       a."CD_ASPECTO",
       a."CD_PROCEDENCIA",
       a."CD_NATUREZA_CONSULTA",
       a."NM_QUEIXA_PRINCIPAL",
       a."FL_TOMA_ANTIBIOTICO",
       a."FL_INTERNACAO",
       a."DT_FIM_ATENDIMENTO",
       a."HR_FIM_ATENDIMENTO",
       a."QT_PESO",
       a."QT_TAMANHO",
       a."DS_OBSERVACAO",
       a."CD_USUARIO_DIGITADOR",
       a."NU_PEDIDO_POSTO",
       a."FL_DIFERENCA_ACOMODACAO",
       a."CD_UNIDADE_ATENDIMENTO",
       a."VL_GLOSA",
       a."VL_GLOSA_ANALISAR",
       a."DT_CANC_ATEND",
       a."CD_DIAGNOSTICO",
       a."DT_ENT_CONTROLADORIA",
       a."DT_ENT_FATURAMENTO",
       a."FL_BLOQUEIO",
       a."DT_BLOQUEIO",
       a."CD_USUARIO",
       a."DT_COLETA_DIGITAL",
       a."CD_ATENDIMENTO_ORIGEM",
       a."FL_GERADO_AUTO",
       a."DT_COLETA_DIGITAL_EXAME",
       a."DS_JUST_CONS_RETORNO",
       a."CD_USU_LIBEROU_RETORNO",
       a."DT_ENT_PRONT_AUDITORIA",
       a."DT_DEV_PRONT_PENDENCIA",
       a."DT_ENT_NSALA_AUDITORIA",
       a."CD_USUARIO_CANCELOU",
       a."NU_GAB",
       a."FL_TIPO_GAB",
       a."DS_JUST_AUT_DOC",
       a."DT_AUT_DOC",
       a."CD_USU_AUT_DOC",
       a."CD_ATENDIMENTO_CONTIGUO",
       to_date(to_char(a.dt_atendimento, 'dd/mm/yyyy') || ' ' ||
               fn_hora(a.hr_atendimento) || ':00',
               'dd/mm/yyyy hh24:mi:ss') dt_atendimento_fn,
       sa.dt_geracao_senha,
       item.nm_item_prescricao,
       item.dt_prescricao,
       item.dt_aplicado,
       (trunc((sysdate - item.dt_prescricao) * 24) * 60 +
       round((((sysdate - item.dt_prescricao) * 24) -
              (trunc((sysdate - item.dt_prescricao) * 24))) * 60)) total_minutos,
       case when exa.cd_atendimento is null then 0 else 1 end as pendente_exame
  from tb_paciente p,
       tm_atendimento a,
       tb_prescricao_medica pm,
       tb_grupo_atendimento_sa ga,
       tb_local_atendimento_sa la,
       tb_senha_atendimento_sa sa,
       tm_setor posto,
       tb_exame_solicitado_sa exa,
       (select oa.dt_ocupacao,
               oa.hr_ocupacao,
               to_date(to_char(oa.dt_ocupacao, 'dd/mm/yyyy') || ' ' ||
                       fn_hora(oa.hr_ocupacao) || ':00',
                       'dd/mm/yyyy hh24:mi:ss') dt_alocacao_fn,
               po.NM_SETOR as nm_posto,
               1 as fl_alocacao,
               oa.cd_atendimento
          from tb_ocupacao_acomodacao oa, tm_setor po
         where oa.cd_posto = po.CD_SETOR
           and oa.dt_ocupacao >= sysdate - 1) alocacao,
       (select pm1.cd_atendimento cd_a1,
               pm1.cd_ocorrencia_plano,
               pm1.cd_ordem_prescricao,
               pd.nm_produto nm_item_prescricao,
               pp.dt_transacao dt_prescricao,
               apm.dt_aplicado + (apm.hr_aplicado / 3600 / 24) dt_aplicado
          from tb_produto                pd,
               tb_apraza_presc_mat_med   apm,
               tb_prescricao_medica      pm1,
               tb_prescricao_plano       pp,
               tb_prescricao_gasto_extra ge
         where pm1.dt_prescricao >= sysdate - 1
           and pp.cd_atendimento = pm1.cd_atendimento
           and pp.cd_ocorrencia_plano = pm1.cd_ocorrencia_plano
           and pp.cd_ordem_prescricao = pm1.cd_ordem_prescricao
           and pp.cd_prescricao_plano_pai is null
           and pp.cd_profissional_cancela is null
           and ge.cd_atendimento(+) = pp.cd_atendimento
           and ge.cd_ocorrencia_plano(+) = pp.cd_ocorrencia_plano
           and ge.cd_ordem_prescricao(+) = pp.cd_ordem_prescricao
           and ge.cd_ordem_prescricao_plano(+) =
               pp.cd_ordem_prescricao_plano
           and ge.cd_mat_med(+) = pp.cd_mat_med
           and apm.cd_atendimento(+) = ge.cd_atendimento
           and apm.cd_ocorrencia_plano(+) = ge.cd_ocorrencia_plano
           and apm.cd_ordem_prescricao(+) = ge.cd_ordem_prescricao
           and apm.cd_ordem_prescricao_plano(+) =
               ge.cd_ordem_prescricao_plano
           and apm.cd_ordem(+) = ge.cd_ordem_hora_med
           and apm.ds_justificativa_nao_adm is null
           and pd.nu_produto = pp.nu_produto
        union all
        select distinct pm1.cd_atendimento cd_a1,
                        pm1.cd_ocorrencia_plano,
                        pm1.cd_ordem_prescricao,
                        pc.nm_procedimento nm_item_prescricao,
                        pp.dt_transacao dt_prescricao,
                        aps.dt_final + (aps.hr_final / 3600 / 24) dt_aplicado
          from tb_procedimento           pc,
               tb_proced_hora_plano_uso  aps,
               tb_prescricao_medica      pm1,
               tb_procedimento_plano_uso pp,
               tb_prescricao_gasto_extra ge
         where pm1.dt_prescricao >= sysdate - 1
           and pp.cd_atendimento = pm1.cd_atendimento
           and pp.cd_ocorrencia_plano = pm1.cd_ocorrencia_plano
           and pp.cd_ordem_prescricao = pm1.cd_ordem_prescricao
           and pp.cd_proc_plano_pai is null
           and pp.cd_profissional_cancela is null
           and aps.cd_atendimento(+) = pp.cd_atendimento
           and aps.cd_ocorrencia_plano(+) = pp.cd_ocorrencia_plano
           and aps.cd_ordem_prescricao(+) = pp.cd_ordem_prescricao
           and aps.cd_ordem_proc_plano_uso(+) = pp.cd_ordem_proc_plano_uso
           and aps.ds_justificativa_nao_adm is null
           and ge.cd_atendimento(+) = pp.cd_atendimento
           and ge.cd_ocorrencia_plano(+) = pp.cd_ocorrencia_plano
           and ge.cd_ordem_prescricao(+) = pp.cd_ordem_prescricao
           and ge.cd_ordem_proc_plano_uso(+) = pp.cd_ordem_proc_plano_uso
           and ge.cd_procedimento(+) = pp.cd_procedimento
           and pc.cd_procedimento = pp.cd_procedimento
           and nvl(pc.fl_aerosol, 'N') = 'N') item -- aerossol nao entra aqui pois já aparece em medicamento
 where sa.dt_geracao_senha >= sysdate - 1
   and sa.fl_principal = 'S'
   and posto.cd_setor = a.cd_setor
   and la.cd_local_atendimento = sa.cd_local_atendimento
   and ga.cd_local_atendimento = sa.cd_local_atendimento
   and ga.cd_grupo_atendimento = sa.cd_grupo_atendimento
   and a.cd_atendimento = sa.cd_atendimento
   and a.dt_canc_atend is null
   and a.cd_motivo_atendimento = 1
   and p.cd_paciente = a.cd_paciente
   and pm.cd_atendimento = sa.cd_atendimento
   and item.cd_a1 = pm.cd_atendimento
   and item.cd_ocorrencia_plano = pm.cd_ocorrencia_plano
   and item.cd_ordem_prescricao = pm.cd_ordem_prescricao
   and item.dt_aplicado is null
   and exa.cd_atendimento(+) = a.cd_atendimento
   and nvl(exa.fl_exame_cancelado, 'N') = 'N'
   and alocacao.cd_atendimento(+) = a.cd_atendimento
/

