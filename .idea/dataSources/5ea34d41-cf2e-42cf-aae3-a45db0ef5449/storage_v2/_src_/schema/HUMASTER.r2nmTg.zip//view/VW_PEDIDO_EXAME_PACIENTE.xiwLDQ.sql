create view VW_PEDIDO_EXAME_PACIENTE as
select
         pe.cd_atendimento,
         pe.cd_ocorrencia,
         pe.nu_pedido,
         pe.dt_pedido,
         pe.nm_operador,
         pe.cd_ocorrencia_ocupacao,
         pe.cd_tipo_exame,
         pe.cd_tipo_entrega,
         pa.cd_paciente,
         pa.nm_paciente,
         pa.cd_sexo,
         pa.dt_nascimento,
         a.dt_atendimento,
         a.cd_tipo_atendimento,
         pe.hr_pedido
  from tb_paciente pa,
       tm_atendimento a,
       tb_pedido_exame pe
  where a.cd_atendimento = pe.cd_atendimento
    and pa.cd_paciente   = a.cd_paciente
/

