create view VW_OPERADOR_CERTIFICADO as
select a.NM_OPERADOR,
       a.DS_OPERADOR,
       a.CD_PESSOA,
       b.user_id,
       b.ds_certificado
  from adm.tb_certificado b,
       tb_operador a
 where a.NM_OPERADOR = b.nm_operador
/

