create view VW_ITENS_KIT_PADRAO_FULL as
SELECT /*
             Fred Monteiro - IVIA - 22/11/2017
             View que contem todos os materiais e medicamentos do kit padrao de dispensacao
         */
        a.id_kit,
        a.cd_atendimento,
        ab.cd_unidade_atendimento,
        aba.nm_unidade_atendimento,
        aaa.cd_param_grupo_proc,
        aaa.nm_param_grupo_proc,
        aaa.cd_tipo_grupo_proc,
        a.cd_procedimento,
        ac.nm_procedimento,
        a.dt_transacao,
        aaaaaaaa.fl_tipo_classificacao,
        aaaaaaaa.ds_fl_tipo_classificacao,
        aaaaaaaa.cd_tipo_produto_servico,
        aaaaaaa.cd_tipo_classificacao,
        aaaaaaa.ds_tipo_classificacao,
        aaaaaa.cd_classificacao,
        aaaaaa.nm_classificacao,
        aaaa.cd_mat_med cd_material_padrao,
        aaaaa.nm_material nm_material_padrao,
        decode (A.FL_KIT_REDUZIDO ,'S', nvl(aaaa.qt_kit_reduzido,0) ,aaaa.qt_produto) qtd,
        a.cd_pessoa_func_montou cd_pessoa,
        a.cd_faixa,
        'M' tipo_medicamento
    FROM
        tb_procedimento ac,   -- procedimento do kit
        tb_unidade_atendimento aba,  -- unidade de atendimento
        tm_atendimento ab,   -- atendimento do kit
        tb_classe_tipo_classificacao aaaaaaaa,-- tipo classe
        tb_tipo_classificacao aaaaaaa, -- tipo de classificacao
        tb_classificacao aaaaaa,  -- classificacao do material
        tb_material aaaaa,-- material do kit
        tb_prod_grupo_proc aaaa, -- materiais x grupo de procedimento
        tb_param_grupo_proc aaa,  -- grupo de procedimento
        tb_proc_grupo_proc aa,   -- procedimento x grupo de procedimento
        tm_kit_cirurgia_lote a      -- kit
    WHERE
            1 = 1
     -- filtros
        AND
            nvl(
                aaa.fl_ativo,
                'S'
            ) = 'S'
        AND
            aaaa.cd_grupo_prod_proc = 2
        AND
            a.dt_transacao BETWEEN nvl(
                aaaa.dt_ini_vigencia,
                a.dt_transacao
            ) AND nvl(
                aaaa.dt_fin_vigencia,
                SYSDATE + 1
            )
     -- join a -- aa
        AND
            a.cd_procedimento = aa.cd_procedimento
     -- join aa -- aaa
        AND
            aa.cd_param_grupo_proc = aaa.cd_param_grupo_proc
     -- join aaa -- aaaa
        AND
            aaa.cd_param_grupo_proc = aaaa.cd_param_grupo_proc
     -- join aaaa -- aaaaa
        AND
            aaaa.cd_mat_med = aaaaa.cd_material
     -- join aaaaa -- aaaaaa
        AND
            aaaaa.cd_classificacao = aaaaaa.cd_classificacao
     -- join aaaaaa -- aaaaaaa
        AND
            aaaaaa.cd_tipo_classificacao = aaaaaaa.cd_tipo_classificacao
     -- join aaaaaaa -- aaaaaaaa
        AND
            aaaaaaa.fl_tipo_classificacao = aaaaaaaa.fl_tipo_classificacao
     -- join a -- ab
        AND
            a.cd_atendimento = ab.cd_atendimento (+)
     -- join ab -- aba
        AND
            ab.cd_unidade_atendimento = aba.cd_unidade_atendimento (+)
     -- join a -- ac
        AND
            a.cd_procedimento = ac.cd_procedimento
/

