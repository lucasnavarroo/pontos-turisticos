create view VW_EMPRESA_ORGANIZACAO as
select  e.cd_empresa_organizacao,
 e.nm_logotipo_empresa,
 p.nm_pessoa_razao_social
from    tb_pessoa p,
 tb_empresa_organizacao e
where   p.cd_pessoa = e.cd_pessoa
/

