create view VW_PROFISSIONAL as
SELECT
    a.cd_profissional,
    p.cd_pessoa,
    p.nm_pessoa_razao_social,
    p.nm_fantasia,
    p.nu_cgc_cpf,
    p.fl_tipo_pessoa,
    a.cd_conselho,
    a.f_ativo,
    a.cd_crm_profissional,
    a.fl_status,
    FN_FORMATA_CELULAR (a.fone,a.ddd) celular,
    cd_tipo_negociacao
  FROM
    tb_pessoa p,
    tb_profissional a
  WHERE
    a.fl_status  IN ('A','S')
  AND p.cd_pessoa = a.cd_profissional
/

