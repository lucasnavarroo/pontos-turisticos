create view VW_IMPRIME_PEDIDO as
select distinct  rp.cd_atendimento,
		     pr.fl_emitiu_resultado,
		     gu.cd_pessoa_realiza,
		     gu.cd_setor_origem
	   from  tb_resultado_procedimento rp,
   tb_procedimento_realizado pr,
   tb_guia gu,
   tb_pedido_exame pe
	   where gu.cd_atendimento = pe.cd_atendimento      and
	   gu.cd_ocorrencia_pedido = pe.cd_ocorrencia and
		 pr.cd_atendimento = gu.cd_atendimento      and
		 pr.cd_ocorrencia = gu.cd_ocorrencia        and
		 rp.cd_atendimento(+) = pr.cd_atendimento   and
		 rp.cd_ocorrencia(+) = pr.cd_ocorrencia     and
		 rp.cd_ordem(+) = pr.cd_ordem
/

