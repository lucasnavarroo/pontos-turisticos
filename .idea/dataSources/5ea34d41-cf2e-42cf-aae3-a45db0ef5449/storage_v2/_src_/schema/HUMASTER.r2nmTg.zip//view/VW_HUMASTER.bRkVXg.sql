create view VW_HUMASTER as
    select 'LOGOTIPO' cd_atributo,
       nm_logotipo_unidade nm_atributo
from tb_unidade_atendimento
where cd_unidade_atendimento = fn_unidade_operador
union all
select 'CODIGO UNIDADE' cd_atributo,
       cd_unidade_atendimento nm_atributo
from tb_unidade_atendimento
where cd_unidade_atendimento = fn_unidade_operador
union all
select 'NUM SERIE' cd_atributo,
       nu_serie nm_atributo
from tb_unidade_atendimento
where cd_unidade_atendimento = fn_unidade_operador
union all
select 'NOME' cd_atributo,
       nm_unidade_atendimento nm_atributo
from tb_unidade_atendimento
where cd_unidade_atendimento = fn_unidade_operador
union all
select 'TITULAR' cd_atributo,
       nm_titular nm_atributo
from tb_unidade_atendimento
where cd_unidade_atendimento = fn_unidade_operador
/

