create view VW_CONTROLE_IMAGEM_PEDIDO as
select pe.nu_pedido,
       pe.cd_atendimento,
       p.nm_paciente,
       proc.cd_procedimento,
       proc.nr_procedimento nm_procedimento,
       pz.dt_inicio dt_solicitacao,
       pk_prazo_exame.fn_dt_prazo_exame(pr.cd_atendimento, pr.cd_ocorrencia, pr.cd_ordem,0.5) dt_prazo_50,
       pk_prazo_exame.fn_dt_prazo_exame(pr.cd_atendimento, pr.cd_ocorrencia, pr.cd_ordem,0.75) dt_prazo_75,
       pz.dt_prazo,
       a.cd_motivo_atendimento,
       a.cd_tipo_atendimento,
       nvl(a.fl_internacao, 'N') fl_internacao,
       a.cd_unidade_atendimento,
       ua.nm_unidade_atendimento,
       poe.fl_ocultar_urgencia
       , proc.FL_NAO_LAUDAR,
       psl.DT_EXAME_SOLIC_LAUDO
  from tb_procedimento_oculto_emg poe,
       tb_unidade_atendimento     ua,
       tb_procedimento            proc,
       tb_paciente                p,
       tb_prazo_exame             pz,
       tb_procedimento_sem_laudo  psl,
       tm_atendimento             a,
       tb_pedido_exame            pe,
       tb_guia                    g,
       tb_procedimento_realizado  pr
 where pr.cd_atendimento = g.cd_atendimento
   and pr.cd_ocorrencia = g.cd_ocorrencia
   and g.cd_atendimento = pe.cd_atendimento
   and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
   and pr.cd_atendimento = a.cd_atendimento
   and a.cd_paciente = p.cd_paciente
   and pr.cd_atendimento = pz.cd_atendimento
   and pr.cd_ocorrencia = pz.cd_ocorrencia
   and pr.cd_ordem = pz.cd_ordem
   and pr.cd_atendimento = psl.cd_atendimento(+)
   and pr.cd_ocorrencia = psl.cd_ocorrencia(+)
   and pr.cd_ordem = psl.cd_ordem(+)
   and pr.cd_procedimento = proc.cd_procedimento
   and a.cd_unidade_atendimento = ua.cd_unidade_atendimento
   and pr.cd_procedimento = poe.cd_procedimento
  and ((proc.fl_nao_laudar = 'N') or ((proc.fl_nao_laudar = 'S') and (psl.dt_exame_solic_laudo is not null)))
   and pr.fl_entregou_material = 'S'
   and pr.dt_libera_laudo is null
   and proc.fl_tipo_exame = 2
/

