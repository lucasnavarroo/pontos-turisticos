create view VW_SAM_SENHA_AGUARDANDO as
select CD_SENHA_MASTER,
       sa.CD_GRUPO_ATENDIMENTO,
       sa.CD_LOCAL_ATENDIMENTO,
       CD_SENHA_ATENDIMENTO,
       CD_PONTO_ATENDIMENTO_ATE,
       sa.CD_ATENDIMENTO,
       DT_GERACAO_SENHA,
       DT_INICIO_ATENDIMENTO,
       DT_INICIO_CADASTRO,
       DT_FIM_CADASTRO,
       NM_PACIENTE,
       VL_IDADE,
       FL_STATUS,
       sa.CD_PACIENTE,
       FL_PRIORIDADE,
       a.cd_medico_atendente,
       nm_operador_obs_retorno,
       sa.FL_PRINCIPAL,
       sa.CD_GRUPO_CONSULTORIO,
       sa.fl_triagem,
       sa.cd_nivel_classificacao_risco,
       sa.cd_operador_inicio_triagem,
       sa.dt_inicio_triagem,
       sa.dt_fim_triagem,
       a.cd_natureza_consulta,
       a.fl_gerado_auto
from   tb_local_atendimento_sa loc, tm_atendimento a,
       tb_senha_atendimento_sa sa
where  a.cd_atendimento = sa.CD_ATENDIMENTO
and    loc.CD_LOCAL_ATENDIMENTO = sa.CD_LOCAL_ATENDIMENTO
and    a.cd_tipo_atendimento not in (0,5,7,8,10)
and    a.DT_FIM_ATENDIMENTO    is null
and    sa.fl_status in (2,6,8)
and    dt_geracao_senha        >= trunc(sysdate)- 3
and    dt_geracao_senha        >= trunc(sysdate)- nvl(loc.qt_dias_coleta,1)
/

