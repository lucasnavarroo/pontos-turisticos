create view VW_ACE_GRUPOS_OPCOES as
SELECT COD_GRUPO, cod_op,cd_tela
FROM tb_GRUPOS_OPCOES
/

