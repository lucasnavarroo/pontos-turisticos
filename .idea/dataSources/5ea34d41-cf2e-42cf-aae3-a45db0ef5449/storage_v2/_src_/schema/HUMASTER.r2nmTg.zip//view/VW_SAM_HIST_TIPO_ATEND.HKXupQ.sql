create view VW_SAM_HIST_TIPO_ATEND as
select /*+first_rows(100)*/ "CD_TIPO_ATENDIMENTO","NM_TIPO_ATENDIMENTO","DT_ATENDIMENTO","HR_ATENDIMENTO","CD_ATENDIMENTO","TP_ATEND","CD_PACIENTE","CD_PESSOA","DT_ATE","LOCAL_ATE"
  from (Select t.cd_tipo_atendimento,
               t.nm_tipo_atendimento,
               to_char(a.dt_atendimento, 'dd/mm/yyyy') dt_atendimento,
               fn_hora(a.hr_atendimento) hr_atendimento,
               a.cd_atendimento,
               1 tp_atend,
               p.cd_paciente,
               null cd_pessoa,
               a.dt_atendimento dt_ate,
               'hap' local_ate
          from tb_tipo_atendimento t, tm_atendimento a, tb_paciente p
         Where a.cd_tipo_atendimento + 0 = t.cd_tipo_atendimento
           and p.cd_paciente = a.cd_paciente
        union
        Select /*+DRIVING_SITE(pf,pm,pl,ac,pu)*/
         99,
         'CONSULTA CLINICA ELETIVA',
         to_char(TRUNC(ac.DT_ATENDIMENTO), 'dd/mm/yyyy') DT_ATENDIMENTO,
         fn_hora(to_number(to_char(aC.dt_atendimento, 'sssss'))) hr_atendimento,
         ac.NU_ATENDIMENTO,
         2 tp_atend,
         null cd_paciente,
         pu.cd_pessoa,
         ac.DT_ATENDIMENTO dt_ate,
         'hap' local_ate
          From tb_prestador_fisico@hapvida     pf,
               tb_pessoa@hapvida               pm,
               tb_pessoa@hapvida               pl,
               TB_ATENDIMENTO_CONSULTA@hapvida ac,
               tb_pessoa@hapvida               pu
         where ac.cd_pessoa = pu.cd_pessoa
           and pl.cd_pessoa = ac.cd_prestador_juridico
           and pm.cd_pessoa = ac.cd_prestador
           and pf.cd_pessoa = pm.cd_pessoa
         order by 9 desc) Tb
/

