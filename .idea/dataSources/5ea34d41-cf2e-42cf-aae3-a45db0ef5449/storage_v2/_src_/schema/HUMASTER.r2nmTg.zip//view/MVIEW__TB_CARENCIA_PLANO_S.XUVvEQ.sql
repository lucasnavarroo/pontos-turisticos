create view MVIEW$_TB_CARENCIA_PLANO_S as
select "CD_PLANO","CD_CARENCIA","QT_DIAS","QT_DIAS_ATRASO","QT_DIAS_ACRESCIMO","FL_COMPRA_CARENCIA", rowid m_row$$ from humaster.tb_carencia_plano@hapvida

/

comment on table MVIEW$_TB_CARENCIA_PLANO_S is 'master view for snapshot HUMASTER.TB_CARENCIA_PLANO_S'
/

