create view VW_VIGENCIA_TAB_PROCEDIMENTO as
select a.cd_tabela_procedimento,
	a.ds_tabela_procedimento,
	b.dt_vigencia
from tb_vl_procedimento_convenio b,tb_tabela_procedimento a
where a.cd_tabela_procedimento=b.cd_tabela_procedimento
group by a.cd_tabela_procedimento,
	a.ds_tabela_procedimento,
	b.dt_vigencia
/

