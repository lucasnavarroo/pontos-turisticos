create view VW_SAM_MS_GERAL as
select "CD_PROCEDIMENTO_PAI","CD_PROCEDIMENTO","CD_GRUPO_PROCEDIMENTO","CD_SUBGRUPO_PROCEDIMENTO","FL_TIPO_EXAME","NM_PROCEDIMENTO","NM_PROCEDIMENTO_ALIAS_1","NM_PROCEDIMENTO_ALIAS_2","NR_PROCEDIMENTO"
  from (select cd_procedimento_pai,
               cd_procedimento,
               cd_grupo_procedimento,
               cd_subgrupo_procedimento,
               fl_tipo_exame,
               nm_procedimento,
               nm_procedimento_alias_1,
               nm_procedimento_alias_2,
               nr_procedimento
          from (select cd_procedimento_pai,
                       cd_procedimento,
                       cd_grupo_procedimento,
                       cd_subgrupo_procedimento,
                       fl_tipo_exame,
                       nm_procedimento,
                       nm_procedimento_alias_1,
                       nm_procedimento_alias_2,
                       nr_procedimento
                  from tb_procedimento
                 where nm_procedimento_alias_1 is null
                   and nm_procedimento_alias_1 is null
                   and fl_uso = 'S'
                union all
                select cd_procedimento_pai,
                       cd_procedimento,
                       cd_grupo_procedimento,
                       cd_subgrupo_procedimento,
                       fl_tipo_exame,
                       nm_procedimento,
                       nm_procedimento_alias_1,
                       nm_procedimento_alias_2,
                       (nr_procedimento || '  ou  ' ||
                       nm_procedimento_alias_1 || '  ou  ' ||
                       nm_procedimento_alias_2) nr_procedimento
                  from tb_procedimento
                 where nm_procedimento_alias_1 is not null
                   and nm_procedimento_alias_1 is not null
                   and fl_uso = 'S')) tb
 where FN_TIPO_PROCEDIMENTO(tb.CD_PROCEDIMENTO) IN (4, 6)
/

