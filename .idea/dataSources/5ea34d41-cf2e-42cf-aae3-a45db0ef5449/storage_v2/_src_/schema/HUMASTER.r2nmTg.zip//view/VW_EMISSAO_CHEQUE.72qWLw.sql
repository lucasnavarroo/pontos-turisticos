create view VW_EMISSAO_CHEQUE as
select e.cd_movimento_conta,
       e.cd_cheque,
       e.cd_serie_cheque,
       e.dt_emissao,
       e.nm_portador,
       e.fl_emissao,
       m.dt_transacao,
       m.cd_autoriza_cheque,
       m.vl_movimento,
       c.cd_conta_bancaria,
       b.cd_banco,
       b.cd_agencia,
       b.nm_agencia,
       c.cd_conta_corrente
from tb_agencia_bancaria b,
     tm_conta_corrente c,
     tm_movimento_conta m,
     tb_emissao_cheque e
where m.cd_movimento_conta=e.cd_movimento_conta and
--      m.cd_unidade_atendimento like fn_unidade and
      c.cd_conta_bancaria=m.cd_conta_corrente_debito and
--      c.cd_unidade_atendimento like fn_unidade and
      b.cd_banco=c.cd_banco and
      b.cd_agencia=c.cd_agencia
/

