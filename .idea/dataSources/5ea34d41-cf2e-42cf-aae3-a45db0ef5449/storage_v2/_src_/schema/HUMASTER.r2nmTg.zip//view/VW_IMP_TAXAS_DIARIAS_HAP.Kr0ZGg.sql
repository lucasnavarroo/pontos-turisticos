create view VW_IMP_TAXAS_DIARIAS_HAP as
select tc.cd_taxas                cd_taxas_hospital,
         tc.nm_taxas_convenio       nm_taxas_convenio,
         tx.cd_procedimento_taxa    cd_taxas_hapvida,
         tx.ds_taxa                 ds_taxa,
         t.vl_valor_negociado       vl_taxa,
         p.nu_cgc_cpf               nu_cgc_cpf,               -- Filtro
         p.nm_pessoa_razao_social   nm_pessoa_razao_social,   -- Filtro
         p.cd_pessoa                cd_pessoa,                -- Filtro
         tc.cd_convenio             cd_convenio,              -- Filtro
         tc.cd_plano_convenio       cd_plano_convenio,        -- Filtro
         tc.fl_pagamento            fl_pagamento,             -- Filtro
         r.cd_tipo_rede_atendimento cd_tipo_rede_atendimento, -- Filtro
         r.ds_tipo_rede_atendimento ds_tipo_rede_atendimento
    from tb_taxas_convenio                tc,
         tb_taxas_pln@hapvida             tx,
         tb_tipo_rede_atendimento@hapvida r,
         tb_negociacao_taxas_pln@hapvida  t,
         tb_prestador_juridico@hapvida    pj,
         tb_pessoa@hapvida                p
   where pj.cd_pessoa               = p.cd_pessoa
     and t.cd_prestador             = pj.cd_pessoa
     and tx.cd_taxa(+)              = t.cd_codigo_item
     and t.dt_fim_vigencia         is null
     and nvl(t.fl_status, 0)        = 1
     and r.cd_tipo_rede_atendimento = t.cd_tipo_rede_atendimento
     and tc.cd_taxas_convenio       = tx.cd_procedimento_taxa
     and tc.cd_taxas in (select x.cd_taxas
                           from tb_taxas x
                          where x.nr_taxas like tc.nm_taxas_convenio || '%')
   order by 1
/

