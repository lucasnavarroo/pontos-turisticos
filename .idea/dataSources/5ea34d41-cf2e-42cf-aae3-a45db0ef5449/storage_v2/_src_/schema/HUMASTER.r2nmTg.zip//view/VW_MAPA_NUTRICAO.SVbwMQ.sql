create view VW_MAPA_NUTRICAO as
select s.nm_setor,
         oa.cd_acomodacao || '-' || oa.nu_leito as leito,
         dp.cd_atendimento,
         pa.nm_paciente,
         pa.cd_sexo,
         decode(trunc(months_between(current_date, pa.dt_nascimento) / 12), 0,
         decode((trunc(months_between(current_date, pa.dt_nascimento))), 0,
         to_char(trunc(sysdate - pa.dt_nascimento)) || ' d',
         (trunc(months_between(current_date, pa.dt_nascimento))) || ' m'),
         (trunc(months_between(current_date, pa.dt_nascimento) / 12) || ' a')) as idade,
         pm.qt_peso_kg_registrado as peso,
         pm.nu_prescricao_medica,
         dp.cd_dieta,
         d.nm_dieta,
         ta.nm_tipo_acesso,
         upper(pe.nm_fantasia) as cd_profissional_valida,
         dp.dt_prescricao_dieta,
         s.cd_setor,
         oa.cd_acomodacao,
         pm.cd_ocorrencia_plano,
         dp.cd_ordem_dieta,
         dp.cd_ordem_prescricao
  from tb_dieta_paciente dp,
       tb_prescricao_medica pm,
       tm_atendimento a,
       tb_ocupacao_acomodacao oa,
       tm_setor s,
       tb_paciente pa,
       tb_dieta d,
       tb_tipo_acesso ta,
       tb_pessoa pe
  where dp.dt_prescricao_dieta = trunc(current_date)
  and dp.fl_validado = 'S'
  and dp.fl_status_uso = 'S'
  and pm.cd_atendimento = dp.cd_atendimento
  and pm.cd_ocorrencia_plano = dp.cd_ocorrencia_plano
  and pm.cd_ordem_prescricao = dp.cd_ordem_prescricao
  and pm.fl_prescricao_medica = 'M'
  and pm.fl_status_prescricao = 'S'
  and a.cd_atendimento = dp.cd_atendimento
  and a.cd_unidade_atendimento = fn_unidade_operador
  and a.dt_fim_atendimento is null
  and
  (
    select a1.fl_internacao
    from tm_atendimento a1
    where a1.cd_atendimento = a.cd_atendimento
    and a1.cd_unidade_atendimento = a.cd_unidade_atendimento
    and a1.dt_fim_atendimento is null
  ) = 'S'
  and oa.cd_atendimento = a.cd_atendimento
  and oa.fl_ocupacao = 'S'
  and s.cd_setor = oa.cd_posto
  and pa.cd_paciente = a.cd_paciente
  and d.cd_dieta = dp.cd_dieta
  and ta.cd_tipo_acesso(+) = dp.cd_tipo_acesso
  and pe.cd_pessoa = dp.cd_profissional_valida
/

