create view VW_WORKLIST_INTEGRADOS as
select sp.nm_setor_pacs na_requireunit,
       pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem  na_accessionnumber,
       pa.cd_paciente,
       pa.nm_paciente,
       decode(igp.cd_grupo_produto,501,'CT',502,'US',503,'CR',504,'NM',505,'MR',506,'MG',508,'ES',null) nm_modalidade,
       p.nm_procedimento,
       trunc(pr.dt_procedimento_realizado) dt_procedimento_realizado,
       pi.dt_integracao
from pixeon_integracao pi,
     tb_setor_pacs sp,
     tm_setor se,
     tb_pessoa ppf,
     tb_profissional pf,
     tb_prof_proced_realizado ppr,
     tb_paciente pa,
     tb_item_grupo_produto igp,
     tb_procedimento p,
     tb_procedimento_realizado pr,
     tb_unidade_atendimento ua,
     tb_guia gu,
     tm_atendimento a,
     tb_pedido_exame pe
where pe.cd_atendimento = a.cd_atendimento
  and a.cd_atendimento = pr.cd_atendimento
  and gu.cd_atendimento = a.cd_atendimento
  and gu.cd_ocorrencia_pedido = pe.cd_ocorrencia
  and pr.cd_atendimento = gu.cd_atendimento
  and pr.cd_ocorrencia = gu.cd_ocorrencia
  and a.cd_unidade_atendimento = ua.cd_unidade_atendimento
  and pr.cd_procedimento = p.cd_procedimento
  and p.cd_procedimento = igp.cd_produto
  and a.cd_paciente = pa.cd_paciente
  and pr.cd_atendimento = ppr.cd_atendimento
  and pr.cd_ocorrencia = ppr.cd_ocorrencia
  and pr.cd_ordem = ppr.cd_ordem
  and pr.dt_resultado||'' is  null
  and ppr.cd_profissional = pf.cd_profissional
  and pf.cd_profissional = ppf.cd_pessoa
  and gu.cd_setor_origem = se.cd_setor
  and se.cd_setor_pacs = sp.cd_setor_pacs
  and pr.dt_procedimento_realizado between trunc(sysdate - 30) and sysdate
  and nvl(decode(igp.cd_grupo_produto,501,'CT',502,'US',503,'CR',504,'NM',505,'MR',506,'MG',508,'ES',null),'SS') <> 'SS'
  and p.fl_tipo_exame = 2
  and ppr.cd_tipo_ato_profissional = 21
  and pr.cd_atendimento||pr.cd_ocorrencia||pr.cd_ordem = pi.na_accessionnumber
/

