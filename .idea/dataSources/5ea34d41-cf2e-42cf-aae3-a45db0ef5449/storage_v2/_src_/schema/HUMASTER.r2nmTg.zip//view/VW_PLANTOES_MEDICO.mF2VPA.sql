create view VW_PLANTOES_MEDICO as
select "CD_MEDICO"       ,
    "ANO_REFERENCIA"        ,
    "MES_REFERENCIA"        ,
    "NU_PLANTOES"           ,
    "DT_INICIO_PLANTAO"     ,
    "HR_INICIO_PLANTAO"     ,
    "DT_FIM_PLANTAO"        ,
    "HR_FIM_PLANTAO"        ,
    "DT_PROCESSAMENTO"      ,
    "CD_USUARIO"            ,
    "TERMINAL"              ,
    "CD_FILIAL"             ,
    "CD_GRUPO_PROCEDIMENTO" ,
    "CD_EMPRESA"            ,
    "CD_TIPO_REGRA"         ,
    "TEMPO"                 ,
    "VALOR"                 ,
    "TEMPO_CONSIDERADO"     ,
    "FL_SOBRE_AVISO"
  from tb_plantoes_medico
where cd_filial like fn_filial_operador
/

