create view VW_SAM_DADOS_ATESTADO as
select tb."CD_PACIENTE",tb."NU_ATENDIMENTO",tb."CD_PRESTADOR",tb."NM_MEDICO",tb."CD_PRESTADOR_JURIDICO",tb."NM_LOCAL",tb."DT_INICIAL",tb."QT_DIAS",tb."FL_TRANSCRICAO",tb."CID10",tb."CD_OPERADOR",tb."CD_USUARIO",tb."DT_INI",tb."FL_COACAO",  trunc(sysdate) - trunc(nvl(tb.dt_ini, sysdate)) duracao
  from (select a.cd_paciente,
                a.cd_atendimento nu_atendimento,
                am.cd_medico_atendente cd_prestador,
                pf.nm_pessoa_razao_social nm_medico,
                pj.cd_pessoa cd_prestador_juridico,
                pj.nm_pessoa_razao_social nm_local,
                to_char(am.dt_emissao, 'dd/mm/yyyy') dt_inicial,
                am.qt_dias,
                'N' fl_transcricao,
                am.cid10,
                am.nm_operador cd_operador,
                null cd_usuario,
                am.dt_emissao dt_ini,
                am.fl_coacao
           from tb_unidade_atendimento u,
                tb_pessoa              pj,
                tb_pessoa              pf,
                tb_atestado_medico     am,
                tm_atendimento         a
          where a.cd_atendimento = am.cd_atendimento
            and am.cd_medico_atendente = pf.cd_pessoa
            and a.cd_unidade_atendimento = u.cd_unidade_atendimento
            and u.cd_pessoa_cobra = pj.cd_pessoa
            and a.DT_CANC_ATEND is null
         union all
         select null,
                null,
                ac.cd_prestador,
                p.nm_pessoa_razao_social,
                ac.cd_prestador,
                'HAPCLINICA',
                to_char(aa.dt_inicial, 'dd/mm/yyyy') dt_inicial,
                aa.qt_dias,
                aa.fl_transcricao,
                null,
                aa.cd_operador,
                ac.cd_usuario,
                aa.dt_inicial dt_ini,
                'N' fl_coacao
           from tb_pessoa@hapvida               p,
                tb_atendimento_consulta@hapvida ac,
                tb_atendimento_atestado@hapvida aa
          where /*ac.dt_atendimento between (trunc(sysdate) - 90) and
                        trunc(sysdate)
                    and*/
          ac.nu_atendimento = aa.nu_atendimento
       and p.cd_pessoa = ac.cd_prestador_juridico) Tb
/*where (tb.cd_paciente = :cd_paciente or tb.cd_usuario = :cd_usuario)
and tb.dt_inicial between (trunc(sysdate) - :nm_intervalo) and
    trunc(sysdate)*/
 order by tb.dt_ini desc
/

