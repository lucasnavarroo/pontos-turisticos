create view VW_OCUPA as
    (SELECT B.CD_POSTO,
        B.CD_CLASSE_ACOMODACAO,
        B.CD_ACOMODACAO,
        B.NU_LEITO,
        P.NM_PACIENTE,
        B.DT_OCUPACAO,
        E.CD_MEDICO_ATENDENTE,
        B.CD_ATENDIMENTO,
        E.CD_UNIDADE_ATENDIMENTO
    FROM TB_PACIENTE P,
         TM_ATENDIMENTO E,
         TB_OCUPACAO_ACOMODACAO B
   WHERE B.DT_LIBERACAO                             IS   NULL
     AND B.FL_OCUPACAO                              =    'S'
     AND E.CD_ATENDIMENTO                           =    B.CD_ATENDIMENTO
     --AND E.CD_UNIDADE_ATENDIMENTO                   LIKE FN_UNIDADE
     AND E.DT_CANC_ATEND                            IS   NULL
--     AND E.DT_FIM_ATENDIMENTO                       IS   NULL
     AND P.CD_PACIENTE                              =    E.CD_PACIENTE
 union all
select  cd_posto,
        cd_classe_acomodacao,
        cd_acomodacao,
        nu_leito,
        NM_PACIENTE,
        DT_AGENDA,
        0,
        0,
        '0'
   from tb_agenda_internacao
  where  cd_status     =  'A'
  and trunc(sysdate) - trunc(dt_agenda) <= decode(to_char(sysdate,'d'),'1', 2,
                                                                       '2', 3, 1))
/

