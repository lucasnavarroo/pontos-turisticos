create view VW_SAM_MEDICAM_PRESC as
select m.cd_mat_med,
       m.nu_produto,
       /*decode(nvl(p.nr_produto, 'X'),
       'X',
       p.nm_produto,
       p.nr_produto)*/
       p.nm_produto nm_produto
  from tb_produto p, tb_produto_mat_med m
 where p.nu_produto = m.nu_produto
/

