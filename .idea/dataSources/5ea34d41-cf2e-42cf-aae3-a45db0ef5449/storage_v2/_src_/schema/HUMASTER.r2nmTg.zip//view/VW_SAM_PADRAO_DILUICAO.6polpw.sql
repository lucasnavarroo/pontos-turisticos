create view VW_SAM_PADRAO_DILUICAO as
select
distinct ta.cd_mnemonico,
         ad.ds_administracao_diluicao,
         pr.nm_produto nm_reconstituir,
         to_char(ad.qt_reconstituir) ||
         decode(ad.qt_reconstituir, null, '', 'ML') qt_reconstituir,
         pr1.nm_produto nm_diluente,
         to_char(ad.qt_diluente) || decode(ad.qt_diluente, null, '', 'ML') qt_diluente,
         ad.cd_principio_ativo,
         ad.cd_ocorrencia_diluicao,
         ad.cd_ordem_administracao,
         ad.qt_diluente qtde_diluente,
         ad.qt_reconstituir qtde_reconstituir,
         pr2.nm_produto nm_reconstituir2,
         ad.qt_reconstituir2,
         ad.cd_diluente,
         decode(ad.fl_tipo_administracao,
                'B',
                'Bolus',
                'C',
                'Contínuo',
                'L',
                'Lento') tipo_adm,
         ad.cd_apresentacao_diluente,
         pf.nu_produto,
         pcd.cd_classe_acomodacao,
         ad.cd_tipo_acesso,
         ap.qt_volume, -- and (ap.qt_volume = :tb_prescricao_plano.qt_volume_aux or m.fl_fragmenta = 'S')
         m.fl_fragmenta,
         ap.cd_unidade_dosagem,
         ap.qt_dosagem
  from tb_tipo_acesso             ta,
       tb_produto                 pr2,
       tb_produto                 pr,
       tb_produto                 pr1,
       tb_material                m,
       tb_produto_mat_med         pf,
       tb_param_classe_diluicao   pcd,
       tb_principio_ativo         pa,
       tb_produto_principio_ativo ppa,
       tb_apresentacao_diluicao   ap,
       tb_administracao_diluicao  ad
 where ad.cd_principio_ativo = ppa.cd_principio_ativo
   and ap.cd_principio_ativo = ad.cd_principio_ativo
   and ap.cd_ocorrencia_diluicao = ad.cd_ocorrencia_diluicao
   and ppa.nu_produto = pf.nu_produto
   and pa.cd_principio_ativo = ppa.cd_principio_ativo
   and pcd.cd_principio_ativo(+) = ad.cd_principio_ativo
   and pcd.cd_ocorrencia_diluicao(+) = ad.cd_ocorrencia_diluicao
   and pcd.cd_ordem_administracao(+) = ad.cd_ordem_administracao
   and m.cd_material = pf.cd_mat_med
   and pr.nu_produto(+) = ad.cd_reconstituir
   and pr1.nu_produto(+) = ad.cd_diluente
   and pr2.nu_produto(+) = ad.cd_reconstituir2
   and ad.cd_tipo_acesso + 0 = ta.cd_tipo_acesso
/

