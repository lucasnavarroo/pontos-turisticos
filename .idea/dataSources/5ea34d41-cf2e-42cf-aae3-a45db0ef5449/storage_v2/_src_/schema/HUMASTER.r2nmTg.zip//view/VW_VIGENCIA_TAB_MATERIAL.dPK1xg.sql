create view VW_VIGENCIA_TAB_MATERIAL as
select a.cd_tabela_mat_med,
 a.ds_tabela_mat_med,
 b.dt_vigencia
from tb_vl_mat_med_convenio b,tb_tabela_mat_med a
where a.cd_tabela_mat_med = b.cd_tabela_mat_med
group by a.cd_tabela_mat_med,
 a.ds_tabela_mat_med,
 b.dt_vigencia
/

