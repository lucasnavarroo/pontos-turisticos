create view VW_DEMO_PROC_GLOSA as
select DISTINCT
       d.nu_remessa,
       i.nu_item_remessa,
       d.nu_registro_ans,
       d.cd_atendimento,
       d.nu_guia
  from tb_item_remessa_glosa i,
       tb_demostrativo_proc_glosa D
where d.nu_remessa            = i.nu_remessa
  and d.nu_item_remessa       = i.nu_item_remessa
  and d.nu_remessa            = i.nu_remessa
  and nvl(d.vl_a_recuperar,0) > 0

--grant select on humaster.vw_demo_proc_glosa to RL_ADMINISTRACAO4
/

