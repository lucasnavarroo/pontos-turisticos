create view VW_PROCEDIMENTO_CIRURGICO as
    select  tb_procedimento.cd_procedimento,
	tb_procedimento.cd_subgrupo_procedimento,
	tb_procedimento.cd_grupo_procedimento,
	tb_procedimento.nr_procedimento,
	tb_procedimento.fl_cirurgia,
	rowidtochar(tb_procedimento.rowid) ri_procedimento
from tb_procedimento
where fl_cirurgia = 1
union
select  tb_procedimento.cd_procedimento,
	tb_procedimento.cd_subgrupo_procedimento,
	tb_procedimento.cd_grupo_procedimento,
	tb_procedimento.nr_procedimento,
	tb_procedimento.fl_cirurgia,
	rowidtochar(tb_procedimento.rowid) ri_procedimento
from tb_procedimento
where fl_cirurgia <> 1
  and fl_tipo_exame in (2,7)
/

