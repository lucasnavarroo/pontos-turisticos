create view VW_SAM_EXAMES_PRC as
select /* + first_rows(10) */
         cp.cd_atendimento, pc.cd_procedimento,p.nr_procedimento,decode(nvl(pc.fl_senha_auto_hapvida,'N'),'S',1,0) senha_aut,
         p.nu_prioridade_exame, decode(nvl(fl_cbhpm,'N'),'N','AMB','CBHPM') tabela,
         coalesce(p.fl_solic_inter_na_emergencia, 'N') fl_solic_inter_na_emergencia,
		 coalesce(p.fl_urgencia, 'N') fl_urgencia
  from tb_procedimento p,
       tb_procedimento_convenio pc,
       tm_convenio c,
       tb_convenio_pagador cp
  where cp.cd_convenio_pagador= 1 and
        cp.cd_convenio_base   = c.CD_CONVENIO and
        pc.cd_convenio        = cp.cd_convenio_base and
 	      pc.cd_plano_convenio  = cp.cd_plano_base and
	      p.cd_procedimento     = pc.cd_procedimento  and
		    p.fl_tipo_exame       in (5,3)
		and nvl(p.fl_cbhpm,'N') = nvl(c.fl_cbhpm_convenio, 'N')
/

