create view FN_LIQDC_DOC as
select "ID_LIQDC_DOC","ID_CC_ORIGEM","ID_CC_DESTINO","NUM_DOC","ID_LOTE_INTEGRACAO","ID_SEQ_INTEGRACAO"
     from fn_liqdc_doc@matera
/

