create view VW_SAM_PRESC_PADRAO_DIETAS as
select f."CD_MODELO",f."CD_ORDEM_DIETA",f."CD_DIETA",f."NM_DIETA",f."DT_PRESCRICAO_DIETA",f."DT_INICIAL",f."DT_FINAL",f."CD_MEDICO",f."CD_UNIDADE_USUAL",f."NU_FREQUENCIA",f."QT_DIETA",f."DS_OBSERVACAO",f."CD_TIPO_ACESSO",f."CD_OPERADOR",f."CD_TERMINAL",f."DT_TRANSACAO",f."FL_STATUS_USO",f."HR_INICIO_USO",f."CD_PROFISSIONAL_PRESCREVE",f."CD_PROFISSIONAL_VALIDA",f."CD_PROFISSIONAL_CANCELA",f."FL_VALIDADO",f."FL_IMPRESSO",f."FL_BOMBA_INFUSAO",f."QT_GOTEJAMENTO",f."CD_GOTEJAMENTO",f."QT_TEMPO_GOTEJ",f."CD_UNIDADE_GOTEJ",f."FL_ROTINA_RG",f."CD_ORDEM_IMPRESSAO",f."CD_ORDEM_IMPRESSAO_ITEM",f."DT_IMPRESSAO",f."CD_PROFISSIONAL_IMPRIME",f."DT_HR_SUSPENSAO",f."FL_ENTEROFIX",f."FL_EQUIPO_BOMBA",f."LS_MNEMONICO", g.cd_mnemonico ls_gotejamento
  from (select c.*,
               e.cd_mnemonico ls_mnemonico from (select cd_modelo,
                                                   cd_ordem_dieta,
                                                   a.cd_dieta,
                                                   b.nm_dieta,
                                                   dt_prescricao_dieta,
                                                   dt_inicial,
                                                   dt_final,
                                                   cd_medico,
                                                   cd_unidade_usual,
                                                   nu_frequencia,
                                                   qt_dieta,
                                                   ds_observacao,
                                                   cd_tipo_acesso,
                                                   cd_operador,
                                                   cd_terminal,
                                                   dt_transacao,
                                                   fl_status_uso,
                                                   fn_hora(hr_inicio_uso) hr_inicio_uso,
                                                   cd_profissional_prescreve,
                                                   cd_profissional_valida,
                                                   cd_profissional_cancela,
                                                   fl_validado,
                                                   fl_impresso,
                                                   fl_bomba_infusao,
                                                   qt_gotejamento,
                                                   cd_gotejamento,
                                                   qt_tempo_gotej,
                                                   cd_unidade_gotej,
                                                   fl_rotina_rg,
                                                   cd_ordem_impressao,
                                                   cd_ordem_impressao_item,
                                                   dt_impressao,
                                                   cd_profissional_imprime,
                                                   dt_hr_suspensao,
                                                   fl_enterofix,
                                                   fl_equipo_bomba
                                              from tb_dieta_paciente_modelo a,
                                                   (select d.cd_dieta,
                                                           decode(td.cd_tipo_dieta,
                                                                  1,
                                                                  d.nm_dieta,
                                                                  substr(td.ds_tipo_dieta,
                                                                         1,
                                                                         10) ||
                                                                  ' / ' ||
                                                                  d.nm_dieta) nm_dieta
                                                      from tb_tipo_dieta td,
                                                           TB_DIETA      d
                                                     where d.cd_tipo_dieta =
                                                           td.cd_tipo_dieta) b
                                             where b.cd_dieta(+) = a.cd_dieta) c,
               tb_tipo_acesso e where e.cd_tipo_acesso(+) = c.cd_tipo_acesso) f,
       tb_gotejamento g
 where g.cd_gotejamento(+) = f.cd_gotejamento
/

