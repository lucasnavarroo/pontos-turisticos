create view VW_ITENS_REAL as
    select a.cd_atendimento                             cd_atendimento,
       aa.cd_ocorrencia                             cd_ocorrencia,
       aa.cd_ordem                                  cd_ordem,
       to_char(aab.cd_procedimento)                 cd_procedimento,
       aab.nm_procedimento                          nm_procedimento,
       aaaaaa.cd_grupo_prod_proc                    cd_tipo_item,
       aaaaaa.nm_grupo_prod_proc                    nm_tipo_item,
       to_char(aaaaa.cd_material)                   cd_item,
       aaaaa.nm_material                            nm_item,
       aaaaa.cd_unidade_usual                       cd_um,
       sum(aaaa.qt_material + nvl(aaaa.qt_devolvido, 0)) qtd_item,
       humaster.fn_custo_unit_item(aaaa.cd_mat_med, sysdate, fn_filial_setor(a.cd_setor)) prc_unit,
       sum((aaaa.qt_material + nvl(aaaa.qt_devolvido, 0)) * humaster.fn_custo_unit_item(aaaa.cd_mat_med, sysdate, fn_filial_setor(a.cd_setor))) total
  from       tb_procedimento             aab,
                   tm_setor              aaab,
                      tb_grupo_prod_proc aaaaaa,
                   tb_material           aaaaa,
                tb_comanda_mat_med       aaaa,
             tb_comanda                  aaa,
          tb_procedimento_realizado      aa,
       tm_atendimento                    a
 where 1 = 1
    -- filtros
   and (aaaa.qt_material + nvl(aaaa.qt_devolvido, 0)) > 0 /* Materiais que tiveram quantidade superior a 0 */
   -- e um procedimento padronizado
   and exists (select 1
                 from vw_procedimento_pai_filho b
                where 1 = 1
                  and b.procedimento_filho = aa.cd_procedimento)
    -- join a -< aa
   and a.cd_atendimento = aa.cd_atendimento
    -- join aa -< aaa
   and aa.cd_atendimento = aaa.cd_atendimento
   and aa.cd_ocorrencia  = aaa.cd_ocorrencia
   and aa.cd_ordem       = aaa.cd_ordem
    -- join aaa -< aaaa
   and aaa.cd_atendimento = aaaa.cd_atendimento
   and aaa.cd_ocorrencia  = aaaa.cd_ocorrencia
   and aaa.cd_ordem       = aaaa.cd_ordem
   and aaa.cd_ordem_cmd   = aaaa.cd_ordem_cmd
    -- join aaaa -- aaaaa
   and aaaa.cd_mat_med = aaaaa.cd_material
    -- join aaa >- aaab
   and aaa.cd_setor_destino = aaab.cd_setor
    -- join aaaaa -- aaaaaa
   and decode(nvl(aaaaa.fl_opme, 'N'), 'S', 10, decode(decode(nvl(aaab.fl_centro_cirurgico, 'N'), 'N', nvl(aaab.fl_centro_obstetrico, 'N'), nvl(aaab.fl_centro_cirurgico, 'N')), 'S', 11, 12)) = aaaaaa.cd_grupo_prod_proc
    -- join aa -- aab
   and aa.cd_procedimento = aab.cd_procedimento
 group by a.cd_atendimento,
          aa.cd_ocorrencia,
          aa.cd_ordem,
          to_char(aab.cd_procedimento),
          aab.nm_procedimento,
          aaaaaa.cd_grupo_prod_proc,
          aaaaaa.nm_grupo_prod_proc,
          to_char(aaaaa.cd_material),
          humaster.fn_custo_unit_item(aaaa.cd_mat_med, sysdate, fn_filial_setor(a.cd_setor)),
          aaaaa.nm_material,
          aaaaa.cd_unidade_usual
 union all
/* Exames de laboratorio e imagem */
select a.cd_atendimento            cd_atendimento,
       aa.cd_ocorrencia            cd_ocorrencia,
       aa.cd_ordem                 cd_ordem,
       to_char(aa.cd_procedimento) cd_procedimento,
       aaa.nm_procedimento         nm_procedimento,
       aaaa.cd_grupo_prod_proc     cd_tipo_item,
       aaaa.nm_grupo_prod_proc     nm_tipo_item,
       to_char(aa.cd_procedimento) cd_item,
       aaa.nm_procedimento         nm_item,
       ''                          cd_um,
       aa.qt_procedimento          qtd_item,
       humaster.fn_custo_unit_procedimento(aa.cd_procedimento) prc_unit,
       aa.qt_procedimento * humaster.fn_custo_unit_procedimento(aa.cd_procedimento) total
  from          tb_grupo_prod_proc  aaaa,
             tb_procedimento        aaa,
          tb_procedimento_realizado aa,
       tm_atendimento               a
 where 1 = 1
    -- filtros
   and aaa.fl_tipo_exame in (0, 1, 2) /* Exames de laboratorio(0,1) e imagem(2) */
    -- join a -< aa
   and a.cd_atendimento = aa.cd_atendimento
    -- join aa >- aaa
   and aa.cd_procedimento = aaa.cd_procedimento
    -- join aaa -- aaaa
   and decode(aaa.fl_tipo_exame, 0, 13, 1, 13, 2, 14) = aaaa.cd_grupo_prod_proc
/

