create view VW_NASCEBEM_NUCLEO as
select /*+choose*/ max(c.dt_status) dt_status , c.cd_nucleo || '-' ||p.nm_pessoa_razao_social nm_nucleo, u.cd_usuario
       from tb_medprev_contato@hapvida c, tb_usuario@hapvida u, tb_pessoa@hapvida p
       where u.nu_usuario = c.nu_usuario
         and p.cd_pessoa = c.cd_nucleo
         and c.cd_nucleo is not null
       group by c.cd_nucleo, c.cd_nucleo || '-' ||p.nm_pessoa_razao_social, u.cd_usuario
/

