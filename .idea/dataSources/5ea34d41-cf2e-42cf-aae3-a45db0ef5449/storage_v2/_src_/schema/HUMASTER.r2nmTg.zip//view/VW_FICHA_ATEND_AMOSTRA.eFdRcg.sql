create view VW_FICHA_ATEND_AMOSTRA as
select gu.cd_ocorrencia_pedido ocor_ped,
       gu.nu_guia,
       gu.cd_setor_origem,
       gu.cd_pessoa_realiza,
       pr.cd_procedimento,
       pr.qt_procedimento,
       decode(co.cd_tipo_convenio,
              0,
              pr.vl_total / nvl(pr.qt_procedimento, 1),
              0) vl_unit_proc,
       decode(co.cd_tipo_convenio, 0, pr.vl_total, 0) vl_proced,
       gu.cd_atendimento,
       pr.cd_ocorrencia,
       pr.cd_ordem ord_ped,
       pr.cd_senha_autoriza,
       pf.cd_profissional crm_medico,
       pe.nm_fantasia nm_medico,
       cp.cd_convenio_pagador,
       pec.nm_fantasia nm_convenio,
       pc.ds_plano_convenio,
       cp.nu_carteira_convenio,
       gp.cd_grupo_produto,
       gp.nm_grupo_produto,
       (select ap.cd_amostra
          from tb_amostra_procedimento    ap
         where ap.cd_atendimento = pr.cd_atendimento
          and ap.cd_ocorrencia   = pr.cd_ocorrencia
          and ap.cd_ordem        = pr.cd_ordem
          and rownum = 1) amostra
  from tb_grupo_produto           gp,
       tb_convenio                co,
       tb_plano_convenio          pc,
--       tb_item_grupo_procedimento igp,
       tb_procedimento            po,
       tb_profissional            pf,
       tb_pessoa                  pe,
       tb_pessoa                  pec,
       tb_pedido_exame            pex,
       tb_convenio_pagador        cp,
       tb_guia                    gu,
       tb_procedimento_realizado  pr,
       tb_prof_proced_realizado   pp
 where pp.cd_tipo_ato_profissional = 21
   and pp.cd_atendimento = pr.cd_atendimento
   and pp.cd_ocorrencia = pr.cd_ocorrencia
   and pp.cd_ordem = pr.cd_ordem
   and pr.cd_atendimento = gu.cd_atendimento
   and pr.cd_ocorrencia = gu.cd_ocorrencia
   and gu.cd_atendimento = cp.cd_atendimento
   and gu.cd_convenio_pagador = cp.cd_convenio_pagador
   and cp.cd_convenio_base = co.cd_convenio
   and gu.cd_atendimento = pex.cd_atendimento
   and gu.cd_ocorrencia_pedido = pex.cd_ocorrencia
   and pec.cd_pessoa = co.cd_pessoa
   and pe.cd_pessoa = pp.cd_profissional
   and pe.cd_pessoa = pf.cd_profissional
   and pr.cd_procedimento = po.cd_procedimento
   --and po.cd_procedimento = igp.cd_procedimento
   and cp.cd_convenio_base = pc.cd_convenio
   and cp.cd_plano_base = pc.cd_plano_convenio
   and fn_grupo_excessao(fn_unidade_operador,po.cd_procedimento) = gp.cd_grupo_produto
/

