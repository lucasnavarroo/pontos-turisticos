create view VW_IMP_MATERIAIS_HAP as
select mc.cd_material             cd_material_hospital,
         mc.nm_material_convenio    nm_material_convenio,
         m.cd_material              cd_material_hapvida,
         m.ds_material              ds_material,
         t.vl_valor_negociado       vl_material,
         p.nu_cgc_cpf               nu_cgc_cpf,               -- Filtro
         p.nm_pessoa_razao_social   nm_pessoa_razao_social,   -- Filtro
         p.cd_pessoa                cd_pessoa,                -- Filtro
         mc.cd_convenio             cd_convenio,              -- Filtro
         mc.cd_plano_convenio       cd_plano_convenio,        -- Filtro
         mc.fl_pagamento            fl_pagamento,             -- Filtro
         r.cd_tipo_rede_atendimento cd_tipo_rede_atendimento, -- Filtro
         r.ds_tipo_rede_atendimento ds_tipo_rede_atendimento
    from tb_material_convenio                mc,
         tb_materiais_pln@hapvida            m,
         tb_tipo_rede_atendimento@hapvida    r,
         tb_negociacao_materiais_pln@hapvida t,
         tb_prestador_juridico@hapvida       pj,
         tb_pessoa@hapvida                   p
   where pj.cd_pessoa               = p.cd_pessoa
     and t.cd_prestador             = pj.cd_pessoa
     and m.cd_material(+)           = t.cd_codigo_item
     and t.dt_fim_vigencia is null
     and nvl(t.fl_status, 0)        = 1
     and r.cd_tipo_rede_atendimento = t.cd_tipo_rede_atendimento
     and mc.cd_material_convenio    = m.cd_material
     and exists (select 1
                   from tb_mat_med            a,
                        tb_classificacao      b,
                        tb_tipo_classificacao c
                  where a.cd_mat_med            = mc.cd_material
                    and b.cd_classificacao      = a.cd_classificacao
                    and b.cd_tipo_classificacao = c.cd_tipo_classificacao
                    and c.fl_tipo_classificacao in (1, 2))
   order by 1
/

