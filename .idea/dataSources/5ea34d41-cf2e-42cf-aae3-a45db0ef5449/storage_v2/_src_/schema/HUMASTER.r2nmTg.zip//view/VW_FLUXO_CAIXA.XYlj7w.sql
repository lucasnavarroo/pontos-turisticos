create view VW_FLUXO_CAIXA as
    select
 v.dt_transacao,
 m.cd_filial,
 abs(m.VL_TRANSACAO) vl_transacao,
 m.CD_UM_TRANSACAO         ,
 decode(sign(m.vl_transacao),-1,decode(m.fl_lancamento,'C','D','D','C'),m.FL_LANCAMENTO) fl_lancamento
from tm_movimento_transacao m, tm_movimento_conta v
where   m.cd_movimento_conta = v.cd_movimento_conta and
   v.dt_estorno is null
union all
select
  greatest(trunc(sysdate),dt_prevista_liquidacao),o.cd_filial,
  decode(vl_saldo_obrigacao,0,vl_obrigacao,null,vl_obrigacao,
  vl_saldo_obrigacao) + nvl(decode(sign(dt_vencimento-greatest(trunc(sysdate),dt_prevista_liquidacao)),-1,
  vl_obrigacao*pc_multa_atrazo/100*decode(cd_status,2,0,7,0,1),0),0) +
  nvl(decode(sign(dt_vencimento-greatest(trunc(sysdate),dt_prevista_liquidacao)),-1,
  (greatest(trunc(sysdate),dt_prevista_liquidacao)-dt_vencimento)*
  vl_juro_dia,0),0),
  o.cd_um,decode(cd_tipo_obrigacao,1,'C','D')
from tm_obrigacao o
where o.cd_status in (1,2,5,10,11,13,12,14)
/

