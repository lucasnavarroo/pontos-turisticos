create view VW_TELA as
select  distinct at.cd_tela,
 t.nm_tela
from    tb_tela t,
 tb_acesso_tela at
where   at.cd_tela = t.cd_tela(+)
/

