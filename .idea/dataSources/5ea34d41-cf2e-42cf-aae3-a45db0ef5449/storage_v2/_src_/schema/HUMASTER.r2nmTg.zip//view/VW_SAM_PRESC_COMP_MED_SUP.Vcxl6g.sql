create view VW_SAM_PRESC_COMP_MED_SUP as
select cd_atendimento,
       cd_ocorrencia_plano,
       cd_ordem_prescricao,
       cd_ordem_proc_plano_uso,
       cd_proc_plano_pai,
       cd_tipo_procedimento,
       cd_unidade_usual,
       fl_tipo_aprazamento,
       qt_procedimento,
       fl_validado,
       cd_procedimento
  from TB_PROCEDIMENTO_PLANO_USO
  where fl_tipo_aprazamento is null
/

