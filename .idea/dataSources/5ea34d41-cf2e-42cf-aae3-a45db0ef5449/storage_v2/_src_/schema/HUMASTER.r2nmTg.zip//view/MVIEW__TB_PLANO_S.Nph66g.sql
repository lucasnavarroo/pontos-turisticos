create view MVIEW$_TB_PLANO_S as
select  cd_plano,
                nm_plano,
                nr_plano,
                fl_status_plano,
                ds_linha_1,
                ds_linha_2,
                ds_linha_3,
                ds_linha_4,
                ds_linha_5,
                ds_linha_6,
                fl_nivel,
                cd_tipo_acomodacao,
                fl_tipo_plano,
                cd_tipo_rede_atendimento,
                cd_plano_pai,
                cd_tipo_plano
        , rowid m_row$$ from humaster.tb_plano@hapvida

/

comment on table MVIEW$_TB_PLANO_S is 'master view for snapshot HUMASTER.TB_PLANO_S'
/

