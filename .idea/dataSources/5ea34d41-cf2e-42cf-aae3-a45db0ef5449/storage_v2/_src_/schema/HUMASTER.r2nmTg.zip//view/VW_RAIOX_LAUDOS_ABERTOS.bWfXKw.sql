create view VW_RAIOX_LAUDOS_ABERTOS as
select a.cd_atendimento,
           a.dt_atendimento,
           a.cd_paciente,
           pe.nu_pedido,
           pe.dt_pedido,
           p.cd_procedimento,
           p.nm_procedimento,
           pr.dt_procedimento_realizado,
           pr.hr_procedimento_realizado,
           g.cd_pessoa_realiza,
           pr.cd_setor,
           to_date(to_char(pr.dt_procedimento_realizado, 'ddmmyyyy')||' '||substr(fn_hora(pr.hr_procedimento_realizado), 1, 2)||substr(fn_hora(pr.hr_procedimento_realizado), 4, 2),'dd/mm/yyyy hh24:mi:ss') dt_proc_realizado,
           (sysdate - to_date(to_char(pr.dt_procedimento_realizado, 'ddmmyyyy')||' '||substr(fn_hora(pr.hr_procedimento_realizado), 1, 2)||substr(fn_hora(pr.hr_procedimento_realizado), 4, 2),'dd/mm/yyyy hh24:mi:ss')) * 1440 total_minutos,
           decode(nvl(pr.fl_status_laudo,'0'), '0', 'ABERTO',
                                               '1', 'EM ANALISE',
                                               '2', 'PRÉ LAUDO',
                                               '3', 'LIBERADO',
                                               '4', 'PENDENTE') status_laudo,
           pr.cd_profissional_laudo
    from  tb_item_grupo_produto igp,
          tb_procedimento p,
          tb_procedimento_realizado pr,
          tm_atendimento a,
          tb_guia g,
          tb_pedido_exame pe
    where pr.dt_procedimento_realizado between sysdate - 180 and sysdate
      and p.fl_tipo_exame = '2' -- exames de imagem
      and pr.fl_status_laudo != '3' -- laudos liberados
      and a.cd_motivo_atendimento = '1' -- urgencia
      and igp.cd_grupo_produto = '503'
      and g.cd_atendimento = pe.cd_atendimento
      and g.cd_ocorrencia_pedido = pe.cd_ocorrencia
      and pr.cd_atendimento = g.cd_atendimento
      and pr.cd_ocorrencia  = g.cd_ocorrencia
      and p.cd_procedimento  = pr.cd_procedimento
      and p.cd_procedimento = igp.cd_produto
      and a.cd_atendimento = pr.cd_atendimento
/

