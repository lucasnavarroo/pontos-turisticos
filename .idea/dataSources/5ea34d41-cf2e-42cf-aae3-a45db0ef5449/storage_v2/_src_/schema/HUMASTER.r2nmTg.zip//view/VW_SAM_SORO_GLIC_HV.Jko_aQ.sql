create view VW_SAM_SORO_GLIC_HV as
select pr.nu_produto cd_diluente, pr.nm_produto nm_diluente
  from tb_produto pr
 where pr.fl_diluente = 'S'
   and pr.fl_compoe_hv = 'S'
   and pr.nu_produto in
       (select pm.nu_produto
          from tb_produto_principio_ativo ppa,
               tb_material                m,
               tb_produto_mat_med         pm
         where m.cd_material = pm.cd_mat_med
           and m.cd_unidade_dosagem in ('MG', 'GR')
           and ppa.nu_produto = pm.nu_produto
           and ppa.cd_principio_ativo in (1240, 1241, 2190))
/

