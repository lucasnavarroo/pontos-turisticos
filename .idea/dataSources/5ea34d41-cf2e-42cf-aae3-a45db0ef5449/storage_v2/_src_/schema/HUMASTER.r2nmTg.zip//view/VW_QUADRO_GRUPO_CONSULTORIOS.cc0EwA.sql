create view VW_QUADRO_GRUPO_CONSULTORIOS as
select gc.cd_local_atendimento local,
              gr.cd_grupo_atendimento especialidade,
              ga.ds_grupo_atendimento ds_especialidade,
              gc.cd_grupo_consultorio grupo,
              gc.ds_grupo_consultorio ds_consultorio,
              count(po.cd_ponto_atendimento) consultorios,
             (select count(sa.cd_senha_master) from tb_senha_atendimento_sa sa
               where sa.dt_geracao_senha between sysdate - 1 and sysdate
                 and sa.cd_local_atendimento = gc.cd_local_atendimento
                 and sa.cd_grupo_atendimento+0 = gr.cd_grupo_atendimento
                 and nvl(sa.fl_principal,'N') = 'S'
                 and sa.fl_status in (2,3)
                 and nvl(sa.fl_prioridade,'0') like decode(0,1,'1','%')
                 and ((sa.cd_grupo_consultorio = gc.cd_grupo_consultorio) or
                      (gc.cd_grupo_consultorio = fn_calcula_consultorio_trg_sa(gc.cd_local_atendimento,null) and
                       nvl(sa.cd_grupo_consultorio,9999) = 9999)
                      )) pacientes,
             (select nvl(count(distinct sa.cd_ponto_atendimento_ate),0) from tb_senha_atendimento_sa sa
               where sa.dt_geracao_senha between sysdate - 1 and sysdate
                 and sa.cd_local_atendimento = gc.cd_local_atendimento
                 and sa.cd_grupo_atendimento+0 = gr.cd_grupo_atendimento
                 and nvl(sa.fl_principal,'N') = 'S'
                 and sa.fl_status in (10)
                 and nvl(sa.fl_prioridade,'0') like decode(0,1,'1','%')
                 and ((sa.cd_grupo_consultorio = gc.cd_grupo_consultorio) or
                      (gc.cd_grupo_consultorio = fn_calcula_consultorio_trg_sa(gc.cd_local_atendimento,null) and
                       nvl(sa.cd_grupo_consultorio,9999) = 9999)
                      )) retorno,
             (select nvl(count(distinct sa.cd_ponto_atendimento_ate),0) from tb_senha_atendimento_sa sa
               where sa.dt_geracao_senha between sysdate - 1 and sysdate
                 and sa.cd_local_atendimento = gc.cd_local_atendimento
                 and sa.cd_grupo_atendimento+0 = gr.cd_grupo_atendimento
                 and nvl(sa.fl_principal,'N') = 'S'
                 and sa.fl_status in (3)
                 and nvl(sa.fl_prioridade,'0') like decode(0,1,'1','%')
                 and ((sa.cd_grupo_consultorio = gc.cd_grupo_consultorio) or
                      (gc.cd_grupo_consultorio = fn_calcula_consultorio_trg_sa(gc.cd_local_atendimento,null) and
                       nvl(sa.cd_grupo_consultorio,9999) = 9999)
                      )) atendendo,
             (select count(sa.cd_senha_master) from tb_senha_atendimento_sa sa
               where sa.dt_geracao_senha between sysdate - 1 and sysdate
                 and sa.cd_local_atendimento = gc.cd_local_atendimento
                 and sa.cd_grupo_atendimento+0 = gr.cd_grupo_atendimento
                 and nvl(sa.fl_principal,'N') = 'S'
                 and sa.fl_status in (2)
                 and nvl(sa.fl_prioridade,'0') like decode(0,1,'1','%')
                 and ((sa.cd_grupo_consultorio = gc.cd_grupo_consultorio) or
                      (gc.cd_grupo_consultorio = fn_calcula_consultorio_trg_sa(gc.cd_local_atendimento,null) and
                       nvl(sa.cd_grupo_consultorio,9999) = 9999)
                      )) aguardando,
             ((select count(sa.cd_senha_master) from tb_senha_atendimento_sa sa
               where sa.dt_geracao_senha between sysdate - 1 and sysdate
                 and sa.cd_local_atendimento = gc.cd_local_atendimento
                 and sa.cd_grupo_atendimento+0 = gr.cd_grupo_atendimento
                 and nvl(sa.fl_principal,'N') = 'S'
                 and sa.fl_status in (2,3)
                 and nvl(sa.fl_prioridade,'0') like decode(0,1,'1','%')
                 and ((sa.cd_grupo_consultorio = gc.cd_grupo_consultorio) or
                      (gc.cd_grupo_consultorio = fn_calcula_consultorio_trg_sa(gc.cd_local_atendimento,null) and
                       nvl(sa.cd_grupo_consultorio,9999) = 9999)))/
                 count(po.cd_ponto_atendimento)) indice
             from
                  tb_ponto_operador_atend_sa po,
                  tb_grupo_atendimento_sa ga,
                  tb_grupo_ponto_atend_sa gr,
                  tb_grupo_consultorio_sa gc
            where
              gr.cd_local_atendimento = gc.cd_local_atendimento
              and ga.cd_local_atendimento = gr.cd_local_atendimento
              and ga.cd_grupo_atendimento = gr.cd_grupo_atendimento
              and nvl(ga.cd_grupo_procedimento,0) not in (9) -- exclui triagem
              and po.cd_local_atendimento = gr.cd_local_atendimento
              and po.cd_ponto_atendimento = gr.cd_ponto_atendimento
              and po.cd_grupo_consultorio = gc.cd_grupo_consultorio
              and po.fl_tipo = 1
      group by gc.cd_local_atendimento,
               gr.cd_grupo_atendimento,
               ga.ds_grupo_atendimento,
               gc.cd_grupo_consultorio,
               gc.ds_grupo_consultorio
      order by  1, 4, 11, 6 desc
/

