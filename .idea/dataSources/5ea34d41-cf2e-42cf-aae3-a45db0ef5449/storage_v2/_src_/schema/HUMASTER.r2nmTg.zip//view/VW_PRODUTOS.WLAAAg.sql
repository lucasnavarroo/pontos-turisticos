create view VW_PRODUTOS as
    select cd_procedimento cd_produto,
       nr_procedimento nm_produto
from tb_procedimento
union all
select cd_taxas,nr_taxas
from tb_taxas
/

